<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps the customer-facing shipping charge inside WooCommerce accounting.
 */
class DUTT_SHD_WooCommerce_Fiscal {
	public const SHIPPING_CHARGE_OWNER    = 'merchant';
	public const CONSUMER_DOCUMENT_ISSUER = 'merchant';
	public const TAX_SYSTEM               = 'woocommerce';

	public static function shipping_rate_cost( array $quote ): float {
		$gross = self::quote_money( $quote, 'customer_charge', 'price_with_vat', 'price' );
		if ( $gross <= 0 || ! wc_tax_enabled() ) {
			return $gross;
		}

		if ( class_exists( 'WC_Tax' ) ) {
			$rates = WC_Tax::get_shipping_tax_rates();
			if ( is_array( $rates ) && ! empty( $rates ) ) {
				$taxes = WC_Tax::calc_inclusive_tax( $gross, $rates );
				if ( is_array( $taxes ) ) {
					$tax = array_sum( array_map( 'floatval', $taxes ) );
					if ( $tax >= 0 && $tax < $gross ) {
						return round( $gross - $tax, 2 );
					}
				}
			}

			// No matching WooCommerce shipping tax means the full charge is tax-free.
			return $gross;
		}

		$net = self::positive_money_or_null( $quote['customer_charge_net'] ?? null );
		if ( null !== $net ) {
			return min( $gross, $net );
		}

		$vat_rate = self::normalized_vat_rate( $quote['vat_rate'] ?? null );
		return $vat_rate > 0 ? round( $gross / ( 1 + $vat_rate ), 2 ) : $gross;
	}

	public static function order_shipping_totals( WC_Order $order ): array {
		$net   = 0.0;
		$tax   = 0.0;
		$found = false;

		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( ! method_exists( $item, 'get_method_id' ) || 'dutt_same_hour_delivery' !== $item->get_method_id() ) {
				continue;
			}

			$found = true;
			$net  += method_exists( $item, 'get_total' ) ? (float) $item->get_total() : 0.0;
			$tax  += method_exists( $item, 'get_total_tax' ) ? (float) $item->get_total_tax() : 0.0;
		}

		if ( ! $found ) {
			$net = (float) $order->get_shipping_total();
			$tax = method_exists( $order, 'get_shipping_tax' ) ? (float) $order->get_shipping_tax() : 0.0;
		}

		$net = round( max( 0.0, $net ), 2 );
		$tax = round( max( 0.0, $tax ), 2 );

		return array(
			'net'   => $net,
			'tax'   => $tax,
			'gross' => round( $net + $tax, 2 ),
		);
	}

	public static function ownership_payload( WC_Order $order ): array {
		$totals = self::order_shipping_totals( $order );

		return array(
			'platform'                       => 'woocommerce',
			'shipping_charge_owner'          => self::SHIPPING_CHARGE_OWNER,
			'consumer_document_issuer'       => self::CONSUMER_DOCUMENT_ISSUER,
			'tax_system'                     => self::TAX_SYSTEM,
			'dutt_customer_receipt_required' => false,
			'shipping_total_net'             => $totals['net'],
			'shipping_tax'                   => $totals['tax'],
			'shipping_total_gross'           => $totals['gross'],
		);
	}

	private static function quote_money( array $quote, string ...$keys ): float {
		foreach ( $keys as $key ) {
			if ( isset( $quote[ $key ] ) && is_numeric( $quote[ $key ] ) ) {
				return round( max( 0.0, (float) $quote[ $key ] ), 2 );
			}
		}

		return 0.0;
	}

	private static function positive_money_or_null( $value ): ?float {
		if ( ! is_numeric( $value ) || (float) $value <= 0 ) {
			return null;
		}

		return round( (float) $value, 2 );
	}

	private static function normalized_vat_rate( $value ): float {
		if ( ! is_numeric( $value ) ) {
			return 0.0;
		}

		$rate = max( 0.0, (float) $value );
		return $rate > 1 ? $rate / 100 : $rate;
	}
}

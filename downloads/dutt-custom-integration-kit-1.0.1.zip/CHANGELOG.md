# Changelog

All notable changes to the DUTT Custom Integration Kit are documented here.

## 1.0.1 - 2026-08-11

- Validated the custom merchant flow with a real production pilot in Larissa: quote, preparation, dispatch, status, and cancellation.
- Increased the production client timeout to 90 seconds so cold starts do not produce an ambiguous delivery result.
- Added pilot status recovery for delivery and city identifiers after a delayed backend completion.
- Added a protected local pilot website and regression coverage for recovery and cancellation safety.

## 1.0.0 - 2026-08-11

- Added the production merchant API contract for custom websites.
- Added server-side Node.js and PHP adapters.
- Added signed webhook verification and replay-protection helpers.
- Added safe smoke testing, onboarding, security, fiscal, and production guides.
- Enforced the `custom` integration source so backend COD restrictions apply.
- Added EUR/Greece and merchant agreement/privacy-DPA payload validation.

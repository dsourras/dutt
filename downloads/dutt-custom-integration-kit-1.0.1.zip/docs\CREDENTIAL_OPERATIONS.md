# Credential Operations

## Issue a merchant key

1. Confirm the merchant identity, legal business details, website domain, and authorized technical contact.
2. Create or select the merchant in DUTT Admin.
3. Issue a new merchant-specific key through the approved admin operation.
4. Record only the key prefix/fingerprint in operational notes. The backend stores the key hash rather than the raw key.
5. Deliver the raw key once through an approved secure channel, separately from the integration ZIP.
6. Ask the developer to store it directly in the website secret manager and run the connection test.

Never reuse a key across merchants, development agencies, websites, or unrelated environments.

## Planned rotation

1. Issue a replacement key for the same merchant.
2. Keep the old key active during a short, agreed migration window.
3. Update the website secret and run the connection test with the new key.
4. Confirm normal quote/status operation.
5. Revoke the old key and verify that it returns an authorization failure.

Rotating one merchant's key must not modify or revoke any other merchant credential.

## Suspected compromise

1. Revoke the affected key immediately.
2. Review merchant API and webhook audit logs for the affected prefix, merchant, and time window.
3. Issue a new key only after the server secret storage and deployment path are confirmed clean.
4. Reconcile order creation, cancellation, refund, and settlement activity before closing the incident.

## Webhook-secret rotation

Register the new webhook secret from the website backend and deploy the matching verifier configuration together. During a controlled rollout, support both secrets only for the shortest practical interval. Remove the old secret after a signed test event succeeds.

Do not send merchant keys or webhook secrets through source control, browser code, screenshots, ordinary support tickets, or public chat.

<?php
/**
 * Uninstall cleanup for DUTT Same Hour Delivery.
 *
 * Plugin settings and product eligibility metadata are removed on uninstall.
 * Historical WooCommerce order delivery metadata is intentionally preserved.
 *
 * @package DUTT_Same_Hour_Delivery
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$dutt_shd_setting_keys = array(
	'enabled',
	'api_mode',
	'quote_api_url',
	'connection_test_api_url',
	'create_delivery_api_url',
	'cancel_delivery_api_url',
	'merchant_overview_api_url',
	'merchant_key',
	'api_key',
	'api_timeout_seconds',
	'api_default_estimated_time',
	'store_name',
	'store_city',
	'store_address',
	'legal_name',
	'vat_number',
	'tax_office',
	'billing_address',
	'billing_city',
	'billing_postcode',
	'billing_email',
	'business_activity',
	// Legacy internal options from prototype builds; kept only for cleanup.
	'store_latitude',
	'store_longitude',
	'service_radius_km',
	'max_weight_kg',
	'max_length_cm',
	'max_width_cm',
	'max_height_cm',
	'vat_note',
	'customer_charge_policy',
	'free_delivery_threshold',
	'fixed_customer_charge',
	'preparation_minutes',
	'service_start',
	'service_end',
	'cash_on_delivery',
	'diagnostic_logging',
	'mock_rider_availability',
	'mock_estimated_time',
	'webhook_secret',
	'business_billing_block',
);

foreach ( $dutt_shd_setting_keys as $dutt_shd_key ) {
	delete_option( 'dutt_shd_' . $dutt_shd_key );
}

delete_option( 'dutt_shd_needs_zone_install' );
delete_option( 'dutt_shd_scanner_offset' );
delete_option( 'dutt_shd_category_eligibility' );
delete_option( 'dutt_shd_recent_logs' );

global $wpdb;

if ( $wpdb instanceof wpdb ) {
	$dutt_shd_product_meta_keys = array(
		'_dutt_eligibility',
		'_dutt_scanner_result',
		'_dutt_scanner_reason',
		'_dutt_scanned_at',
	);

	foreach ( $dutt_shd_product_meta_keys as $dutt_shd_meta_key ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time uninstall cleanup.
		$wpdb->delete(
			$wpdb->postmeta,
			array( 'meta_key' => $dutt_shd_meta_key ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-time uninstall cleanup.
			array( '%s' )
		);
	}

	$dutt_shd_shipping_settings_like = $wpdb->esc_like( 'woocommerce_dutt_same_hour_delivery_' ) . '%' . $wpdb->esc_like( '_settings' );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes dynamic shipping-instance settings during uninstall.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$dutt_shd_shipping_settings_like
		)
	);
}

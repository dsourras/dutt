<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Merchant_Support {
	const MENU_SLUG    = 'dutt-merchant-support';
	const NONCE_ACTION = 'dutt_shd_merchant_support';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 25 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_dutt_shd_support_create', array( __CLASS__, 'handle_create' ) );
		add_action( 'admin_post_dutt_shd_support_status', array( __CLASS__, 'handle_status' ) );
		add_action( 'wp_ajax_dutt_shd_support_poll', array( __CLASS__, 'handle_poll' ) );
		add_action( 'wp_ajax_dutt_shd_support_send', array( __CLASS__, 'handle_send' ) );
	}

	public static function add_menu(): void {
		add_submenu_page(
			DUTT_SHD_Onboarding::PARENT_MENU_SLUG,
			'Dutt Support',
			'Support',
			'manage_woocommerce',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function enqueue_assets(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin page routing.
		if ( self::MENU_SLUG !== sanitize_key( (string) ( $_GET['page'] ?? '' ) ) ) {
			return;
		}

		$style_path     = DUTT_SHD_PLUGIN_DIR . 'assets/admin-merchant-support.css';
		$script_path    = DUTT_SHD_PLUGIN_DIR . 'assets/admin-merchant-support.js';
		$style_version  = file_exists( $style_path ) ? (string) filemtime( $style_path ) : DUTT_SHD_VERSION;
		$script_version = file_exists( $script_path ) ? (string) filemtime( $script_path ) : DUTT_SHD_VERSION;

		wp_enqueue_style(
			'dutt-shd-merchant-support',
			plugins_url( 'assets/admin-merchant-support.css', DUTT_SHD_PLUGIN_FILE ),
			array(),
			$style_version
		);
		wp_enqueue_script(
			'dutt-shd-merchant-support',
			plugins_url( 'assets/admin-merchant-support.js', DUTT_SHD_PLUGIN_FILE ),
			array(),
			$script_version,
			true
		);
		wp_localize_script(
			'dutt-shd-merchant-support',
			'duttMerchantSupport',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
				'pollMs'  => 5000,
				'idleMs'  => 30000,
			)
		);
	}

	public static function support_url( array $context = array() ): string {
		$args = array( 'page' => self::MENU_SLUG );
		foreach ( array( 'thread', 'order_id', 'delivery_id', 'order_reference', 'merchant_id' ) as $key ) {
			if ( isset( $context[ $key ] ) && '' !== trim( (string) $context[ $key ] ) ) {
				$args[ $key ] = trim( (string) $context[ $key ] );
			}
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	public static function render_page(): void {
		self::assert_capability();
		$settings = DUTT_SHD_Settings::all();
		if ( empty( $settings['merchant_key'] ) ) {
			echo '<div class="wrap"><h1>Dutt Support</h1><div class="notice notice-warning inline"><p>Save a valid Merchant Key before using support.</p></div></div>';
			return;
		}

		$list_result = DUTT_SHD_API_Client::merchant_support(
			array(
				'action' => 'list_threads',
				'limit'  => 50,
			)
		);
		$threads     = ! empty( $list_result['success'] ) && is_array( $list_result['threads'] ?? null )
			? $list_result['threads']
			: array();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only conversation selection.
		$selected_id = sanitize_text_field( wp_unslash( (string) ( $_GET['thread'] ?? '' ) ) );
		if ( '' === $selected_id && ! empty( $threads[0]['thread_id'] ) ) {
			$selected_id = (string) $threads[0]['thread_id'];
		}

		$selected_thread = self::find_thread( $threads, $selected_id );
		$messages        = array();
		if ( $selected_thread ) {
			$message_result = DUTT_SHD_API_Client::merchant_support(
				array(
					'action'    => 'get_messages',
					'thread_id' => $selected_id,
					'limit'     => 50,
				)
			);
			if ( ! empty( $message_result['success'] ) && is_array( $message_result['messages'] ?? null ) ) {
				$messages = $message_result['messages'];
				DUTT_SHD_API_Client::merchant_support(
					array(
						'action'    => 'mark_read',
						'thread_id' => $selected_id,
					)
				);
			}
		}

		$context = self::request_context();
		echo '<div class="wrap dutt-support-wrap">';
		echo '<div class="dutt-support-heading"><div><h1>Dutt Support</h1><p>Direct communication with Dutt operations.</p></div><button type="button" class="button button-primary" data-dutt-new-thread>New conversation</button></div>';
		self::render_notice();
		if ( empty( $list_result['success'] ) ) {
			echo '<div class="notice notice-error inline"><p>Support is temporarily unavailable. Please try again.</p></div>';
		}
		echo '<div class="dutt-support-layout">';
		self::render_thread_list( $threads, $selected_id );
		echo '<main class="dutt-support-main">';
		self::render_new_thread_form( $context, empty( $threads ) || ! empty( $context['order_reference'] ) );
		self::render_conversation( $selected_thread, $messages );
		echo '</main></div></div>';
	}

	private static function render_thread_list( array $threads, string $selected_id ): void {
		echo '<aside class="dutt-support-threads"><div class="dutt-support-section-title">Conversations</div>';
		if ( empty( $threads ) ) {
			echo '<p class="dutt-support-empty">No conversations yet.</p></aside>';
			return;
		}
		echo '<div class="dutt-support-thread-list">';
		foreach ( $threads as $thread ) {
			if ( ! is_array( $thread ) ) {
				continue;
			}
			$thread_id = (string) ( $thread['thread_id'] ?? '' );
			$url       = self::support_url( array( 'thread' => $thread_id ) );
			$active    = $thread_id === $selected_id ? ' is-active' : '';
			$unread    = (int) ( $thread['unread_for_merchant'] ?? 0 );
			echo '<a class="dutt-support-thread' . esc_attr( $active ) . '" href="' . esc_url( $url ) . '">';
			echo '<span class="dutt-support-thread-top"><strong>' . esc_html( (string) ( $thread['subject'] ?? 'Support' ) ) . '</strong>';
			if ( $unread > 0 ) {
				echo '<span class="dutt-support-unread">' . esc_html( (string) $unread ) . '</span>';
			}
			echo '</span>';
			echo '<span class="dutt-support-preview">' . esc_html( (string) ( $thread['last_message_preview'] ?? '' ) ) . '</span>';
			echo '<span class="dutt-support-thread-meta">' . esc_html( self::status_label( (string) ( $thread['status'] ?? '' ) ) ) . ' · ' . esc_html( self::format_time( (int) ( $thread['updated_at'] ?? 0 ) ) ) . '</span>';
			echo '</a>';
		}
		echo '</div></aside>';
	}

	private static function render_new_thread_form( array $context, bool $visible ): void {
		$subject          = ! empty( $context['order_reference'] ) ? 'Order ' . $context['order_reference'] : '';
		$default_category = ! empty( $context['delivery_id'] ) ? 'active_delivery' : 'other';
		$support_stage    = (string) ( $context['support_stage'] ?? 'setup' );
		echo $visible
			? '<section class="dutt-support-new" data-dutt-new-panel>'
			: '<section class="dutt-support-new" data-dutt-new-panel style="display:none">';
		echo '<div class="dutt-support-panel-header"><div><span class="dutt-support-kicker">NEW CONVERSATION</span><h2>Contact Dutt Support</h2></div><button type="button" class="button-link" data-dutt-close-new>Close</button></div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::NONCE_ACTION );
		echo '<input type="hidden" name="action" value="dutt_shd_support_create">';
		echo '<input type="hidden" name="client_thread_id" value="' . esc_attr( wp_generate_uuid4() ) . '">';
		echo '<input type="hidden" name="order_reference" value="' . esc_attr( (string) ( $context['order_reference'] ?? '' ) ) . '">';
		echo '<input type="hidden" name="external_order_id" value="' . esc_attr( (string) ( $context['external_order_id'] ?? '' ) ) . '">';
		echo '<input type="hidden" name="delivery_id" value="' . esc_attr( (string) ( $context['delivery_id'] ?? '' ) ) . '">';
		self::render_topic_select( $support_stage, 'dutt-support-new-message' );
		echo '<div class="dutt-support-form-grid"><label>Category<select name="category">';
		foreach ( self::categories() as $value => $label ) {
			$is_selected = $default_category === $value;
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $is_selected, true, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></label><label>Subject<input type="text" name="subject" maxlength="140" required value="' . esc_attr( $subject ) . '"></label></div>';
		echo '<label>Message<textarea id="dutt-support-new-message" name="message" rows="5" maxlength="3000" required></textarea></label>';
		if ( ! empty( $context['order_reference'] ) || ! empty( $context['delivery_id'] ) ) {
			echo '<div class="dutt-support-context">';
			if ( ! empty( $context['order_reference'] ) ) {
				echo '<span>Order <strong>' . esc_html( $context['order_reference'] ) . '</strong></span>';
			}
			if ( ! empty( $context['delivery_id'] ) ) {
				echo '<span>Delivery <strong>' . esc_html( $context['delivery_id'] ) . '</strong></span>';
			}
			echo '</div>';
		}
		echo '<button type="submit" class="button button-primary button-large">Start conversation</button></form></section>';
	}

	private static function render_conversation( ?array $thread, array $messages ): void {
		if ( ! $thread ) {
			echo '<section class="dutt-support-placeholder"><h2>Support when you need it</h2><p>Open a conversation and Dutt operations will receive it immediately.</p></section>';
			return;
		}

		$thread_id = (string) ( $thread['thread_id'] ?? '' );
		$status    = (string) ( $thread['status'] ?? 'open' );
		echo '<section class="dutt-support-conversation" data-dutt-thread="' . esc_attr( $thread_id ) . '">';
		echo '<header class="dutt-support-conversation-header"><div><span class="dutt-support-kicker">' . esc_html( self::category_label( (string) ( $thread['category'] ?? '' ) ) ) . '</span><h2>' . esc_html( (string) ( $thread['subject'] ?? 'Support' ) ) . '</h2>';
		$references = array_filter(
			array(
				! empty( $thread['order_reference'] ) ? 'Order ' . $thread['order_reference'] : '',
				! empty( $thread['delivery_id'] ) ? 'Delivery ' . $thread['delivery_id'] : '',
			)
		);
		if ( $references ) {
			echo '<p>' . esc_html( implode( ' · ', $references ) ) . '</p>';
		}
		echo '</div>';
		$status_action = 'closed' === strtolower( $status ) ? 'reopen_thread' : 'close_thread';
		$status_label  = 'closed' === strtolower( $status ) ? 'Reopen' : 'Close';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::NONCE_ACTION );
		echo '<input type="hidden" name="action" value="dutt_shd_support_status"><input type="hidden" name="thread_id" value="' . esc_attr( $thread_id ) . '"><input type="hidden" name="support_action" value="' . esc_attr( $status_action ) . '"><button class="button" type="submit">' . esc_html( $status_label ) . '</button></form></header>';

		echo '<div class="dutt-support-messages" data-dutt-messages>';
		foreach ( $messages as $message ) {
			self::render_message( is_array( $message ) ? $message : array() );
		}
		echo '</div>';

		if ( 'closed' !== strtolower( $status ) ) {
			$delivery_status = (string) ( $thread['delivery_status'] ?? '' );
			$support_stage   = DUTT_SHD_Merchant_Support_Topics::stage( $delivery_status, ! empty( $thread['delivery_id'] ) );
			echo '<form class="dutt-support-composer" data-dutt-composer>';
			self::render_topic_select( $support_stage, 'dutt-support-reply-message' );
			echo '<textarea id="dutt-support-reply-message" name="message" rows="2" maxlength="3000" required placeholder="Write a message"></textarea><button type="submit" class="button button-primary">Send</button><span class="spinner"></span><span class="dutt-support-send-status" data-dutt-send-status aria-live="polite"></span></form>';
		} else {
			echo '<div class="dutt-support-closed">This conversation is closed.</div>';
		}
		echo '</section>';
	}

	private static function render_message( array $message ): void {
		$sender_type = strtolower( (string) ( $message['sender_type'] ?? '' ) );
		$class       = 'merchant' === $sender_type ? ' is-merchant' : ' is-support';
		$timestamp   = (int) ( $message['created_at'] ?? 0 );
		echo '<article class="dutt-support-message' . esc_attr( $class ) . '" data-message-id="' . esc_attr( (string) ( $message['message_id'] ?? '' ) ) . '" data-created-at="' . esc_attr( (string) $timestamp ) . '">';
		echo '<div class="dutt-support-message-label">' . esc_html( 'merchant' === $sender_type ? 'You' : 'Dutt Support' ) . ' · ' . esc_html( self::format_time( $timestamp ) ) . '</div>';
		echo '<div class="dutt-support-bubble">' . nl2br( esc_html( (string) ( $message['text'] ?? '' ) ) ) . '</div></article>';
	}

	public static function handle_create(): void {
		self::assert_capability();
		check_admin_referer( self::NONCE_ACTION );
		$client_thread_id = sanitize_text_field( wp_unslash( (string) ( $_POST['client_thread_id'] ?? '' ) ) );
		$result           = DUTT_SHD_API_Client::merchant_support(
			array(
				'action'            => 'create_thread',
				'client_thread_id'  => $client_thread_id,
				'client_message_id' => $client_thread_id,
				'category'          => sanitize_key( (string) ( $_POST['category'] ?? 'other' ) ),
				'subject'           => sanitize_text_field( wp_unslash( (string) ( $_POST['subject'] ?? '' ) ) ),
				'message'           => sanitize_textarea_field( wp_unslash( (string) ( $_POST['message'] ?? '' ) ) ),
				'order_reference'   => sanitize_text_field( wp_unslash( (string) ( $_POST['order_reference'] ?? '' ) ) ),
				'external_order_id' => sanitize_text_field( wp_unslash( (string) ( $_POST['external_order_id'] ?? '' ) ) ),
				'delivery_id'       => sanitize_text_field( wp_unslash( (string) ( $_POST['delivery_id'] ?? '' ) ) ),
				'source'            => 'woocommerce',
				'site_url'          => home_url(),
			)
		);
		$thread_id        = ! empty( $result['success'] ) ? (string) ( $result['thread']['thread_id'] ?? '' ) : '';
		self::redirect( $thread_id, ! empty( $result['success'] ) ? 'created' : (string) ( $result['reason'] ?? 'error' ) );
	}

	public static function handle_status(): void {
		self::assert_capability();
		check_admin_referer( self::NONCE_ACTION );
		$thread_id = sanitize_text_field( wp_unslash( (string) ( $_POST['thread_id'] ?? '' ) ) );
		$action    = sanitize_key( (string) ( $_POST['support_action'] ?? '' ) );
		if ( ! in_array( $action, array( 'close_thread', 'reopen_thread' ), true ) ) {
			self::redirect( $thread_id, 'invalid_action' );
		}
		$result = DUTT_SHD_API_Client::merchant_support(
			array(
				'action'    => $action,
				'thread_id' => $thread_id,
			)
		);
		self::redirect( $thread_id, ! empty( $result['success'] ) ? 'updated' : (string) ( $result['reason'] ?? 'error' ) );
	}

	public static function handle_poll(): void {
		self::assert_capability();
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		$thread_id = sanitize_text_field( wp_unslash( (string) ( $_POST['thread_id'] ?? '' ) ) );
		$after     = max( 0, (int) ( $_POST['after'] ?? 0 ) );
		$result    = DUTT_SHD_API_Client::merchant_support(
			array(
				'action'    => 'get_messages',
				'thread_id' => $thread_id,
				'after'     => $after,
				'limit'     => 100,
			)
		);
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'reason' => (string) ( $result['reason'] ?? 'poll_failed' ) ), 400 );
		}
		if ( ! empty( $result['messages'] ) ) {
			DUTT_SHD_API_Client::merchant_support(
				array(
					'action'    => 'mark_read',
					'thread_id' => $thread_id,
				)
			);
		}
		wp_send_json_success(
			array(
				'messages' => is_array( $result['messages'] ?? null ) ? $result['messages'] : array(),
				'thread'   => is_array( $result['thread'] ?? null ) ? $result['thread'] : array(),
			)
		);
	}

	public static function handle_send(): void {
		self::assert_capability();
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		$result = DUTT_SHD_API_Client::merchant_support(
			array(
				'action'            => 'send_message',
				'thread_id'         => sanitize_text_field( wp_unslash( (string) ( $_POST['thread_id'] ?? '' ) ) ),
				'client_message_id' => sanitize_text_field( wp_unslash( (string) ( $_POST['client_message_id'] ?? '' ) ) ),
				'message'           => sanitize_textarea_field( wp_unslash( (string) ( $_POST['message'] ?? '' ) ) ),
			)
		);
		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'reason' => (string) ( $result['reason'] ?? 'send_failed' ) ), 400 );
		}
		wp_send_json_success( $result );
	}

	private static function request_context(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only order context.
		$order_id = absint( $_GET['order_id'] ?? 0 );
		if ( $order_id > 0 && function_exists( 'wc_get_order' ) ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$delivery_id = (string) $order->get_meta( 'dutt_delivery_id' );
				return array(
					'order_reference'   => 'WC' . $order->get_order_number(),
					'external_order_id' => (string) $order->get_id(),
					'delivery_id'       => $delivery_id,
					'support_stage'     => DUTT_SHD_Merchant_Support_Topics::stage( (string) $order->get_meta( 'dutt_status' ), '' !== $delivery_id ),
				);
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only support context.
		$delivery_id = sanitize_text_field( wp_unslash( (string) ( $_GET['delivery_id'] ?? '' ) ) );
		return array(
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only support context.
			'order_reference'   => sanitize_text_field( wp_unslash( (string) ( $_GET['order_reference'] ?? '' ) ) ),
			'external_order_id' => '',
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only support context.
			'delivery_id'       => $delivery_id,
			'support_stage'     => DUTT_SHD_Merchant_Support_Topics::stage( '', '' !== $delivery_id ),
		);
	}

	private static function render_topic_select( string $stage, string $target_id ): void {
		echo '<label class="dutt-support-topic">Common question<select data-dutt-support-topic data-target="' . esc_attr( $target_id ) . '">';
		echo '<option value="">Choose a question</option>';
		foreach ( DUTT_SHD_Merchant_Support_Topics::options( $stage ) as $topic ) {
			echo '<option value="' . esc_attr( (string) $topic['message'] ) . '" data-category="' . esc_attr( (string) $topic['category'] ) . '">' . esc_html( (string) $topic['label'] ) . '</option>';
		}
		echo '</select></label>';
	}

	private static function find_thread( array $threads, string $thread_id ): ?array {
		foreach ( $threads as $thread ) {
			if ( is_array( $thread ) && (string) ( $thread['thread_id'] ?? '' ) === $thread_id ) {
				return $thread;
			}
		}
		return null;
	}

	private static function categories(): array {
		return array(
			'active_delivery' => 'Active delivery',
			'order'           => 'Order',
			'billing'         => 'Billing',
			'technical'       => 'Technical issue',
			'account'         => 'Account',
			'returns'         => 'Return',
			'other'           => 'Other',
		);
	}

	private static function category_label( string $category ): string {
		$categories = self::categories();
		return $categories[ $category ] ?? 'Support';
	}

	private static function status_label( string $status ): string {
		return 'closed' === strtolower( $status ) ? 'Closed' : 'Open';
	}

	private static function format_time( int $timestamp ): string {
		if ( $timestamp <= 0 ) {
			return '';
		}
		return wp_date( 'd M, H:i', (int) floor( $timestamp / 1000 ) );
	}

	private static function render_notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect status.
		$status = sanitize_key( (string) ( $_GET['support_status'] ?? '' ) );
		if ( '' === $status ) {
			return;
		}
		$success = in_array( $status, array( 'created', 'updated' ), true );
		echo '<div class="notice ' . ( $success ? 'notice-success' : 'notice-error' ) . ' is-dismissible"><p>' . esc_html( $success ? 'Support conversation updated.' : 'Support action failed. Please try again.' ) . '</p></div>';
	}

	private static function redirect( string $thread_id, string $status ): void {
		wp_safe_redirect(
			add_query_arg(
				array_filter(
					array(
						'page'           => self::MENU_SLUG,
						'thread'         => $thread_id,
						'support_status' => sanitize_key( $status ),
					)
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	private static function assert_capability(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access Dutt Support.', 'dutt-same-hour-delivery' ) );
		}
	}
}

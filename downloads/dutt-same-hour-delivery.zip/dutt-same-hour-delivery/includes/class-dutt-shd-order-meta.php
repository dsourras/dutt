<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Order_Meta {
	public static function init(): void {
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'save_order_meta' ), 20, 1 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'save_store_api_order_meta' ), 20, 1 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ), 20, 2 );
		add_filter( 'manage_woocommerce_page_wc-orders_columns', array( __CLASS__, 'add_orders_list_column' ), 40 );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( __CLASS__, 'render_orders_list_column' ), 10, 2 );
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_orders_list_column' ), 40 );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'render_legacy_orders_list_column' ), 10, 2 );
		add_action( 'admin_post_dutt_shd_ready_for_pickup', array( __CLASS__, 'handle_ready_for_pickup' ) );
		add_action( 'admin_post_dutt_shd_retry_delivery', array( __CLASS__, 'handle_retry_delivery' ) );
		add_action( 'admin_post_dutt_shd_cancel_delivery', array( __CLASS__, 'handle_cancel_delivery' ) );
		add_action( 'admin_post_dutt_shd_refresh_status', array( __CLASS__, 'handle_refresh_status' ) );
		add_action( 'admin_post_dutt_shd_create_return_delivery', array( __CLASS__, 'handle_create_return_delivery' ) );
		add_action( 'admin_post_dutt_shd_mock_create_delivery', array( __CLASS__, 'handle_retry_delivery' ) );
		add_action( 'admin_post_dutt_shd_mock_cancel_delivery', array( __CLASS__, 'handle_cancel_delivery' ) );
	}

	public static function add_orders_list_column( array $columns ): array {
		$updated = array();
		$added   = false;

		foreach ( $columns as $key => $label ) {
			$updated[ $key ] = $label;

			if ( ! $added && in_array( $key, array( 'order_status', 'status' ), true ) ) {
				$updated['dutt_shd_delivery_status'] = 'Dutt';
				$added                               = true;
			}
		}

		if ( ! $added ) {
			$updated['dutt_shd_delivery_status'] = 'Dutt';
		}

		return $updated;
	}

	public static function render_orders_list_column( string $column, $order_or_id ): void {
		if ( 'dutt_shd_delivery_status' !== $column ) {
			return;
		}

		$order = $order_or_id instanceof WC_Order ? $order_or_id : wc_get_order( absint( $order_or_id ) );
		self::render_orders_list_status( $order );
	}

	public static function render_legacy_orders_list_column( string $column, int $post_id ): void {
		if ( 'dutt_shd_delivery_status' !== $column ) {
			return;
		}

		self::render_orders_list_status( wc_get_order( $post_id ) );
	}

	private static function render_orders_list_status( $order ): void {
		if ( ! $order instanceof WC_Order || ! self::is_dutt_order( $order ) ) {
			echo '&mdash;';
			return;
		}

		$status = (string) $order->get_meta( 'dutt_status' );
		if ( '' === $status ) {
			$status = 'awaiting_ready_for_pickup';
		}

		$tracking_url = class_exists( 'DUTT_SHD_Tracking' ) ? DUTT_SHD_Tracking::tracking_url( $order ) : '';
		$status_label = class_exists( 'DUTT_SHD_Status_Sync' ) ? DUTT_SHD_Status_Sync::status_label( $status ) : $status;
		$badge_class  = self::orders_list_status_class( $status );

		echo '<div class="dutt-shd-orders-list-status" style="min-width:130px;">';
		echo '<span style="display:inline-block;padding:2px 7px;border-radius:999px;font-size:11px;line-height:1.7;font-weight:600;' . esc_attr( $badge_class ) . '">';
		if ( '' !== $tracking_url ) {
			echo '<a href="' . esc_url( $tracking_url ) . '" target="_blank" rel="noopener noreferrer" style="color:inherit;text-decoration:none;">' . esc_html( $status_label ?: '-' ) . '</a>';
		} else {
			echo esc_html( $status_label ?: '-' );
		}
		echo '</span>';

		$reference = self::pickup_reference( $order );
		if ( '' !== $reference ) {
			echo '<br><small style="display:block;margin-top:4px;color:#646970;">' . esc_html( $reference ) . '</small>';
		}

		$return_status = trim( (string) $order->get_meta( 'dutt_return_status' ) );
		if ( '' !== $return_status ) {
			$return_label = class_exists( 'DUTT_SHD_Status_Sync' ) ? DUTT_SHD_Status_Sync::status_label( $return_status ) : $return_status;
			echo '<br><small style="display:block;margin-top:4px;color:#646970;">Return: ' . esc_html( $return_label ) . '</small>';
		}

		$error = trim( (string) $order->get_meta( 'dutt_last_error' ) );
		if ( '' !== $error ) {
			echo '<br><small style="display:block;margin-top:4px;color:#b32d2e;">' . esc_html( wp_trim_words( $error, 10, '...' ) ) . '</small>';
		}
		echo '</div>';
	}

	private static function orders_list_status_class( string $status ): string {
		$status = self::normalize_delivery_status( $status );

		if ( in_array( $status, array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ), true ) ) {
			return 'background:#edfaef;color:#0a5f1b;border:1px solid #8ed29a;';
		}

		if ( self::is_cancelled_delivery_status( $status ) || in_array( $status, array( 'failed', 'returned', 'return_completed' ), true ) ) {
			return 'background:#fcf0f1;color:#8a2424;border:1px solid #e0a3a3;';
		}

		if ( in_array( $status, array( 'accepted', 'assigned', 'picked_up', 'pending_dispatch', 'pending' ), true ) ) {
			return 'background:#eef4ff;color:#174a8b;border:1px solid #9dbdea;';
		}

		if ( in_array( $status, array( 'create_failed', 'cancel_failed' ), true ) ) {
			return 'background:#fff8e5;color:#7a4d00;border:1px solid #e0c36f;';
		}

		return 'background:#f6f7f7;color:#3c434a;border:1px solid #dcdcde;';
	}

	public static function save_order_meta( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		self::save_dutt_order_meta( $order );
	}

	public static function save_store_api_order_meta( WC_Order $order ): void {
		self::save_dutt_order_meta( $order );
	}

	private static function save_dutt_order_meta( WC_Order $order ): void {
		if ( ! self::order_uses_dutt( $order ) ) {
			return;
		}

		$quote          = WC()->session ? WC()->session->get( 'dutt_shd_last_quote' ) : array();
		$estimated_time = is_array( $quote ) && ! empty( $quote['estimated_time'] )
			? $quote['estimated_time']
			: DUTT_SHD_Settings::get( 'api_default_estimated_time' );

		$order->update_meta_data( 'dutt_selected', 'yes' );
		$order->update_meta_data( 'dutt_pickup_reference', self::pickup_reference( $order ) );
		$order->update_meta_data( 'dutt_quote_price', wc_format_decimal( self::get_quote_price( $order, $quote ), 2 ) );
		$order->update_meta_data( 'dutt_customer_charge', wc_format_decimal( self::get_customer_charge( $order, $quote ), 2 ) );
		$order->update_meta_data( 'dutt_store_contribution', wc_format_decimal( self::get_store_contribution( $quote ), 2 ) );
		$order->update_meta_data( 'dutt_charge_policy', is_array( $quote ) ? ( $quote['charge_policy'] ?? 'full_quote' ) : 'full_quote' );
		$order->update_meta_data( 'dutt_vat_rate', wc_format_decimal( self::quote_number( $quote, 'vat_rate', 0.0 ), 4 ) );
		$order->update_meta_data( 'dutt_quote_price_net', wc_format_decimal( self::quote_number( $quote, 'quote_price_net', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_quote_price_vat', wc_format_decimal( self::quote_number( $quote, 'quote_price_vat', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_customer_charge_net', wc_format_decimal( self::quote_number( $quote, 'customer_charge_net', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_customer_charge_vat', wc_format_decimal( self::quote_number( $quote, 'customer_charge_vat', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_store_contribution_net', wc_format_decimal( self::quote_number( $quote, 'store_contribution_net', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_store_contribution_vat', wc_format_decimal( self::quote_number( $quote, 'store_contribution_vat', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_settlement_due', wc_format_decimal( self::quote_number( $quote, 'settlement_due', self::get_quote_price( $order, $quote ) ), 2 ) );
		$order->update_meta_data( 'dutt_settlement_due_net', wc_format_decimal( self::quote_number( $quote, 'settlement_due_net', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_settlement_due_vat', wc_format_decimal( self::quote_number( $quote, 'settlement_due_vat', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_customer_receipt_required', self::quote_flag( $quote, 'customer_receipt_required' ) ? 'yes' : 'no' );
		$order->update_meta_data( 'dutt_customer_receipt_document_kind', is_array( $quote ) ? (string) ( $quote['customer_receipt_document_kind'] ?? '' ) : '' );
		$order->update_meta_data( 'dutt_merchant_invoice_required', self::quote_flag( $quote, 'merchant_invoice_required' ) ? 'yes' : 'no' );
		$order->update_meta_data( 'dutt_merchant_invoice_document_kind', is_array( $quote ) ? (string) ( $quote['merchant_invoice_document_kind'] ?? '' ) : '' );
		$order->update_meta_data( 'dutt_fiscal_billing_model', is_array( $quote ) ? sanitize_key( (string) ( $quote['fiscal_billing_model'] ?? '' ) ) : '' );
		$order->update_meta_data( 'dutt_merchant_invoice_amount', wc_format_decimal( self::quote_number( $quote, 'merchant_invoice_amount', self::get_quote_price( $order, $quote ) ), 2 ) );
		$order->update_meta_data( 'dutt_merchant_invoice_net', wc_format_decimal( self::quote_number( $quote, 'merchant_invoice_net', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_merchant_invoice_vat', wc_format_decimal( self::quote_number( $quote, 'merchant_invoice_vat', 0.0 ), 2 ) );
		$order->update_meta_data( 'dutt_fiscal_provider_ready', self::quote_flag( $quote, 'fiscal_provider_ready' ) ? 'yes' : 'no' );
		$woocommerce_shipping = DUTT_SHD_WooCommerce_Fiscal::order_shipping_totals( $order );
		$order->update_meta_data( 'dutt_woocommerce_shipping_net', wc_format_decimal( $woocommerce_shipping['net'], 2 ) );
		$order->update_meta_data( 'dutt_woocommerce_shipping_tax', wc_format_decimal( $woocommerce_shipping['tax'], 2 ) );
		$order->update_meta_data( 'dutt_woocommerce_shipping_gross', wc_format_decimal( $woocommerce_shipping['gross'], 2 ) );
		$order->update_meta_data( 'dutt_shipping_charge_owner', DUTT_SHD_WooCommerce_Fiscal::SHIPPING_CHARGE_OWNER );
		$order->update_meta_data( 'dutt_consumer_document_issuer', DUTT_SHD_WooCommerce_Fiscal::CONSUMER_DOCUMENT_ISSUER );
		$order->update_meta_data( 'dutt_shipping_tax_system', DUTT_SHD_WooCommerce_Fiscal::TAX_SYSTEM );
		$order->update_meta_data( 'dutt_estimated_time', $estimated_time );
		if ( is_array( $quote ) ) {
			$order->update_meta_data( 'dutt_quote_id', $quote['quote_id'] ?? '' );
			$order->update_meta_data( 'dutt_distance_km', $quote['distance_km'] ?? '' );
			$order->update_meta_data( 'dutt_pricing_version', $quote['pricing_version'] ?? '' );
			$order->update_meta_data( 'dutt_cart_subtotal', $quote['cart_subtotal'] ?? '' );
		}
		if ( '' === (string) $order->get_meta( 'dutt_status' ) ) {
			$order->update_meta_data( 'dutt_status', 'awaiting_ready_for_pickup' );
		}
		$order->save();
	}

	public static function add_meta_box( $screen, $order_or_post ): void {
		$screens = array( 'shop_order' );
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$screens[] = wc_get_page_screen_id( 'shop-order' );
		}

		foreach ( array_unique( $screens ) as $screen_id ) {
			add_meta_box(
				'dutt-shd-delivery-info',
				'DUTT Delivery Info',
				array( __CLASS__, 'render_meta_box' ),
				$screen_id,
				'side',
				'high'
			);
		}
	}

	public static function render_meta_box( $post_or_order ): void {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID ?? 0 );
		if ( ! $order ) {
			echo '<p>No order found.</p>';
			return;
		}

		if ( ! self::is_dutt_order( $order ) ) {
			echo '<p>DUTT was not selected for this order.</p>';
			return;
		}

		$delivery_id = (string) $order->get_meta( 'dutt_delivery_id' );
		if ( '' === $delivery_id ) {
			$delivery_id = (string) $order->get_meta( 'mock_dutt_delivery_id' );
		}
		$tracking_url     = class_exists( 'DUTT_SHD_Tracking' ) ? DUTT_SHD_Tracking::tracking_url( $order ) : '';
		$status           = (string) $order->get_meta( 'dutt_status' );
		$status_synced_at = (string) $order->get_meta( 'dutt_status_synced_at' );
		$driver_name      = (string) $order->get_meta( 'dutt_driver_name' );
		$driver_phone     = (string) $order->get_meta( 'dutt_driver_phone' );
		$eta_pickup       = (string) $order->get_meta( 'dutt_eta_pickup' );
		$eta_delivery     = (string) $order->get_meta( 'dutt_eta_delivery' );
		$failure_reason   = (string) $order->get_meta( 'dutt_failure_reason' );
		$failure_stage    = (string) $order->get_meta( 'dutt_failure_stage' );
		$status_history   = $order->get_meta( 'dutt_status_history' );
		if ( ! is_array( $status_history ) ) {
			$status_history = array();
		}
		$last_error              = (string) $order->get_meta( 'dutt_last_error' );
		$estimated_time          = (string) $order->get_meta( 'dutt_estimated_time' );
		$price                   = (string) $order->get_meta( 'dutt_quote_price' );
		$customer_charge         = (string) $order->get_meta( 'dutt_customer_charge' );
		$store_contribution      = (string) $order->get_meta( 'dutt_store_contribution' );
		$charge_policy           = (string) $order->get_meta( 'dutt_charge_policy' );
		$quote_id                = (string) $order->get_meta( 'dutt_quote_id' );
		$distance_km             = (string) $order->get_meta( 'dutt_distance_km' );
		$pricing_version         = (string) $order->get_meta( 'dutt_pricing_version' );
		$pickup_reference        = self::pickup_reference( $order );
		$address                 = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() . ', ' . $order->get_shipping_city() . ' ' . $order->get_shipping_postcode() );
		$fallback_shipping_total = self::get_dutt_shipping_total( $order );
		$status                  = $status ?: 'awaiting_ready_for_pickup';
		$estimated_time          = $estimated_time ?: DUTT_SHD_Settings::get( 'api_default_estimated_time' );
		$price                   = '' !== $price ? $price : ( $fallback_shipping_total > 0 ? wc_format_decimal( $fallback_shipping_total, 2 ) : '' );
		$customer_charge         = '' !== $customer_charge ? $customer_charge : ( $fallback_shipping_total > 0 ? wc_format_decimal( $fallback_shipping_total, 2 ) : '' );
		$store_contribution      = '' !== $store_contribution ? $store_contribution : '0';
		$charge_policy           = $charge_policy ?: DUTT_SHD_Settings::get( 'customer_charge_policy' );
		$charge_policy_label     = class_exists( 'DUTT_SHD_Checkout' )
			? DUTT_SHD_Checkout::charge_policy_label( $charge_policy )
			: $charge_policy;
		$pricing_note            = class_exists( 'DUTT_SHD_Checkout' )
			? DUTT_SHD_Checkout::customer_pricing_note(
				array(
					'price'              => is_numeric( $price ) ? (float) $price : 0.0,
					'customer_charge'    => is_numeric( $customer_charge ) ? (float) $customer_charge : 0.0,
					'store_contribution' => is_numeric( $store_contribution ) ? (float) $store_contribution : 0.0,
					'charge_policy'      => $charge_policy,
				)
			)
			: '';

		echo '<p><strong>Pickup reference:</strong><br><span style="font-size:18px;font-weight:700;">' . esc_html( $pickup_reference ?: '-' ) . '</span></p>';
		echo '<p><strong>Delivery ID:</strong><br>' . esc_html( $delivery_id ?: '-' ) . '</p>';
		if ( $tracking_url ) {
			echo '<p><strong>Tracking:</strong><br><a href="' . esc_url( $tracking_url ) . '" target="_blank" rel="noopener noreferrer">Open Dutt tracking</a></p>';
		}
		if ( class_exists( 'DUTT_SHD_Merchant_Support' ) ) {
			$support_url = DUTT_SHD_Merchant_Support::support_url(
				array(
					'order_id'        => $order->get_id(),
					'delivery_id'     => $delivery_id,
					'order_reference' => 'WC' . $order->get_order_number(),
				)
			);
			echo '<p><a class="button" href="' . esc_url( $support_url ) . '">Contact Dutt Support</a></p>';
		}
		echo '<p><strong>Quote ID:</strong><br>' . esc_html( $quote_id ?: '-' ) . '</p>';
		$status_label = class_exists( 'DUTT_SHD_Status_Sync' ) ? DUTT_SHD_Status_Sync::status_label( $status ) : $status;
		echo '<p><strong>DUTT status:</strong><br>' . esc_html( $status_label ?: '-' ) . '</p>';
		echo '<p><strong>Last Dutt status sync:</strong><br>' . esc_html( $status_synced_at ?: '-' ) . '</p>';
		echo '<div style="border:1px solid #dcdcde;border-radius:6px;padding:10px;margin:12px 0;background:#fff;">';
		echo '<p style="margin-top:0;"><strong>DUTT tracking</strong></p>';
		echo '<p><strong>Driver:</strong><br>' . esc_html( $driver_name ?: '-' ) . ( $driver_phone ? '<br>' . esc_html( $driver_phone ) : '' ) . '</p>';
		echo '<p><strong>ETA pickup:</strong><br>' . esc_html( self::format_tracking_value( $eta_pickup ) ) . '</p>';
		echo '<p><strong>ETA delivery:</strong><br>' . esc_html( self::format_tracking_value( $eta_delivery ) ) . '</p>';
		if ( $failure_reason || $failure_stage ) {
			echo '<p><strong>Failure:</strong><br>' . esc_html( trim( $failure_reason . ( $failure_stage ? ' (' . $failure_stage . ')' : '' ) ) ) . '</p>';
		}
		if ( ! empty( $status_history ) ) {
			echo '<p><strong>History:</strong></p>';
			echo '<ul style="margin:0 0 0 16px;">';
			foreach ( array_slice( array_reverse( $status_history ), 0, 6 ) as $entry ) {
				if ( ! is_array( $entry ) ) {
					continue;
				}
				$entry_status = class_exists( 'DUTT_SHD_Status_Sync' )
					? DUTT_SHD_Status_Sync::status_label( (string) ( $entry['status'] ?? '' ) )
					: (string) ( $entry['status'] ?? '' );
				$entry_time   = self::format_tracking_value( (string) ( $entry['event_time'] ?? $entry['synced_at'] ?? '' ) );
				echo '<li>' . esc_html( trim( $entry_status . ( $entry_time && '-' !== $entry_time ? ' - ' . $entry_time : '' ) ) ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
		if ( $last_error ) {
			echo '<p><strong>Last error:</strong><br>' . esc_html( $last_error ) . '</p>';
		}
		echo '<p><strong>Estimated delivery time:</strong><br>' . esc_html( $estimated_time ?: '-' ) . '</p>';
		echo '<p><strong>Distance:</strong><br>' . esc_html( $distance_km ? $distance_km . ' km' : '-' ) . '</p>';
		echo '<p><strong>Pricing version:</strong><br>' . esc_html( $pricing_version ?: '-' ) . '</p>';
		echo '<p><strong>Customer address:</strong><br>' . esc_html( $address ?: '-' ) . '</p>';
		echo '<div style="border:1px solid #dcdcde;border-radius:6px;padding:10px;margin:12px 0;background:#f6f7f7;">';
		echo '<p style="margin-top:0;"><strong>DUTT pricing split</strong></p>';
		echo '<p><strong>DUTT quote:</strong><br>' . wp_kses_post( $price ? wc_price( (float) $price ) : '-' ) . '</p>';
		echo '<p><strong>Customer charged at checkout:</strong><br>' . wp_kses_post( '' !== $customer_charge ? wc_price( (float) $customer_charge ) : '-' ) . '</p>';
		echo '<p><strong>Store-paid amount:</strong><br>' . wp_kses_post( '' !== $store_contribution ? wc_price( (float) $store_contribution ) : '-' ) . '</p>';
		echo '<p><strong>Pricing policy:</strong><br>' . esc_html( $charge_policy_label ?: '-' ) . '</p>';
		if ( '' !== $pricing_note ) {
			echo '<p style="margin-bottom:0;"><em>' . esc_html( $pricing_note ) . '</em></p>';
		}
		echo '</div>';
		$operation_result      = (string) $order->get_meta( 'dutt_operation_result' );
		$operation_mode        = (string) $order->get_meta( 'dutt_operation_mode' );
		$settlement_status     = (string) $order->get_meta( 'dutt_settlement_status' );
		$merchant_charge_gross = (string) $order->get_meta( 'dutt_merchant_charge_gross' );
		$operation_note        = (string) $order->get_meta( 'dutt_operation_note' );
		if ( $operation_result || $settlement_status || $merchant_charge_gross ) {
			echo '<div style="border:1px solid #dcdcde;border-radius:6px;padding:10px;margin:12px 0;background:#fff;">';
			echo '<p style="margin-top:0;"><strong>DUTT settlement outcome</strong></p>';
			echo '<p><strong>Operation:</strong><br>' . esc_html( self::operation_result_label( $operation_result ) ) . '</p>';
			echo '<p><strong>Settlement status:</strong><br>' . esc_html( $settlement_status ?: '-' ) . '</p>';
			echo '<p><strong>Settlement mode:</strong><br>' . esc_html( $operation_mode ?: '-' ) . '</p>';
			echo '<p><strong>Merchant charge:</strong><br>' . wp_kses_post( '' !== $merchant_charge_gross ? wc_price( (float) $merchant_charge_gross ) : '-' ) . '</p>';
			if ( '' !== $operation_note ) {
				echo '<p style="margin-bottom:0;"><strong>Note:</strong><br>' . esc_html( $operation_note ) . '</p>';
			}
			echo '</div>';
		}

		$ready_url   = wp_nonce_url(
			admin_url( 'admin-post.php?action=dutt_shd_ready_for_pickup&order_id=' . $order->get_id() ),
			'dutt_shd_order_action_' . $order->get_id()
		);
		$cancel_url  = wp_nonce_url(
			admin_url( 'admin-post.php?action=dutt_shd_cancel_delivery&order_id=' . $order->get_id() ),
			'dutt_shd_order_action_' . $order->get_id()
		);
		$retry_url   = wp_nonce_url(
			admin_url( 'admin-post.php?action=dutt_shd_retry_delivery&order_id=' . $order->get_id() ),
			'dutt_shd_order_action_' . $order->get_id()
		);
		$refresh_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=dutt_shd_refresh_status&order_id=' . $order->get_id() ),
			'dutt_shd_order_action_' . $order->get_id()
		);

		if ( $delivery_id ) {
			echo '<p><a class="button" href="' . esc_url( $refresh_url ) . '">Refresh Dutt status</a></p>';
		}

		if ( ! $delivery_id ) {
			$label = self::can_retry_delivery( $status, $delivery_id ) ? 'Retry Dutt delivery' : 'Ready for Dutt pickup';
			echo '<p><a class="button button-primary" href="' . esc_url( self::can_retry_delivery( $status, $delivery_id ) ? $retry_url : $ready_url ) . '">' . esc_html( $label ) . '</a></p>';
		}
		if ( self::can_cancel_delivery( $status, $delivery_id ) ) {
			echo '<p><a class="button" href="' . esc_url( $cancel_url ) . '" onclick="return confirm(\'Cancel this Dutt delivery?\');">Cancel Dutt delivery</a></p>';
		}
		if ( $delivery_id && self::can_retry_delivery( $status, $delivery_id ) ) {
			echo '<p><a class="button" href="' . esc_url( $retry_url ) . '">Retry Dutt delivery</a></p>';
		}

		self::render_return_delivery_box( $order, $status, $delivery_id );
	}

	private static function render_return_delivery_box( WC_Order $order, string $status, string $delivery_id ): void {
		if ( '' === $delivery_id ) {
			return;
		}

		$return_delivery_id  = trim( (string) $order->get_meta( 'dutt_return_delivery_id' ) );
		$return_status       = trim( (string) $order->get_meta( 'dutt_return_status' ) );
		$return_reference    = trim( (string) $order->get_meta( 'dutt_return_pickup_reference' ) );
		$return_tracking_url = trim( (string) $order->get_meta( 'dutt_return_tracking_url' ) );
		$return_error        = trim( (string) $order->get_meta( 'dutt_return_last_error' ) );

		echo '<div style="border:1px solid #dcdcde;border-radius:6px;padding:10px;margin:12px 0;background:#fff;">';
		echo '<p style="margin-top:0;"><strong>DUTT return pickup</strong></p>';

		if ( '' !== $return_delivery_id ) {
			echo '<p><strong>Return Delivery ID:</strong><br>' . esc_html( $return_delivery_id ) . '</p>';
			echo '<p><strong>Return reference:</strong><br>' . esc_html( $return_reference ?: '-' ) . '</p>';
			echo '<p><strong>Return status:</strong><br>' . esc_html( $return_status ?: '-' ) . '</p>';
			if ( '' !== $return_tracking_url ) {
				echo '<p><strong>Return tracking:</strong><br><a href="' . esc_url( $return_tracking_url ) . '" target="_blank" rel="noopener noreferrer">Open Dutt tracking</a></p>';
			}
			echo '</div>';
			return;
		}

		if ( ! self::can_create_return_delivery( $status ) ) {
			if ( '' !== $return_error ) {
				echo '<p><strong>Last return error:</strong><br>' . esc_html( $return_error ) . '</p>';
			}
			echo '</div>';
			return;
		}

		$defaults   = self::return_delivery_defaults( $order );
		$return_url = wp_nonce_url(
			add_query_arg(
				array(
					'action'   => 'dutt_shd_create_return_delivery',
					'order_id' => $order->get_id(),
				),
				admin_url( 'admin-post.php' )
			),
			'dutt_shd_order_action_' . $order->get_id()
		);
		echo '<p><strong>Pickup:</strong><br>' . esc_html( trim( $defaults['pickup_name'] . ' - ' . $defaults['pickup_address'] . ', ' . $defaults['pickup_city'] ) ) . '</p>';
		echo '<p><strong>Return to:</strong><br>' . esc_html( trim( $defaults['delivery_name'] . ' - ' . $defaults['delivery_address'] . ', ' . $defaults['delivery_city'] ) ) . '</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( $return_url ) . '" onclick="return confirm(\'Create Dutt return pickup for this order?\');">Create Dutt return pickup</a></p>';
		if ( '' !== $return_error ) {
			echo '<p><strong>Last return error:</strong><br>' . esc_html( $return_error ) . '</p>';
		}
		echo '</div>';
	}

	private static function render_return_input( string $label, string $name, string $value ): void {
		$id = 'dutt_return_' . sanitize_key( $name );
		echo '<p><label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $label ) . '</strong></label><br>';
		echo '<input id="' . esc_attr( $id ) . '" type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" style="width:100%;"></p>';
	}

	public static function handle_ready_for_pickup(): void {
		$order = self::get_order_from_request();
		self::mark_ready_for_pickup( $order, true );
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' ) );
		exit;
	}

	public static function handle_retry_delivery(): void {
		$order = self::get_order_from_request();
		self::retry_delivery_for_order( $order );
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' ) );
		exit;
	}

	public static function handle_cancel_delivery(): void {
		$order = self::get_order_from_request();
		self::cancel_delivery_for_order( $order );
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' ) );
		exit;
	}

	public static function handle_refresh_status(): void {
		$order = self::get_order_from_request();
		self::refresh_status_for_order( $order );
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' ) );
		exit;
	}

	public static function handle_create_return_delivery(): void {
		$order = self::get_order_from_request();
		self::create_return_delivery_for_order( $order, self::return_request_from_request() );
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=wc-orders' ) );
		exit;
	}

	public static function auto_cancel_delivery_for_order( WC_Order $order, string $trigger = 'merchant_event' ): array {
		return self::perform_delivery_cancel( $order, $trigger, true );
	}

	private static function get_order_from_request(): WC_Order {
		$order_id = isset( $_REQUEST['order_id'] ) ? absint( $_REQUEST['order_id'] ) : 0;
		check_admin_referer( 'dutt_shd_order_action_' . $order_id );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to edit this order.', 'dutt-same-hour-delivery' ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_die( esc_html__( 'Order not found.', 'dutt-same-hour-delivery' ) );
		}
		return $order;
	}

	private static function return_request_from_request(): array {

		// The order action nonce is verified by get_order_from_request() before this method is called.
		$fields = array(
			'pickup_name',
			'pickup_phone',
			'pickup_email',
			'pickup_address',
			'pickup_city',
			'pickup_postcode',
			'delivery_name',
			'delivery_phone',
			'delivery_address',
			'delivery_city',
			'delivery_postcode',
			'reason',
		);
		$data   = array();
		foreach ( $fields as $field ) {
			$data[ $field ] = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		$data['notes'] = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		return $data;
	}

	private static function merge_return_data_with_defaults( WC_Order $order, array $return_data ): array {
		$defaults = self::return_delivery_defaults( $order );
		foreach ( $defaults as $key => $value ) {
			if ( ! isset( $return_data[ $key ] ) || '' === trim( (string) $return_data[ $key ] ) ) {
				$return_data[ $key ] = $value;
			}
		}

		if ( ! isset( $return_data['reason'] ) || '' === trim( (string) $return_data['reason'] ) ) {
			$return_data['reason'] = 'merchant_requested_return';
		}

		return $return_data;
	}

	private static function return_delivery_defaults( WC_Order $order ): array {
		$settings       = DUTT_SHD_Settings::all();
		$shipping_name  = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
		$billing_name   = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$shipping_phone = method_exists( $order, 'get_shipping_phone' ) ? (string) $order->get_shipping_phone() : '';
		$pickup_address = trim(
			( $order->get_shipping_address_1() ?: $order->get_billing_address_1() ) . ' ' .
			( $order->get_shipping_address_2() ?: $order->get_billing_address_2() )
		);

		return array(
			'pickup_name'      => $shipping_name ?: $billing_name,
			'pickup_phone'     => trim( $shipping_phone ?: (string) $order->get_billing_phone() ),
			'pickup_address'   => $pickup_address,
			'pickup_city'      => trim( (string) ( $order->get_shipping_city() ?: $order->get_billing_city() ) ),
			'pickup_postcode'  => trim( (string) ( $order->get_shipping_postcode() ?: $order->get_billing_postcode() ) ),
			'delivery_name'    => trim( (string) $settings['store_name'] ),
			'delivery_address' => trim( (string) $settings['store_address'] ),
			'delivery_city'    => trim( (string) $settings['store_city'] ),
			'notes'            => 'Return for ' . self::pickup_reference( $order ),
		);
	}

	private static function can_create_return_delivery( string $status ): bool {
		$status = self::normalize_delivery_status( $status );
		return in_array(
			$status,
			array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ),
			true
		);
	}

	private static function order_uses_dutt( WC_Order $order ): bool {
		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( 'dutt_same_hour_delivery' === $item->get_method_id() ) {
				return true;
			}
		}
		return false;
	}

	private static function is_dutt_order( WC_Order $order ): bool {
		return 'yes' === $order->get_meta( 'dutt_selected' ) || self::order_uses_dutt( $order );
	}

	private static function mark_ready_for_pickup( WC_Order $order, bool $update_order_status ): void {
		if ( ! self::is_dutt_order( $order ) ) {
			self::log_order_event( 'warning', 'ready_for_pickup_ignored', $order, array( 'reason' => 'not_dutt_order' ) );
			return;
		}

		$order->update_meta_data( 'dutt_selected', 'yes' );
		$order->update_meta_data( 'dutt_ready_for_pickup_at', current_time( 'mysql' ) );
		self::log_order_event( 'info', 'ready_for_pickup_clicked', $order );

		if ( $update_order_status ) {
			$order->add_order_note( 'Marked ready for Dutt pickup.' );
		}

		self::create_delivery_for_order( $order );
	}

	private static function create_delivery_for_order( WC_Order $order ): void {
		if ( ! self::is_dutt_order( $order ) ) {
			self::log_order_event( 'warning', 'delivery_create_skipped', $order, array( 'reason' => 'not_dutt_order' ) );
			return;
		}

		$existing_delivery_id = (string) $order->get_meta( 'dutt_delivery_id' );
		if ( '' === $existing_delivery_id ) {
			$existing_delivery_id = (string) $order->get_meta( 'mock_dutt_delivery_id' );
		}
		if ( $existing_delivery_id ) {
			if ( '' === (string) $order->get_meta( 'dutt_tracking_url' ) && 'mock' !== DUTT_SHD_Settings::get( 'api_mode' ) ) {
				$existing_delivery = DUTT_SHD_API_Client::create_delivery( $order );
				if ( ! empty( $existing_delivery['success'] ) ) {
					if ( ! empty( $existing_delivery['tracking_url'] ) ) {
						$order->update_meta_data( 'dutt_tracking_url', esc_url_raw( (string) $existing_delivery['tracking_url'] ) );
					}
					if ( ! empty( $existing_delivery['tracking_token'] ) ) {
						$order->update_meta_data( 'dutt_tracking_token', sanitize_text_field( (string) $existing_delivery['tracking_token'] ) );
					}
				}
			}
			$order->update_meta_data( 'dutt_status', 'pending_dispatch' );
			$order->save();
			self::log_order_event(
				'info',
				'delivery_create_skipped',
				$order,
				array(
					'reason'      => 'already_has_delivery',
					'delivery_id' => $existing_delivery_id,
				)
			);
			return;
		}

		$delivery = DUTT_SHD_API_Client::create_delivery( $order );
		if ( empty( $delivery['success'] ) ) {
			$reason  = (string) ( $delivery['reason'] ?? 'create_delivery_failed' );
			$message = (string) ( $delivery['message'] ?? $reason );
			$order->update_meta_data( 'dutt_selected', 'yes' );
			$order->update_meta_data( 'dutt_status', 'create_failed' );
			$order->update_meta_data( 'dutt_last_error', $message );
			$order->add_order_note( 'Dutt delivery creation failed: ' . $message );
			$order->save();
			self::log_order_event(
				'error',
				'delivery_create_failed',
				$order,
				array(
					'reason'  => $reason,
					'message' => $message,
				)
			);
			return;
		}

		$delivery_id = (string) ( $delivery['delivery_id'] ?? '' );
		$order->update_meta_data( 'dutt_selected', 'yes' );
		$order->update_meta_data( 'dutt_delivery_id', $delivery_id );
		if ( 'mock' === DUTT_SHD_Settings::get( 'api_mode' ) ) {
			$order->update_meta_data( 'mock_dutt_delivery_id', $delivery_id );
		}
		$order->update_meta_data( 'dutt_status', (string) ( $delivery['status'] ?? 'pending_dispatch' ) );
		$order->update_meta_data( 'dutt_last_error', '' );
		$order->update_meta_data( 'dutt_delivery_created_at', current_time( 'mysql' ) );
		if ( ! empty( $delivery['city_id'] ) ) {
			$order->update_meta_data( 'dutt_city_id', (string) $delivery['city_id'] );
		}
		if ( ! empty( $delivery['order_number'] ) ) {
			$order->update_meta_data( 'dutt_order_number', (string) $delivery['order_number'] );
		}
		if ( ! empty( $delivery['pickup_reference'] ) ) {
			$order->update_meta_data( 'dutt_pickup_reference', (string) $delivery['pickup_reference'] );
		} elseif ( ! empty( $delivery['order_number'] ) ) {
			$order->update_meta_data( 'dutt_pickup_reference', (string) $delivery['order_number'] );
		}
		if ( ! empty( $delivery['estimated_time'] ) ) {
			$order->update_meta_data( 'dutt_estimated_time', (string) $delivery['estimated_time'] );
		}
		if ( ! empty( $delivery['tracking_url'] ) ) {
			$order->update_meta_data( 'dutt_tracking_url', esc_url_raw( (string) $delivery['tracking_url'] ) );
		}
		if ( ! empty( $delivery['tracking_token'] ) ) {
			$order->update_meta_data( 'dutt_tracking_token', sanitize_text_field( (string) $delivery['tracking_token'] ) );
		}
		$order->add_order_note( 'Dutt delivery created after merchant marked order ready for pickup.' );
		$order->save();
		self::log_order_event(
			'info',
			'delivery_created',
			$order,
			array(
				'delivery_id'       => $delivery_id,
				'status'            => (string) ( $delivery['status'] ?? 'pending_dispatch' ),
				'dutt_order_number' => (string) ( $delivery['order_number'] ?? '' ),
			)
		);
	}

	private static function create_return_delivery_for_order( WC_Order $order, array $return_data ): void {
		if ( ! self::is_dutt_order( $order ) ) {
			self::log_order_event( 'warning', 'return_delivery_skipped', $order, array( 'reason' => 'not_dutt_order' ) );
			return;
		}

		$return_data = self::merge_return_data_with_defaults( $order, $return_data );

		$existing_return_id = trim( (string) $order->get_meta( 'dutt_return_delivery_id' ) );
		if ( '' !== $existing_return_id ) {
			self::log_order_event(
				'info',
				'return_delivery_skipped',
				$order,
				array(
					'reason'             => 'already_has_return_delivery',
					'return_delivery_id' => $existing_return_id,
				)
			);
			return;
		}

		$delivery_id = self::delivery_id( $order );
		if ( '' === $delivery_id ) {
			$order->update_meta_data( 'dutt_return_last_error', 'Original Dutt delivery is missing.' );
			$order->save();
			self::log_order_event( 'warning', 'return_delivery_skipped', $order, array( 'reason' => 'missing_original_delivery' ) );
			return;
		}

		$status = self::normalize_delivery_status( (string) $order->get_meta( 'dutt_status' ) );
		if ( ! self::can_create_return_delivery( $status ) ) {
			$order->update_meta_data( 'dutt_return_last_error', 'Return pickup can be created only after the original delivery is completed.' );
			$order->save();
			self::log_order_event(
				'warning',
				'return_delivery_skipped',
				$order,
				array(
					'reason' => 'original_delivery_not_completed',
					'status' => $status,
				)
			);
			return;
		}

		$result = DUTT_SHD_API_Client::create_return_delivery( $order, $return_data );
		if ( empty( $result['success'] ) ) {
			$reason  = (string) ( $result['reason'] ?? 'return_delivery_failed' );
			$message = (string) ( $result['message'] ?? $reason );
			$order->update_meta_data( 'dutt_return_status', 'create_failed' );
			$order->update_meta_data( 'dutt_return_last_error', $message );
			$order->add_order_note( 'Dutt return pickup creation failed: ' . $message );
			$order->save();
			self::log_order_event(
				'error',
				'return_delivery_failed',
				$order,
				array(
					'reason'  => $reason,
					'message' => $message,
				)
			);
			return;
		}

		$return_delivery_id = (string) ( $result['delivery_id'] ?? '' );
		$order->update_meta_data( 'dutt_return_delivery_id', $return_delivery_id );
		$order->update_meta_data( 'dutt_return_status', (string) ( $result['status'] ?? 'pending_dispatch' ) );
		$order->update_meta_data( 'dutt_return_created_at', current_time( 'mysql' ) );
		$order->update_meta_data( 'dutt_return_last_error', '' );
		$order->update_meta_data( 'dutt_return_external_order_id', (string) ( $result['external_order_id'] ?? '' ) );
		$order->update_meta_data( 'dutt_return_external_hash', (string) ( $result['external_hash'] ?? '' ) );
		if ( ! empty( $result['city_id'] ) ) {
			$order->update_meta_data( 'dutt_return_city_id', (string) $result['city_id'] );
		}
		if ( ! empty( $result['pickup_reference'] ) ) {
			$order->update_meta_data( 'dutt_return_pickup_reference', (string) $result['pickup_reference'] );
		}
		if ( ! empty( $result['tracking_url'] ) ) {
			$order->update_meta_data( 'dutt_return_tracking_url', esc_url_raw( (string) $result['tracking_url'] ) );
		}
		if ( ! empty( $result['tracking_token'] ) ) {
			$order->update_meta_data( 'dutt_return_tracking_token', sanitize_text_field( (string) $result['tracking_token'] ) );
		}
		$order->add_order_note( 'Dutt return pickup created for this order.' );
		$order->save();
		self::log_order_event(
			'info',
			'return_delivery_created',
			$order,
			array(
				'return_delivery_id' => $return_delivery_id,
				'status'             => (string) ( $result['status'] ?? 'pending_dispatch' ),
			)
		);
	}

	private static function cancel_delivery_for_order( WC_Order $order ): void {
		self::perform_delivery_cancel( $order, 'manual_admin_cancel', false );
	}

	private static function retry_delivery_for_order( WC_Order $order ): void {
		if ( ! self::is_dutt_order( $order ) ) {
			self::log_order_event( 'warning', 'delivery_retry_skipped', $order, array( 'reason' => 'not_dutt_order' ) );
			return;
		}

		$status      = (string) $order->get_meta( 'dutt_status' );
		$delivery_id = self::delivery_id( $order );
		if ( ! self::can_retry_delivery( $status, $delivery_id ) ) {
			self::log_order_event(
				'warning',
				'delivery_retry_skipped',
				$order,
				array(
					'reason'      => 'not_retryable',
					'delivery_id' => $delivery_id,
				)
			);
			return;
		}

		self::archive_previous_delivery_id( $order, $delivery_id );
		$order->delete_meta_data( 'dutt_delivery_id' );
		$order->delete_meta_data( 'mock_dutt_delivery_id' );
		$order->delete_meta_data( 'dutt_tracking_url' );
		$order->delete_meta_data( 'dutt_tracking_token' );
		$order->update_meta_data( 'dutt_status', 'retrying_dispatch' );
		$order->update_meta_data( 'dutt_last_error', '' );
		$order->update_meta_data( 'dutt_retry_count', max( 0, (int) $order->get_meta( 'dutt_retry_count' ) ) + 1 );
		$order->add_order_note( 'Retrying Dutt delivery creation from WooCommerce.' );
		$order->save();
		self::log_order_event( 'info', 'delivery_retry_started', $order, array( 'previous_delivery_id' => $delivery_id ) );

		self::create_delivery_for_order( $order );
	}

	private static function refresh_status_for_order( WC_Order $order ): void {
		if ( ! self::is_dutt_order( $order ) ) {
			self::log_order_event( 'warning', 'status_refresh_skipped', $order, array( 'reason' => 'not_dutt_order' ) );
			return;
		}

		$result = DUTT_SHD_API_Client::get_delivery_status( $order );
		if ( empty( $result['success'] ) ) {
			$reason  = (string) ( $result['reason'] ?? 'status_refresh_failed' );
			$message = (string) ( $result['message'] ?? $reason );
			$order->update_meta_data( 'dutt_last_error', $message );
			$order->save();
			self::log_order_event(
				'warning',
				'status_refresh_failed',
				$order,
				array(
					'reason'  => $reason,
					'message' => $message,
				)
			);
			return;
		}

		$status = (string) ( $result['status'] ?? '' );
		if ( '' !== $status ) {
			$order->update_meta_data( 'dutt_status', $status );
		}
		if ( ! empty( $result['city_id'] ) ) {
			$order->update_meta_data( 'dutt_city_id', (string) $result['city_id'] );
		}
		if ( ! empty( $result['tracking_url'] ) ) {
			$order->update_meta_data( 'dutt_tracking_url', esc_url_raw( (string) $result['tracking_url'] ) );
		}
		if ( ! empty( $result['tracking_token'] ) ) {
			$order->update_meta_data( 'dutt_tracking_token', sanitize_text_field( (string) $result['tracking_token'] ) );
		}
		$order->update_meta_data( 'dutt_status_synced_at', current_time( 'mysql' ) );
		$order->update_meta_data( 'dutt_status_last_payload', $result );
		$order->update_meta_data( 'dutt_last_error', '' );
		if ( class_exists( 'DUTT_SHD_Status_Sync' ) ) {
			DUTT_SHD_Status_Sync::save_tracking_payload( $order, $result );
		}
		$order->save();
		self::log_order_event( 'info', 'status_refresh_synced', $order, array( 'status' => $status ) );
	}

	private static function archive_previous_delivery_id( WC_Order $order, string $delivery_id ): void {
		if ( '' === $delivery_id ) {
			return;
		}

		$history = $order->get_meta( 'dutt_previous_delivery_ids' );
		if ( ! is_array( $history ) ) {
			$history = array();
		}

		$history[] = array(
			'delivery_id' => $delivery_id,
			'city_id'     => (string) $order->get_meta( 'dutt_city_id' ),
			'status'      => (string) $order->get_meta( 'dutt_status' ),
			'archived_at' => current_time( 'mysql' ),
		);

		$order->update_meta_data( 'dutt_previous_delivery_ids', array_slice( $history, -10 ) );
	}

	private static function delivery_id( WC_Order $order ): string {
		$delivery_id = (string) $order->get_meta( 'dutt_delivery_id' );
		if ( '' === $delivery_id ) {
			$delivery_id = (string) $order->get_meta( 'mock_dutt_delivery_id' );
		}

		return trim( $delivery_id );
	}

	private static function can_cancel_delivery( string $status, string $delivery_id ): bool {
		if ( '' === $delivery_id ) {
			return false;
		}

		return ! self::is_terminal_delivery_status( $status );
	}

	private static function can_retry_delivery( string $status, string $delivery_id ): bool {
		$status = self::normalize_delivery_status( $status );
		if ( 'create_failed' === $status || self::is_cancelled_delivery_status( $status ) ) {
			return true;
		}

		return '' === $delivery_id && in_array( $status, array( 'cancel_failed', 'retrying_dispatch' ), true );
	}

	private static function is_terminal_delivery_status( string $status ): bool {
		$status = self::normalize_delivery_status( $status );
		if ( self::is_cancelled_delivery_status( $status ) ) {
			return true;
		}

		return in_array(
			$status,
			array( 'delivered', 'completed', 'complete', 'confirmed_by_user', 'failed', 'returned', 'return_completed' ),
			true
		);
	}

	private static function perform_delivery_cancel( WC_Order $order, string $trigger, bool $automatic ): array {
		if ( ! self::is_dutt_order( $order ) ) {
			self::log_order_event(
				'warning',
				'delivery_cancel_skipped',
				$order,
				array(
					'reason'  => 'not_dutt_order',
					'trigger' => $trigger,
				)
			);
			return array(
				'success' => false,
				'skipped' => true,
				'reason'  => 'not_dutt_order',
			);
		}

		$status      = self::normalize_delivery_status( (string) $order->get_meta( 'dutt_status' ) );
		$delivery_id = self::delivery_id( $order );

		if ( '' === $delivery_id ) {
			self::apply_no_dispatch_cancel_outcome( $order, $trigger, $automatic );
			self::log_order_event(
				'info',
				'delivery_cancel_skipped',
				$order,
				array(
					'reason'  => 'delivery_id_missing',
					'trigger' => $trigger,
				)
			);
			return array(
				'success'    => true,
				'skipped'    => true,
				'reason'     => 'delivery_id_missing',
				'status'     => 'cancelled_before_dispatch',
				'local_only' => true,
			);
		}

		if ( self::is_cancelled_delivery_status( $status ) ) {
			return array(
				'success'     => false,
				'skipped'     => true,
				'reason'      => 'already_cancelled',
				'status'      => $status,
				'delivery_id' => $delivery_id,
			);
		}

		$should_attempt_cancel = $automatic ? ! self::is_terminal_delivery_status( $status ) : self::can_cancel_delivery( $status, $delivery_id );
		if ( ! $should_attempt_cancel ) {
			if ( $automatic ) {
				$order->add_order_note( 'WooCommerce requested Dutt cancellation, but current Dutt status is ' . ( $status ?: 'unknown' ) . ' and requires manual follow-up.' );
				$order->save();
			}
			self::log_order_event(
				'warning',
				'delivery_cancel_skipped',
				$order,
				array(
					'reason'      => 'not_cancellable',
					'trigger'     => $trigger,
					'delivery_id' => $delivery_id,
					'status'      => $status,
				)
			);
			return array(
				'success'     => false,
				'skipped'     => true,
				'reason'      => 'not_cancellable',
				'status'      => $status,
				'delivery_id' => $delivery_id,
			);
		}

		$result = DUTT_SHD_API_Client::cancel_delivery( $order );
		if ( empty( $result['success'] ) ) {
			$reason  = (string) ( $result['reason'] ?? 'cancel_delivery_failed' );
			$message = (string) ( $result['message'] ?? $reason );
			if ( ! $automatic ) {
				$order->update_meta_data( 'dutt_status', 'cancel_failed' );
			}
			$order->update_meta_data( 'dutt_last_error', $message );
			$order->update_meta_data( 'dutt_last_cancel_trigger', $trigger );
			$order->update_meta_data( 'dutt_last_cancel_mode', $automatic ? 'automatic' : 'manual' );
			$order->add_order_note(
				$automatic
					? 'Automatic Dutt delivery cancellation failed after WooCommerce change: ' . $message
					: 'Dutt delivery cancellation failed: ' . $message
			);
			$order->save();
			self::log_order_event(
				'error',
				'delivery_cancel_failed',
				$order,
				array(
					'reason'      => $reason,
					'message'     => $message,
					'delivery_id' => $delivery_id,
					'trigger'     => $trigger,
				)
			);
			return array_merge(
				array(
					'success'     => false,
					'reason'      => $reason,
					'message'     => $message,
					'delivery_id' => $delivery_id,
				),
				$result
			);
		}

		$new_status = self::normalize_delivery_status( (string) ( $result['status'] ?? 'cancelled_by_admin' ) );
		$order->update_meta_data( 'dutt_status', $new_status );
		$order->update_meta_data( 'dutt_cancelled_at', current_time( 'mysql' ) );
		$order->update_meta_data( 'dutt_last_error', '' );
		$order->update_meta_data( 'dutt_last_cancel_trigger', $trigger );
		$order->update_meta_data( 'dutt_last_cancel_mode', $automatic ? 'automatic' : 'manual' );
		self::apply_cancel_operation_outcome( $order, $result, $new_status, $trigger, $automatic );
		$order->add_order_note( $automatic ? self::automatic_cancel_note( $trigger ) : 'Dutt delivery cancelled from WooCommerce.' );
		$order->save();
		$sync_result = DUTT_SHD_API_Client::sync_settlement_operation( $order );
		if ( empty( $sync_result['success'] ) ) {
			self::log_order_event(
				'warning',
				'merchant_settlement_sync_failed',
				$order,
				array(
					'trigger'     => $trigger,
					'delivery_id' => $delivery_id,
					'reason'      => (string) ( $sync_result['reason'] ?? '' ),
					'message'     => (string) ( $sync_result['message'] ?? '' ),
				)
			);
		}
		self::log_order_event(
			'info',
			'delivery_cancelled',
			$order,
			array(
				'delivery_id' => $delivery_id,
				'status'      => $new_status,
				'trigger'     => $trigger,
				'mode'        => $automatic ? 'automatic' : 'manual',
			)
		);

		return array(
			'success'         => true,
			'delivery_id'     => $delivery_id,
			'status'          => $new_status,
			'previous_status' => $status,
			'trigger'         => $trigger,
			'automatic'       => $automatic,
			'raw'             => $result['raw'] ?? array(),
		);
	}

	private static function automatic_cancel_note( string $trigger ): string {
		$notes = array(
			'woocommerce_cancelled_status' => 'Dutt delivery cancelled automatically after WooCommerce order was cancelled.',
			'woocommerce_full_refund'      => 'Dutt delivery cancelled automatically after full WooCommerce refund.',
		);

		return $notes[ $trigger ] ?? 'Dutt delivery cancelled automatically after WooCommerce change.';
	}

	private static function apply_no_dispatch_cancel_outcome( WC_Order $order, string $trigger, bool $automatic ): void {
		$order->update_meta_data( 'dutt_status', 'cancelled_before_dispatch' );
		$order->update_meta_data( 'dutt_cancelled_at', current_time( 'mysql' ) );
		$order->update_meta_data( 'dutt_last_error', '' );
		$order->update_meta_data( 'dutt_last_cancel_trigger', $trigger );
		$order->update_meta_data( 'dutt_last_cancel_mode', $automatic ? 'automatic' : 'manual' );
		$order->update_meta_data( 'dutt_operation_result', 'cancelled_before_dispatch' );
		$order->update_meta_data( 'dutt_operation_mode', $automatic ? 'automatic' : 'manual' );
		$order->update_meta_data( 'dutt_operation_stage', 'before_dispatch' );
		$order->update_meta_data( 'dutt_operation_source', $trigger );
		$order->update_meta_data( 'dutt_operation_note', self::automatic_cancel_note( $trigger ) );
		$order->update_meta_data( 'dutt_settlement_status', 'not_required' );
		$order->update_meta_data( 'dutt_merchant_charge_gross', wc_format_decimal( 0, 2 ) );
		$order->update_meta_data( 'dutt_driver_compensation_gross', wc_format_decimal( 0, 2 ) );
		$order->update_meta_data( 'dutt_merchant_due_after_operation', wc_format_decimal( 0, 2 ) );
		$order->update_meta_data( 'dutt_customer_charge_effective', wc_format_decimal( 0, 2 ) );
		$order->update_meta_data( 'dutt_store_contribution_effective', wc_format_decimal( 0, 2 ) );
		$order->update_meta_data( 'dutt_customer_receipt_required_effective', 'no' );
		$order->update_meta_data( 'dutt_merchant_invoice_required_effective', 'no' );
		$order->update_meta_data( 'dutt_merchant_ledger_required', 'no' );
		$order->update_meta_data( 'dutt_driver_settlement_required', 'no' );
		$order->update_meta_data(
			'dutt_cancel_policy_payload',
			array(
				'automatic'                => $automatic,
				'requiresReview'           => false,
				'reason'                   => 'delivery_not_created',
				'stage'                    => 'before_dispatch',
				'version'                  => 'merchant_cancellation_status_v1',
				'trigger'                  => $trigger,
				'ledgerAction'             => 'none',
				'merchantChargeGross'      => 0,
				'driverCompensationGross'  => 0,
				'settlementStatus'         => 'not_required',
				'driverSettlementRequired' => false,
				'merchantLedgerRequired'   => false,
				'createdAt'                => round( microtime( true ) * 1000 ),
			)
		);

		if ( 'woocommerce_full_refund' === $trigger ) {
			$order->update_meta_data( 'dutt_refund_review_status', 'not_required' );
			$order->update_meta_data( 'dutt_refund_settlement_impact', 'auto_cancelled_before_dispatch' );
			$order->update_meta_data( 'dutt_refund_auto_ledger_adjustment', 'yes' );
		}

		$order->add_order_note(
			$automatic
				? 'Dutt delivery cancellation recorded before dispatch. No active Dutt delivery had been created.'
				: 'Dutt delivery cancellation recorded before dispatch. No active Dutt delivery had been created.'
		);
		$order->save();
	}

	private static function apply_cancel_operation_outcome( WC_Order $order, array $result, string $status, string $trigger, bool $automatic ): void {
		$raw                          = is_array( $result['raw'] ?? null ) ? $result['raw'] : array();
		$policy                       = is_array( $raw['cancellation_policy'] ?? null ) ? $raw['cancellation_policy'] : array();
		$stage                        = sanitize_key( str_replace( '-', '_', strtolower( (string) ( $policy['stage'] ?? '' ) ) ) );
		$merchant_charge              = self::money_from_value( $policy['merchantChargeGross'] ?? '' );
		$driver_compensation          = self::money_from_value( $policy['driverCompensationGross'] ?? '' );
		$driver_compensation_pending  = self::meta_bool_value( $policy['driverCompensationPending'] ?? null );
		$customer_charge_effective    = self::money_from_value( $policy['customerChargeEffective'] ?? '' );
		$store_contribution_effective = self::money_from_value( $policy['storeContributionEffective'] ?? '' );
		if ( $merchant_charge > 0 && $customer_charge_effective <= 0 && $store_contribution_effective <= 0 ) {
			$customer_charge_effective    = self::money_from_value( $order->get_meta( 'dutt_customer_charge' ) );
			$store_contribution_effective = max( 0, round( $merchant_charge - $customer_charge_effective, 2 ) );
		}
		$merchant_ledger_required   = self::meta_bool_value( $policy['merchantLedgerRequired'] ?? null );
		$driver_settlement_required = self::meta_bool_value( $policy['driverSettlementRequired'] ?? null );
		$settlement_status          = sanitize_key( str_replace( '-', '_', strtolower( (string) ( $policy['settlementStatus'] ?? '' ) ) ) );
		$policy_automatic           = ! empty( $policy['automatic'] );
		$customer_receipt_required  = self::meta_bool_value( $policy['customerReceiptRequiredEffective'] ?? null );
		$merchant_invoice_required  = self::meta_bool_value( $policy['merchantInvoiceRequiredEffective'] ?? null );
		if ( '' === $customer_receipt_required ) {
			$customer_receipt_required = $customer_charge_effective > 0 ? 'yes' : 'no';
		}
		if ( '' === $merchant_invoice_required ) {
			$merchant_invoice_required = $store_contribution_effective > 0 ? 'yes' : 'no';
		}
		$operation_result = 'cancelled';
		if ( '' !== $stage ) {
			$operation_result = 'cancelled_' . $stage;
		}

		$order->update_meta_data( 'dutt_operation_result', $operation_result );
		$order->update_meta_data( 'dutt_operation_mode', $policy_automatic || $automatic ? 'automatic' : 'manual' );
		$order->update_meta_data( 'dutt_operation_stage', $stage );
		$order->update_meta_data( 'dutt_operation_source', $trigger );
		$order->update_meta_data( 'dutt_operation_note', self::automatic_cancel_note( $trigger ) );
		$order->update_meta_data( 'dutt_settlement_status', $settlement_status ?: 'pending' );
		$order->update_meta_data( 'dutt_merchant_charge_gross', wc_format_decimal( $merchant_charge, 2 ) );
		if ( 'yes' === $driver_compensation_pending ) {
			$order->delete_meta_data( 'dutt_driver_compensation_gross' );
			$order->update_meta_data( 'dutt_driver_compensation_pending', 'yes' );
		} else {
			$order->update_meta_data( 'dutt_driver_compensation_gross', wc_format_decimal( $driver_compensation, 2 ) );
			$order->update_meta_data( 'dutt_driver_compensation_pending', 'no' );
		}
		$order->update_meta_data( 'dutt_merchant_due_after_operation', wc_format_decimal( $merchant_charge, 2 ) );
		$order->update_meta_data( 'dutt_customer_charge_effective', wc_format_decimal( $customer_charge_effective, 2 ) );
		$order->update_meta_data( 'dutt_store_contribution_effective', wc_format_decimal( $store_contribution_effective, 2 ) );
		$order->update_meta_data( 'dutt_customer_receipt_required_effective', $customer_receipt_required );
		$order->update_meta_data( 'dutt_merchant_invoice_required_effective', $merchant_invoice_required );
		$order->update_meta_data( 'dutt_merchant_ledger_required', $merchant_ledger_required );
		$order->update_meta_data( 'dutt_driver_settlement_required', $driver_settlement_required );
		$order->update_meta_data( 'dutt_cancel_policy_payload', $policy );

		if ( 'woocommerce_full_refund' === $trigger ) {
			$order->update_meta_data( 'dutt_refund_review_status', 'not_required' );
			$order->update_meta_data( 'dutt_refund_settlement_impact', 'auto_cancelled_before_pickup' );
			$order->update_meta_data( 'dutt_refund_auto_ledger_adjustment', 'yes' );
		}
	}

	private static function normalize_delivery_status( string $status ): string {
		$status  = sanitize_key( str_replace( '-', '_', strtolower( trim( $status ) ) ) );
		$aliases = array(
			'canceled'             => 'cancelled',
			'canceled_by_admin'    => 'cancelled_by_admin',
			'canceled_by_merchant' => 'cancelled_by_merchant',
		);

		return $aliases[ $status ] ?? $status;
	}

	private static function money_from_value( $value ): float {
		return is_numeric( $value ) ? round( max( 0.0, (float) $value ), 2 ) : 0.0;
	}

	private static function meta_bool_value( $value ): string {
		if ( true === $value || 1 === $value || '1' === $value || 'yes' === $value || 'true' === $value ) {
			return 'yes';
		}
		if ( false === $value || 0 === $value || '0' === $value || 'no' === $value || 'false' === $value ) {
			return 'no';
		}
		return '';
	}

	private static function operation_result_label( string $value ): string {
		$value  = sanitize_key( str_replace( '-', '_', strtolower( trim( $value ) ) ) );
		$labels = array(
			''                              => '-',
			'cancelled'                     => 'Cancelled',
			'cancel_ignored_after_delivery' => 'Cancellation ignored after delivery',
			'cancelled_pending'             => 'Cancelled before dispatch',
			'cancelled_before_dispatch'     => 'Cancelled before dispatch',
			'cancelled_before_pickup'       => 'Cancelled before pickup',
			'cancelled_accepted'            => 'Cancelled after driver acceptance',
			'cancelled_after_acceptance'    => 'Cancelled after driver acceptance',
			'refund_manual_review'          => 'Refund requires manual review',
		);

		return $labels[ $value ] ?? ucwords( str_replace( '_', ' ', $value ) );
	}

	private static function is_cancelled_delivery_status( string $status ): bool {
		$status = self::normalize_delivery_status( $status );
		return 'cancelled' === $status || str_starts_with( $status, 'cancelled_' );
	}

	private static function is_post_pickup_or_terminal_status( string $status ): bool {
		$status = self::normalize_delivery_status( $status );
		if ( '' === $status ) {
			return false;
		}

		if ( self::is_terminal_delivery_status( $status ) ) {
			return true;
		}

		$post_pickup_statuses = array(
			'picked_up',
			'in_transit',
			'out_for_delivery',
			'approaching_delivery',
			'arrived_delivery',
			'returning_to_store',
			'return_in_progress',
			'undeliverable',
		);

		foreach ( $post_pickup_statuses as $candidate ) {
			if ( $status === $candidate || str_starts_with( $status, $candidate . '_' ) ) {
				return true;
			}
		}

		return false;
	}

	private static function log_order_event( string $level, string $event, WC_Order $order, array $context = array() ): void {
		if ( ! class_exists( 'DUTT_SHD_Logger' ) ) {
			return;
		}

		DUTT_SHD_Logger::log(
			$level,
			$event,
			array_merge(
				array(
					'order_id'         => $order->get_id(),
					'order_number'     => $order->get_order_number(),
					'pickup_reference' => self::pickup_reference( $order ),
					'dutt_status'      => (string) $order->get_meta( 'dutt_status' ),
				),
				$context
			)
		);
	}

	private static function format_tracking_value( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '-';
		}

		if ( is_numeric( $value ) ) {
			$timestamp = (float) $value;
			if ( $timestamp > 9999999999 ) {
				$timestamp = $timestamp / 1000;
			}
			return date_i18n( 'Y-m-d H:i', (int) $timestamp );
		}

		return $value;
	}

	private static function get_dutt_shipping_total( WC_Order $order ): float {
		$totals = DUTT_SHD_WooCommerce_Fiscal::order_shipping_totals( $order );
		return $totals['gross'];
	}

	private static function get_quote_price( WC_Order $order, $quote ): float {
		if ( is_array( $quote ) ) {
			foreach ( array( 'quote_price', 'price_with_vat', 'price' ) as $key ) {
				if ( isset( $quote[ $key ] ) && is_numeric( $quote[ $key ] ) ) {
					return (float) $quote[ $key ];
				}
			}
		}

		return self::get_dutt_shipping_total( $order );
	}

	private static function get_customer_charge( WC_Order $order, $quote ): float {
		if ( is_array( $quote ) && isset( $quote['customer_charge'] ) && is_numeric( $quote['customer_charge'] ) ) {
			return (float) $quote['customer_charge'];
		}

		return self::get_dutt_shipping_total( $order );
	}

	private static function get_store_contribution( $quote ): float {
		if ( is_array( $quote ) && isset( $quote['store_contribution'] ) && is_numeric( $quote['store_contribution'] ) ) {
			return (float) $quote['store_contribution'];
		}

		return 0.0;
	}

	private static function quote_number( $quote, string $key, float $fallback ): float {
		if ( is_array( $quote ) && isset( $quote[ $key ] ) && is_numeric( $quote[ $key ] ) ) {
			return (float) $quote[ $key ];
		}

		return $fallback;
	}

	private static function quote_flag( $quote, string $key ): bool {
		if ( ! is_array( $quote ) || ! array_key_exists( $key, $quote ) ) {
			return false;
		}

		return ! empty( $quote[ $key ] );
	}

	private static function pickup_reference( WC_Order $order ): string {
		$stored = trim( (string) $order->get_meta( 'dutt_pickup_reference' ) );
		if ( '' !== $stored ) {
			return $stored;
		}

		$dutt_order_number = trim( (string) $order->get_meta( 'dutt_order_number' ) );
		if ( '' !== $dutt_order_number ) {
			return $dutt_order_number;
		}

		$raw = trim( (string) $order->get_order_number() );
		if ( '' === $raw ) {
			$raw = (string) $order->get_id();
		}
		$raw = preg_replace( '/^#\s*/', '', $raw );
		if ( preg_match( '/^WC[-_\s]/i', $raw ) ) {
			return $raw;
		}
		return 'WC-' . $raw;
	}
}

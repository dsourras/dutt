<?php
/**
 * Private update provider for the DUTT WooCommerce plugin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DUTT_SHD_Updater {
	public const UPDATE_URI          = 'https://dutt.gr/plugin-updates/dutt-same-hour-delivery';
	public const MANIFEST_URL        = 'https://dutt.gr/plugin-updates/dutt-same-hour-delivery.json';
	private const PLUGIN_SLUG        = 'dutt-same-hour-delivery';
	private const PLUGIN_FILE        = 'dutt-same-hour-delivery/dutt-same-hour-delivery.php';
	private const MAX_MANIFEST_BYTES = 16384;
	private const MAX_PACKAGE_BYTES  = 20971520;

	/** @var array<string, mixed>|false|null */
	private static $manifest_cache = null;

	public static function init(): void {
		add_filter( 'update_plugins_dutt.gr', array( __CLASS__, 'filter_update' ), 10, 4 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify_download' ), 10, 4 );
	}

	/**
	 * Supplies WordPress with a normal plugin update offer.
	 *
	 * @param array<string, mixed>|false $update Existing update response.
	 * @param array<string, mixed>       $plugin_data Parsed plugin headers.
	 * @param string                     $plugin_file Plugin basename.
	 * @param array<int, string>         $locales Requested locales.
	 * @return array<string, mixed>|false
	 */
	public static function filter_update( $update, array $plugin_data, string $plugin_file, array $locales ) {
		unset( $locales );
		if (
			self::PLUGIN_FILE !== str_replace( '\\', '/', $plugin_file ) ||
			self::UPDATE_URI !== (string) ( $plugin_data['UpdateURI'] ?? '' )
		) {
			return $update;
		}

		$manifest = self::fetch_manifest();
		if ( false === $manifest || ! version_compare( $manifest['version'], DUTT_SHD_VERSION, '>' ) ) {
			return false;
		}

		return array(
			'id'           => self::UPDATE_URI,
			'slug'         => self::PLUGIN_SLUG,
			'version'      => $manifest['version'],
			'url'          => $manifest['url'],
			'package'      => $manifest['package'],
			'requires'     => $manifest['requires'],
			'tested'       => $manifest['tested'],
			'requires_php' => $manifest['requires_php'],
			'icons'        => array(
				'1x' => 'https://dutt.gr/favicon.png',
				'2x' => 'https://dutt.gr/logo.png',
			),
		);
	}

	/**
	 * Downloads the offered DUTT package and verifies its exact release checksum.
	 *
	 * @param mixed  $reply Existing pre-download result.
	 * @param string $package Package URL.
	 * @param mixed  $upgrader WordPress upgrader instance.
	 * @param array<string, mixed> $hook_extra Upgrade context.
	 * @return mixed
	 */
	public static function verify_download( $reply, string $package, $upgrader, array $hook_extra ) {
		unset( $upgrader, $hook_extra );
		if ( false !== $reply || ! self::is_dutt_package_url( $package ) ) {
			return $reply;
		}

		$manifest = self::fetch_manifest();
		if ( false === $manifest || $manifest['package'] !== $package ) {
			return new WP_Error( 'dutt_update_manifest_mismatch', 'The DUTT update package does not match the current release manifest.' );
		}

		if ( ! function_exists( 'download_url' ) ) {
			$file_api = ABSPATH . 'wp-admin/includes/file.php';
			if ( file_exists( $file_api ) ) {
				require_once $file_api;
			}
		}
		if ( ! function_exists( 'download_url' ) ) {
			return new WP_Error( 'dutt_update_download_unavailable', 'WordPress cannot download the DUTT update package.' );
		}

		$temp_file = download_url( $package, 60 );
		if ( is_wp_error( $temp_file ) ) {
			return $temp_file;
		}

		if ( ! self::package_matches_manifest( $temp_file, $manifest ) ) {
			self::delete_temp_file( $temp_file );
			return new WP_Error( 'dutt_update_checksum_mismatch', 'The DUTT update package failed integrity verification.' );
		}

		return $temp_file;
	}

	/** @return array<string, mixed>|false */
	public static function fetch_manifest() {
		if ( null !== self::$manifest_cache ) {
			return self::$manifest_cache;
		}

		$response = wp_remote_get(
			self::MANIFEST_URL,
			array(
				'timeout'             => 10,
				'redirection'         => 2,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => self::MAX_MANIFEST_BYTES,
				'headers'             => array(
					'Accept'     => 'application/json',
					'User-Agent' => 'DUTT-WooCommerce/' . DUTT_SHD_VERSION,
				),
			)
		);
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			self::$manifest_cache = false;
			return false;
		}

		$body = (string) wp_remote_retrieve_body( $response );
		if ( '' === $body || self::MAX_MANIFEST_BYTES < strlen( $body ) ) {
			self::$manifest_cache = false;
			return false;
		}

		$decoded              = json_decode( $body, true );
		self::$manifest_cache = self::normalize_manifest( is_array( $decoded ) ? $decoded : array() );
		return self::$manifest_cache;
	}

	/**
	 * @param array<string, mixed> $manifest Raw manifest.
	 * @return array<string, mixed>|false
	 */
	public static function normalize_manifest( array $manifest ) {
		$version = trim( (string) ( $manifest['version'] ?? '' ) );
		$package = trim( (string) ( $manifest['package'] ?? '' ) );
		$sha256  = strtolower( trim( (string) ( $manifest['sha256'] ?? '' ) ) );
		$size    = filter_var( $manifest['size_bytes'] ?? null, FILTER_VALIDATE_INT );
		$url     = trim( (string) ( $manifest['url'] ?? '' ) );

		if (
			self::UPDATE_URI !== (string) ( $manifest['id'] ?? '' ) ||
			self::PLUGIN_SLUG !== (string) ( $manifest['slug'] ?? '' ) ||
			1 !== preg_match( '/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/', $version ) ||
			! self::is_dutt_package_url( $package, $version ) ||
			1 !== preg_match( '/^[a-f0-9]{64}$/', $sha256 ) ||
			false === $size || 1 > $size || self::MAX_PACKAGE_BYTES < $size ||
			'https://dutt.gr/downloads/woocommerce-installation.html' !== $url
		) {
			return false;
		}

		$requires     = trim( (string) ( $manifest['requires'] ?? '' ) );
		$tested       = trim( (string) ( $manifest['tested'] ?? '' ) );
		$requires_php = trim( (string) ( $manifest['requires_php'] ?? '' ) );
		if (
			1 !== preg_match( '/^\d+\.\d+(?:\.\d+)?$/', $requires ) ||
			1 !== preg_match( '/^\d+\.\d+(?:\.\d+)?$/', $tested ) ||
			1 !== preg_match( '/^\d+\.\d+(?:\.\d+)?$/', $requires_php )
		) {
			return false;
		}

		return array(
			'id'           => self::UPDATE_URI,
			'slug'         => self::PLUGIN_SLUG,
			'version'      => $version,
			'url'          => $url,
			'package'      => $package,
			'sha256'       => $sha256,
			'size_bytes'   => (int) $size,
			'requires'     => $requires,
			'tested'       => $tested,
			'requires_php' => $requires_php,
		);
	}

	public static function is_dutt_package_url( string $package, string $version = '' ): bool {
		$parts = wp_parse_url( $package );
		if (
			! is_array( $parts ) ||
			'https' !== strtolower( (string) ( $parts['scheme'] ?? '' ) ) ||
			'dutt.gr' !== strtolower( (string) ( $parts['host'] ?? '' ) ) ||
			isset( $parts['user'] ) || isset( $parts['pass'] ) ||
			isset( $parts['query'] ) || isset( $parts['fragment'] ) || isset( $parts['port'] )
		) {
			return false;
		}

		$version_pattern = '' !== $version ? preg_quote( $version, '#' ) : '\\d+\\.\\d+\\.\\d+(?:[-+][0-9A-Za-z.-]+)?';
		return 1 === preg_match(
			'#^/downloads/dutt-same-hour-delivery-' . $version_pattern . '\\.zip$#',
			(string) ( $parts['path'] ?? '' )
		);
	}

	/** @param array<string, mixed> $manifest */
	public static function package_matches_manifest( string $filename, array $manifest ): bool {
		return is_file( $filename ) &&
			(int) filesize( $filename ) === (int) ( $manifest['size_bytes'] ?? 0 ) &&
			hash_equals( (string) ( $manifest['sha256'] ?? '' ), strtolower( (string) hash_file( 'sha256', $filename ) ) );
	}

	public static function reset_manifest_cache(): void {
		self::$manifest_cache = null;
	}

	private static function delete_temp_file( string $filename ): void {
		wp_delete_file( $filename );
	}
}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Onboarding {

	const MENU_SLUG        = 'dutt-same-hour-delivery';
	const PARENT_MENU_SLUG = 'dutt-same-hour-delivery';
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 10 );
		add_action( 'admin_head', array( __CLASS__, 'print_menu_icon_styles' ) );
	}

	public static function add_menu(): void {
		add_menu_page(
			'Dutt Same Hour Delivery',
			'Dutt',
			'manage_woocommerce',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' ),
			plugins_url( 'assets/icon-128x128.png', DUTT_SHD_PLUGIN_FILE ),
			56
		);

		add_submenu_page(
			self::PARENT_MENU_SLUG,
			'Dutt Same Hour Delivery',
			'Dutt Delivery',
			'manage_woocommerce',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function print_menu_icon_styles(): void {
		echo '<style>#toplevel_page_dutt-same-hour-delivery .wp-menu-image img{width:24px;height:24px;padding:4px 0 0;opacity:1;mix-blend-mode:screen;object-fit:contain}</style>';
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'dutt-same-hour-delivery' ) );
		}

		$steps = self::setup_steps();

		echo '<div class="wrap">';
		echo '<h1>DUTT Same Hour Delivery - Getting Started</h1>';
		echo '<p>Use this checklist to prepare a WooCommerce store for production DUTT deliveries. Complete the setup from top to bottom, then place one test order before going live.</p>';

		self::render_status_summary( $steps );
		self::render_steps_table( $steps );
		self::render_flow();
		self::render_support_notes();

		echo '</div>';
	}

	private static function setup_steps(): array {
		$settings = DUTT_SHD_Settings::all();

		return array(
			array(
				'title'       => 'Enable DUTT',
				'done'        => DUTT_SHD_Settings::is_enabled(),
				'description' => 'DUTT must be enabled before it can appear at checkout.',
				'action'      => 'Open settings',
				'url'         => self::settings_url(),
			),
			array(
				'title'       => 'Add Merchant Key',
				'done'        => '' !== trim( (string) ( $settings['merchant_key'] ?? '' ) ),
				'description' => 'Each merchant should use the private key generated from DUTT Admin. Do not reuse keys across stores.',
				'action'      => 'Open settings',
				'url'         => self::settings_url(),
			),
			array(
				'title'       => 'Test API connection',
				'done'        => '' !== trim( (string) ( $settings['merchant_key'] ?? '' ) ),
				'description' => 'After saving the Merchant Key, use the Connection test button in settings to verify the store can reach DUTT.',
				'action'      => 'Run connection test',
				'url'         => self::settings_url(),
			),
			array(
				'title'       => 'Complete store pickup details',
				'done'        => self::store_details_complete( $settings ),
				'description' => 'Set store name, pickup city and pickup address. The merchant does not need latitude or longitude.',
				'action'      => 'Open settings',
				'url'         => self::settings_url(),
			),
			array(
				'title'       => 'Enable DUTT shipping zone method',
				'done'        => self::has_enabled_shipping_method(),
				'description' => 'DUTT must be enabled inside at least one WooCommerce shipping zone.',
				'action'      => 'Open shipping zones',
				'url'         => admin_url( 'admin.php?page=wc-settings&tab=shipping' ),
			),
			array(
				'title'       => 'Choose eligible categories',
				'done'        => self::has_eligible_categories(),
				'description' => 'Approve the product categories that are suitable for same-hour Dutt delivery.',
				'action'      => 'Open eligible categories',
				'url'         => admin_url( 'admin.php?page=dutt-eligible-categories' ),
			),
			array(
				'title'       => 'Review products',
				'done'        => self::scanner_started(),
				'description' => 'Run the product scanner after category setup. Product-level overrides remain available for exceptions.',
				'action'      => 'Open product scanner',
				'url'         => admin_url( 'admin.php?page=dutt-product-scanner' ),
			),
			array(
				'title'       => 'Confirm customer/store pricing policy',
				'done'        => '' !== trim( (string) ( $settings['customer_charge_policy'] ?? '' ) ),
				'description' => 'Decide whether the customer pays the full quote, the store pays, free delivery applies over a threshold, or the customer pays a fixed amount.',
				'action'      => 'Open settings',
				'url'         => self::settings_url(),
			),
			array(
				'title'       => 'Place one test order',
				'done'        => self::has_dutt_order(),
				'description' => 'Test checkout with an eligible product and supported delivery address. Then mark the order Ready for Dutt pickup.',
				'action'      => 'Open orders',
				'url'         => admin_url( 'admin.php?page=wc-orders' ),
			),
			array(
				'title'       => 'Check logs if DUTT is hidden',
				'done'        => true,
				'description' => 'Logs show why DUTT appeared or stayed hidden: address, eligibility, package limits, service hours, API quote, or rider availability.',
				'action'      => 'Open logs',
				'url'         => admin_url( 'admin.php?page=dutt-logs' ),
			),
		);
	}

	private static function render_status_summary( array $steps ): void {
		$total   = count( $steps );
		$done    = count(
			array_filter(
				$steps,
				static function ( array $step ): bool {
					return ! empty( $step['done'] );
				}
			)
		);
		$ready   = $done >= $total - 1;
		$class   = $ready ? 'notice notice-success' : 'notice notice-warning';
		$message = $ready
			? 'This store looks ready for a controlled production test.'
			: 'Finish the required setup steps before enabling production traffic.';

		echo '<div class="' . esc_attr( $class ) . '"><p><strong>' . esc_html( $message ) . '</strong> ';
		echo esc_html( $done . ' of ' . $total . ' onboarding checks are complete.' );
		echo '</p></div>';
	}

	private static function render_steps_table( array $steps ): void {
		echo '<table class="widefat striped">';
		echo '<thead><tr><th style="width:90px;">Status</th><th>Step</th><th>Why it matters</th><th style="width:180px;">Action</th></tr></thead><tbody>';

		foreach ( $steps as $step ) {
			$done = ! empty( $step['done'] );
			echo '<tr>';
			echo '<td><span style="font-weight:700;color:' . esc_attr( $done ? '#008a20' : '#b32d2e' ) . ';">' . esc_html( $done ? 'Done' : 'Needed' ) . '</span></td>';
			echo '<td><strong>' . esc_html( $step['title'] ) . '</strong></td>';
			echo '<td>' . esc_html( $step['description'] ) . '</td>';
			echo '<td><a class="button button-secondary" href="' . esc_url( $step['url'] ) . '">' . esc_html( $step['action'] ) . '</a></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	private static function render_flow(): void {
		echo '<h2>Production order flow</h2>';
		echo '<ol>';
		echo '<li>Customer places a WooCommerce order and selects DUTT at checkout.</li>';
		echo '<li>The plugin stores quote, distance, customer charge, store-paid amount and estimated time on the WooCommerce order.</li>';
		echo '<li>No delivery is created immediately. The merchant prepares the order first.</li>';
		echo '<li>When the order is ready, the merchant opens the WooCommerce order and clicks <strong>Ready for Dutt pickup</strong>.</li>';
		echo '<li>The plugin creates the DUTT delivery, stores the delivery ID and tracking link, and receives status callbacks from DUTT.</li>';
		echo '<li>The merchant can cancel an active delivery or retry delivery creation from the same WooCommerce order when allowed.</li>';
		echo '</ol>';
	}

	private static function render_support_notes(): void {
		echo '<h2>Before going live</h2>';
		echo '<ul>';
		echo '<li>Confirm the Merchant Key belongs to the correct store.</li>';
		echo '<li>Confirm WooCommerce tax settings match how the merchant wants shipping charges displayed.</li>';
		echo '<li>Confirm eligible categories do not include large or unsuitable products.</li>';
		echo '<li>Place one real test order from checkout and verify the same pickup reference appears in WooCommerce, DUTT Admin and the driver app.</li>';
		echo '<li>Keep DUTT Logs open during the first production tests.</li>';
		echo '</ul>';
	}

	private static function settings_url(): string {
		return admin_url( 'admin.php?page=wc-settings&tab=shipping&section=' . DUTT_SHD_Settings::SECTION );
	}

	private static function store_details_complete( array $settings ): bool {
		return '' !== trim( (string) ( $settings['store_name'] ?? '' ) )
			&& '' !== trim( (string) ( $settings['store_city'] ?? '' ) )
			&& '' !== trim( (string) ( $settings['store_address'] ?? '' ) );
	}

	private static function has_enabled_shipping_method(): bool {
		if ( ! class_exists( 'WC_Shipping_Zones' ) ) {
			return false;
		}

		$zones = WC_Shipping_Zones::get_zones();
		foreach ( $zones as $zone_data ) {
			$zone = new WC_Shipping_Zone( (int) $zone_data['id'] );
			foreach ( $zone->get_shipping_methods() as $method ) {
				if ( 'dutt_same_hour_delivery' === $method->id && 'yes' === $method->enabled ) {
					return true;
				}
			}
		}

		$default_zone = new WC_Shipping_Zone( 0 );
		foreach ( $default_zone->get_shipping_methods() as $method ) {
			if ( 'dutt_same_hour_delivery' === $method->id && 'yes' === $method->enabled ) {
				return true;
			}
		}

		return false;
	}

	private static function has_eligible_categories(): bool {
		if ( ! class_exists( 'DUTT_SHD_Category_Eligibility' ) ) {
			return false;
		}

		return in_array( 'eligible', DUTT_SHD_Category_Eligibility::all(), true );
	}

	private static function scanner_started(): bool {
		return (int) get_option( DUTT_SHD_Scanner_Admin::OPTION_OFFSET, 0 ) > 0;
	}

	private static function has_dutt_order(): bool {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return false;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => 1,
				'return'     => 'ids',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Bounded onboarding check for one Dutt order.
				'meta_key'   => 'dutt_selected',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Bounded onboarding check for one Dutt order.
				'meta_value' => 'yes',
			)
		);

		return ! empty( $orders );
	}
}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Tracking {
	public static function init(): void {
		add_action( 'woocommerce_order_details_after_order_table', array( __CLASS__, 'render_customer_tracking' ), 20, 1 );
		add_action( 'woocommerce_email_after_order_table', array( __CLASS__, 'render_email_tracking' ), 20, 4 );
	}

	public static function tracking_url( WC_Order $order ): string {
		$url = esc_url_raw( (string) $order->get_meta( 'dutt_tracking_url' ) );
		return $url ?: '';
	}

	public static function tracking_button_html( WC_Order $order, bool $for_email = false ): string {
		$url = self::tracking_url( $order );
		if ( '' === $url ) {
			return '';
		}

		$style = $for_email
			? 'display:inline-block;padding:10px 14px;background:#111827;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:700;'
			: 'display:inline-block;margin-top:8px;padding:10px 14px;background:#111827;color:#ffffff;text-decoration:none;border-radius:6px;font-weight:700;';

		return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" style="' . esc_attr( $style ) . '">Παρακολούθηση αποστολής Dutt</a>';
	}

	public static function render_customer_tracking( WC_Order $order ): void {
		if ( ! self::is_dutt_order( $order ) ) {
			return;
		}

		$button = self::tracking_button_html( $order );
		if ( '' === $button ) {
			return;
		}

		echo '<section class="woocommerce-order-dutt-tracking" style="margin:24px 0;">';
		echo '<h2>Παρακολούθηση αποστολής</h2>';
		echo '<p>Μπορείτε να δείτε την τρέχουσα κατάσταση της αποστολής σας από το Dutt tracking.</p>';
		echo wp_kses_post( $button );
		echo '</section>';
	}

	public static function render_email_tracking( WC_Order $order, bool $sent_to_admin, bool $plain_text, $email ): void {
		if ( $sent_to_admin || ! self::is_dutt_order( $order ) ) {
			return;
		}

		$url = self::tracking_url( $order );
		if ( '' === $url ) {
			return;
		}

		if ( $plain_text ) {
			echo "\nΠαρακολούθηση αποστολής Dutt: " . esc_url_raw( $url ) . "\n";
			return;
		}

		echo '<h2>Παρακολούθηση αποστολής</h2>';
		echo '<p>Μπορείτε να δείτε την τρέχουσα κατάσταση της αποστολής σας από το Dutt tracking.</p>';
		echo wp_kses_post( self::tracking_button_html( $order, true ) );
	}

	private static function is_dutt_order( WC_Order $order ): bool {
		if ( 'yes' === $order->get_meta( 'dutt_selected' ) ) {
			return true;
		}

		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( 'dutt_same_hour_delivery' === $item->get_method_id() ) {
				return true;
			}
		}

		return false;
	}
}

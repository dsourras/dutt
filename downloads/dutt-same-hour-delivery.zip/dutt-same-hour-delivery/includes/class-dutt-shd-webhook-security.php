<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure validation helpers for signed Dutt merchant callbacks.
 */
class DUTT_SHD_Webhook_Security {
	const MAX_CALLBACK_AGE_SECONDS   = 300;
	const MAX_FUTURE_SKEW_SECONDS    = 60;
	const PROCESSED_EVENT_META_LIMIT = 50;

	public static function signature( string $secret, string $timestamp, string $raw_body ): string {
		return 'sha256=' . hash_hmac( 'sha256', $timestamp . '.' . $raw_body, $secret );
	}

	/**
	 * Returns an empty string when the callback authentication is valid.
	 */
	public static function callback_authentication_error(
		string $secret,
		string $timestamp,
		string $raw_body,
		string $signature,
		?int $now = null
	): string {
		if ( '' === trim( $timestamp ) ) {
			return 'missing_timestamp';
		}
		if ( ! preg_match( '/^[0-9]{1,12}$/', $timestamp ) ) {
			return 'invalid_timestamp';
		}

		$timestamp_value = (int) $timestamp;
		$now_value       = $now ?? time();
		if ( $timestamp_value < $now_value - self::MAX_CALLBACK_AGE_SECONDS ) {
			return 'stale_timestamp';
		}
		if ( $timestamp_value > $now_value + self::MAX_FUTURE_SKEW_SECONDS ) {
			return 'future_timestamp';
		}
		if ( '' === trim( $signature ) ) {
			return 'missing_signature';
		}

		$expected = self::signature( $secret, $timestamp, $raw_body );
		return hash_equals( $expected, $signature ) ? '' : 'invalid_signature';
	}

	/**
	 * Returns an empty string when the header and payload event IDs are valid.
	 */
	public static function event_id_error( string $header_event_id, string $payload_event_id ): string {
		$header_event_id  = trim( $header_event_id );
		$payload_event_id = trim( $payload_event_id );
		if ( '' === $header_event_id || '' === $payload_event_id ) {
			return 'missing_event_id';
		}
		if ( ! preg_match( '/^[A-Za-z0-9._:-]{8,128}$/', $header_event_id ) ) {
			return 'invalid_event_id';
		}
		return hash_equals( $payload_event_id, $header_event_id ) ? '' : 'event_id_mismatch';
	}

	public static function event_was_processed( array $events, string $event_id ): bool {
		foreach ( $events as $event ) {
			$stored_id = is_array( $event ) ? (string) ( $event['event_id'] ?? '' ) : (string) $event;
			if ( '' !== $stored_id && hash_equals( $stored_id, $event_id ) ) {
				return true;
			}
		}
		return false;
	}

	public static function remember_event( array $events, string $event_id, string $status, string $processed_at ): array {
		$remembered = array();
		foreach ( $events as $event ) {
			$stored_id = is_array( $event ) ? (string) ( $event['event_id'] ?? '' ) : (string) $event;
			if ( '' === $stored_id || hash_equals( $stored_id, $event_id ) ) {
				continue;
			}
			$remembered[] = $event;
		}

		$remembered[] = array(
			'event_id'     => $event_id,
			'status'       => $status,
			'processed_at' => $processed_at,
		);
		return array_slice( $remembered, -self::PROCESSED_EVENT_META_LIMIT );
	}

	public static function transition_is_allowed( string $current_status, string $incoming_status ): bool {
		$current_status  = self::normalize_status( $current_status );
		$incoming_status = self::normalize_status( $incoming_status );
		if ( '' === $current_status || $current_status === $incoming_status ) {
			return true;
		}

		$current_terminal_family = self::terminal_family( $current_status );
		if ( '' === $current_terminal_family ) {
			return true;
		}

		return self::terminal_family( $incoming_status ) === $current_terminal_family;
	}

	private static function terminal_family( string $status ): string {
		if ( in_array( $status, array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ), true ) ) {
			return 'delivered';
		}
		if ( 'cancelled' === $status || str_starts_with( $status, 'cancelled_' ) ) {
			return 'cancelled';
		}
		if ( in_array( $status, array( 'returned', 'return_completed', 'returned_to_sender', 'return_to_sender_completed' ), true ) ) {
			return 'returned';
		}
		return '';
	}

	private static function normalize_status( string $status ): string {
		$status = strtolower( trim( str_replace( '-', '_', $status ) ) );
		$status = preg_replace( '/[^a-z0-9_]/', '', $status );
		if ( 'canceled' === $status || str_starts_with( $status, 'canceled_' ) ) {
			return 'cancelled' . substr( $status, strlen( 'canceled' ) );
		}
		return $status;
	}
}

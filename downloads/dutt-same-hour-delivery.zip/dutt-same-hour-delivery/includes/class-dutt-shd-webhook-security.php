<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure validation helpers for signed Dutt merchant callbacks.
 */
class DUTT_SHD_Webhook_Security {
	const MAX_CALLBACK_AGE_SECONDS   = 300;
	const MAX_FUTURE_SKEW_SECONDS    = 60;
	const PROCESSED_EVENT_META_LIMIT = 50;

	public static function signature( string $secret, string $timestamp, string $raw_body ): string {
		return 'sha256=' . hash_hmac( 'sha256', $timestamp . '.' . $raw_body, $secret );
	}

	/**
	 * Returns an empty string when the callback authentication is valid.
	 */
	public static function callback_authentication_error(
		string $secret,
		string $timestamp,
		string $raw_body,
		string $signature,
		?int $now = null
	): string {
		if ( '' === trim( $timestamp ) ) {
			return 'missing_timestamp';
		}
		if ( ! preg_match( '/^[0-9]{1,12}$/', $timestamp ) ) {
			return 'invalid_timestamp';
		}

		$timestamp_value = (int) $timestamp;
		$now_value       = $now ?? time();
		if ( $timestamp_value < $now_value - self::MAX_CALLBACK_AGE_SECONDS ) {
			return 'stale_timestamp';
		}
		if ( $timestamp_value > $now_value + self::MAX_FUTURE_SKEW_SECONDS ) {
			return 'future_timestamp';
		}
		if ( '' === trim( $signature ) ) {
			return 'missing_signature';
		}

		$expected = self::signature( $secret, $timestamp, $raw_body );
		return hash_equals( $expected, $signature ) ? '' : 'invalid_signature';
	}

	/**
	 * Returns an empty string when the header and payload event IDs are valid.
	 */
	public static function event_id_error( string $header_event_id, string $payload_event_id ): string {
		$header_event_id  = trim( $header_event_id );
		$payload_event_id = trim( $payload_event_id );
		if ( '' === $header_event_id || '' === $payload_event_id ) {
			return 'missing_event_id';
		}
		if ( ! preg_match( '/^[A-Za-z0-9._:-]{8,128}$/', $header_event_id ) ) {
			return 'invalid_event_id';
		}
		return hash_equals( $payload_event_id, $header_event_id ) ? '' : 'event_id_mismatch';
	}

	/**
	 * Returns an empty string when the signed event name matches the payload.
	 */
	public static function event_name_error( string $header_event, string $payload_event ): string {
		$header_event  = trim( $header_event );
		$payload_event = trim( $payload_event );
		if ( '' === $header_event || '' === $payload_event ) {
			return 'missing_event_name';
		}
		if ( ! preg_match( '/^delivery\.[a-z0-9_.-]{3,64}$/', $header_event ) ) {
			return 'invalid_event_name';
		}
		return hash_equals( $payload_event, $header_event ) ? '' : 'event_name_mismatch';
	}

	public static function event_was_processed( array $events, string $event_id ): bool {
		foreach ( $events as $event ) {
			$stored_id = is_array( $event ) ? (string) ( $event['event_id'] ?? '' ) : (string) $event;
			if ( '' !== $stored_id && hash_equals( $stored_id, $event_id ) ) {
				return true;
			}
		}
		return false;
	}

	public static function remember_event( array $events, string $event_id, string $status, string $processed_at ): array {
		$remembered = array();
		foreach ( $events as $event ) {
			$stored_id = is_array( $event ) ? (string) ( $event['event_id'] ?? '' ) : (string) $event;
			if ( '' === $stored_id || hash_equals( $stored_id, $event_id ) ) {
				continue;
			}
			$remembered[] = $event;
		}

		$remembered[] = array(
			'event_id'     => $event_id,
			'status'       => $status,
			'processed_at' => $processed_at,
		);
		return array_slice( $remembered, -self::PROCESSED_EVENT_META_LIMIT );
	}

	public static function transition_is_allowed( string $current_status, string $incoming_status ): bool {
		$current_status  = self::normalize_status( $current_status );
		$incoming_status = self::normalize_status( $incoming_status );
		if ( '' === $current_status || $current_status === $incoming_status ) {
			return true;
		}

		$current_terminal_family = self::terminal_family( $current_status );
		if ( '' !== $current_terminal_family ) {
			return self::terminal_family( $incoming_status ) === $current_terminal_family;
		}

		if ( 'cancelled' === self::terminal_family( $incoming_status ) ) {
			return true;
		}

		$current_rank  = self::status_rank( $current_status );
		$incoming_rank = self::status_rank( $incoming_status );
		return null === $current_rank || null === $incoming_rank || $incoming_rank >= $current_rank;
	}

	private static function terminal_family( string $status ): string {
		if ( in_array( $status, array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ), true ) ) {
			return 'delivered';
		}
		if ( 'cancelled' === $status || str_starts_with( $status, 'cancelled_' ) ) {
			return 'cancelled';
		}
		if ( in_array( $status, array( 'returned', 'return_completed', 'returned_to_sender', 'return_to_sender_completed' ), true ) ) {
			return 'returned';
		}
		if ( in_array( $status, array( 'failed', 'delivery_failed' ), true ) ) {
			return 'failed';
		}
		return '';
	}

	private static function status_rank( string $status ): ?int {
		$groups = array(
			10  => array( 'pending', 'pending_dispatch', 'ready_for_pickup', 'awaiting_ready_for_pickup' ),
			20  => array( 'searching', 'searching_driver' ),
			30  => array( 'assigned', 'driver_assigned' ),
			40  => array( 'accepted', 'accepted_by_driver' ),
			50  => array( 'approaching_pickup', 'heading_to_pickup' ),
			60  => array( 'arrived_at_pickup', 'at_pickup' ),
			70  => array( 'picked_up', 'pickup_completed' ),
			80  => array( 'in_transit', 'approaching_delivery' ),
			90  => array( 'arrived_at_delivery', 'at_delivery' ),
			100 => array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ),
		);

		foreach ( $groups as $rank => $statuses ) {
			if ( in_array( $status, $statuses, true ) ) {
				return $rank;
			}
		}

		return null;
	}

	private static function normalize_status( string $status ): string {
		$status = strtolower( trim( str_replace( '-', '_', $status ) ) );
		$status = preg_replace( '/[^a-z0-9_]/', '', $status );
		if ( 'canceled' === $status || str_starts_with( $status, 'canceled_' ) ) {
			return 'cancelled' . substr( $status, strlen( 'canceled' ) );
		}
		return $status;
	}
}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Logger {
	const SOURCE        = 'dutt-same-hour-delivery';
	const OPTION_RECENT = 'dutt_shd_recent_logs';
	const MAX_RECENT    = 120;

	public static function debug( string $event, array $context = array() ): void {
		self::log( 'debug', $event, $context );
	}

	public static function info( string $event, array $context = array() ): void {
		self::log( 'info', $event, $context );
	}

	public static function warning( string $event, array $context = array() ): void {
		self::log( 'warning', $event, $context );
	}

	public static function error( string $event, array $context = array() ): void {
		self::log( 'error', $event, $context );
	}

	public static function log( string $level, string $event, array $context = array() ): void {
		if ( class_exists( 'DUTT_SHD_Settings' ) && 'yes' !== DUTT_SHD_Settings::get( 'diagnostic_logging' ) ) {
			return;
		}

		$level = in_array( $level, array( 'debug', 'info', 'notice', 'warning', 'error', 'critical' ), true ) ? $level : 'info';
		$event = sanitize_key( $event );
		if ( '' === $event ) {
			$event = 'general';
		}

		$context = self::sanitize_context( $context );
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->log(
				$level,
				self::format_message( $event, $context ),
				array_merge(
					array(
						'source' => self::SOURCE,
						'event'  => $event,
					),
					$context
				)
			);
		}

		self::append_recent( $level, $event, $context );
	}

	public static function recent(): array {
		$logs = get_option( self::OPTION_RECENT, array() );
		return is_array( $logs ) ? array_values( $logs ) : array();
	}

	public static function clear_recent(): void {
		delete_option( self::OPTION_RECENT );
	}

	private static function append_recent( string $level, string $event, array $context ): void {
		$logs   = self::recent();
		$logs[] = array(
			'time'    => current_time( 'mysql' ),
			'level'   => $level,
			'event'   => $event,
			'context' => $context,
		);

		if ( count( $logs ) > self::MAX_RECENT ) {
			$logs = array_slice( $logs, -self::MAX_RECENT );
		}

		update_option( self::OPTION_RECENT, $logs, false );
	}

	private static function format_message( string $event, array $context ): string {
		if ( empty( $context ) ) {
			return 'DUTT event: ' . $event;
		}

		$parts = array();
		foreach ( $context as $key => $value ) {
			if ( is_scalar( $value ) || null === $value ) {
				$parts[] = $key . '=' . ( null === $value ? 'null' : (string) $value );
			}
		}

		return 'DUTT event: ' . $event . ( $parts ? ' | ' . implode( ' ', $parts ) : '' );
	}

	private static function sanitize_context( array $context, int $depth = 0 ): array {
		if ( $depth > 3 ) {
			return array( 'truncated' => true );
		}

		$clean = array();
		foreach ( $context as $key => $value ) {
			$key = sanitize_key( (string) $key );
			if ( '' === $key ) {
				continue;
			}

			if ( self::is_sensitive_key( $key ) ) {
				$clean[ $key ] = '[redacted]';
				continue;
			}

			if ( is_array( $value ) ) {
				$clean[ $key ] = self::sanitize_context( $value, $depth + 1 );
				continue;
			}

			if ( is_bool( $value ) ) {
				$clean[ $key ] = $value;
			} elseif ( is_int( $value ) || is_float( $value ) ) {
				$clean[ $key ] = $value;
			} elseif ( null === $value ) {
				$clean[ $key ] = null;
			} else {
				$clean[ $key ] = self::sanitize_string( (string) $value );
			}
		}

		return $clean;
	}

	private static function is_sensitive_key( string $key ): bool {
		foreach ( array( 'key', 'secret', 'token', 'authorization', 'signature', 'password', 'phone', 'email' ) as $needle ) {
			if ( str_contains( $key, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	private static function sanitize_string( string $value ): string {
		$value = sanitize_text_field( $value );
		if ( strlen( $value ) > 300 ) {
			$value = substr( $value, 0, 300 ) . '...';
		}

		return $value;
	}
}

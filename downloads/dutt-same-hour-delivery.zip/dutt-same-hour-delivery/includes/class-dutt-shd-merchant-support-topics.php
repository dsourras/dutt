<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides local, stage-aware starter questions for merchant support.
 */
class DUTT_SHD_Merchant_Support_Topics {
	public static function stage( string $status, bool $has_delivery ): string {
		$status = strtolower( trim( str_replace( '-', '_', $status ) ) );

		if ( '' === $status ) {
			return $has_delivery ? 'active' : 'setup';
		}

		if ( str_starts_with( $status, 'return' ) || 'returned' === $status ) {
			return 'return';
		}

		if ( str_starts_with( $status, 'cancel' ) || in_array( $status, array( 'failed', 'undeliverable', 'refunded' ), true ) ) {
			return 'aftercare';
		}

		if ( in_array( $status, array( 'delivered', 'completed', 'complete' ), true ) ) {
			return 'completed';
		}

		if ( in_array( $status, array( 'picked_up', 'in_transit', 'out_for_delivery', 'approaching_delivery', 'arrived_delivery' ), true ) ) {
			return 'delivery';
		}

		if ( in_array( $status, array( 'accepted', 'assigned', 'approaching_pickup', 'arrived_pickup', 'at_pickup' ), true ) ) {
			return 'pickup';
		}

		if ( in_array( $status, array( 'awaiting_ready_for_pickup', 'ready_for_pickup', 'pending_dispatch', 'retrying_dispatch', 'created', 'pending' ), true ) ) {
			return 'pre_dispatch';
		}

		return $has_delivery ? 'active' : 'setup';
	}

	public static function options( string $stage ): array {
		$stage_options = array(
			'setup'        => array(
				self::topic( 'connection', 'Check my Dutt connection', 'Please check whether my Dutt connection is working correctly.', 'technical' ),
				self::topic( 'checkout', 'Dutt is not shown at checkout', 'Dutt delivery is not appearing as an option at checkout. Please check why.', 'technical' ),
				self::topic( 'merchant_key', 'Merchant Key setup', 'I need help checking my Merchant Key setup. Please do not display or repeat the key.', 'account' ),
			),
			'pre_dispatch' => array(
				self::topic( 'dispatch', 'Why has this delivery not been dispatched?', 'Why has this delivery not been dispatched yet?', 'active_delivery' ),
				self::topic( 'ready', 'Check Ready for pickup status', 'Please check whether Ready for pickup was received for this order.', 'active_delivery' ),
				self::topic( 'cancel', 'Cancellation status', 'Please explain the current cancellation status for this delivery.', 'order' ),
			),
			'pickup'       => array(
				self::topic( 'driver_pickup', 'Driver and pickup ETA', 'Please show me the current driver status and pickup ETA for this delivery.', 'active_delivery' ),
				self::topic( 'pickup_delay', 'Pickup is delayed', 'The pickup appears to be delayed. Please check the current status.', 'active_delivery' ),
				self::topic( 'cancel', 'Cancellation status', 'Please explain the current cancellation status for this delivery.', 'order' ),
			),
			'delivery'     => array(
				self::topic( 'delivery_eta', 'Live status and delivery ETA', 'Please show me the live status and delivery ETA for this delivery.', 'active_delivery' ),
				self::topic( 'address', 'Incorrect delivery address', 'The recipient delivery address may be incorrect. What is the current safe process for correcting it?', 'active_delivery' ),
				self::topic( 'cancel_return', 'Cancellation or return status', 'Please explain the current cancellation or return status for this delivery.', 'returns' ),
			),
			'return'       => array(
				self::topic( 'return_status', 'Product return status', 'Please show me the current product return status for this delivery.', 'returns' ),
				self::topic( 'return_charge', 'Return charge explanation', 'Please explain the stored return charge and settlement details for this delivery.', 'billing' ),
			),
			'completed'    => array(
				self::topic( 'completed_sync', 'Completed delivery status', 'Please verify that this completed delivery has been synchronized correctly.', 'order' ),
				self::topic( 'settlement', 'Charge and settlement explanation', 'Please explain the stored customer charge, merchant contribution and settlement status for this delivery.', 'billing' ),
				self::topic( 'refund', 'Refund status', 'Please explain the current refund status for this order.', 'returns' ),
			),
			'aftercare'    => array(
				self::topic( 'cancel_return', 'Cancellation or return status', 'Please explain the current cancellation or return status for this delivery.', 'returns' ),
				self::topic( 'refund', 'Refund status', 'Please explain the current refund status for this order.', 'returns' ),
				self::topic( 'settlement', 'Charge and settlement explanation', 'Please explain the stored customer charge, merchant contribution and settlement status for this delivery.', 'billing' ),
			),
			'active'       => array(
				self::topic( 'delivery_status', 'Current delivery status', 'Please show me the current status of this delivery.', 'active_delivery' ),
				self::topic( 'dispatch', 'Dispatch status', 'Please check the dispatch status for this delivery.', 'active_delivery' ),
				self::topic( 'cancel_return', 'Cancellation or return status', 'Please explain the current cancellation or return status for this delivery.', 'returns' ),
			),
		);

		$common = array(
			self::topic( 'callback', 'Callback or webhook status', 'Please check the latest callback or webhook status for my Dutt integration.', 'technical' ),
			self::topic( 'settlement_general', 'Billing or settlement question', 'I need an explanation of a billing or settlement entry.', 'billing' ),
			self::topic( 'checkout', 'Checkout delivery option', 'I need help with the Dutt delivery option at checkout.', 'technical' ),
			self::topic( 'other', 'Another question', 'I need help with another Dutt delivery issue.', 'other' ),
		);

		$options = array_merge( $stage_options[ $stage ] ?? $stage_options['active'], $common );
		$unique  = array();
		foreach ( $options as $option ) {
			$unique[ $option['id'] ] = $option;
		}

		return array_values( $unique );
	}

	private static function topic( string $id, string $label, string $message, string $category ): array {
		return compact( 'id', 'label', 'message', 'category' );
	}
}

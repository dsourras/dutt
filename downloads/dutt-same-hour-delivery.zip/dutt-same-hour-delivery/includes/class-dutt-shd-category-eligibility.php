<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Category_Eligibility {
	const OPTION = 'dutt_shd_category_eligibility';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 20 );
	}

	public static function add_menu(): void {
		add_submenu_page(
			DUTT_SHD_Onboarding::PARENT_MENU_SLUG,
			'Eligible Categories',
			'Eligible Categories',
			'manage_woocommerce',
			'dutt-eligible-categories',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function all(): array {
		$value = get_option( self::OPTION, array() );
		return is_array( $value ) ? $value : array();
	}

	public static function term_status( int $term_id ): string {
		$settings = self::all();
		$status   = $settings[ $term_id ] ?? '';
		return in_array( $status, DUTT_SHD_Eligibility_Service::statuses(), true ) ? $status : 'review';
	}

	public static function product_status( int $product_id ): array {
		$terms = get_the_terms( $product_id, 'product_cat' );
		if ( ! is_array( $terms ) || empty( $terms ) ) {
			return self::result( 'review', 'no_product_category' );
		}

		$direct_statuses = array();
		foreach ( $terms as $term ) {
			$direct_statuses[] = self::status_with_reason( self::term_status( (int) $term->term_id ), 'category_' . $term->slug );
		}

		$direct = self::resolve_statuses( $direct_statuses );
		if ( 'review' !== $direct['status'] || self::has_explicit_direct_status( $terms ) ) {
			return $direct;
		}

		$ancestor_statuses = array();
		foreach ( $terms as $term ) {
			$ancestors = get_ancestors( (int) $term->term_id, 'product_cat' );
			foreach ( $ancestors as $ancestor_id ) {
				$ancestor = get_term( (int) $ancestor_id, 'product_cat' );
				if ( ! $ancestor || is_wp_error( $ancestor ) ) {
					continue;
				}
				$ancestor_statuses[] = self::status_with_reason(
					self::term_status( (int) $ancestor_id ),
					'parent_category_' . $ancestor->slug
				);
			}
		}

		if ( $ancestor_statuses ) {
			return self::resolve_statuses( $ancestor_statuses );
		}

		return self::result( 'review', 'category_needs_review' );
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'dutt-same-hour-delivery' ) );
		}

		if ( isset( $_POST['dutt_shd_save_categories'] ) && check_admin_referer( 'dutt_shd_save_categories' ) ) {
			self::save_from_post();
			echo '<div class="notice notice-success"><p>DUTT category eligibility saved.</p></div>';
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		echo '<div class="wrap">';
		echo '<h1>DUTT Eligible Categories</h1>';
		echo '<p>Select which WooCommerce product categories are suitable for motorcycle delivery. Products in approved categories can use DUTT unless their weight or dimensions exceed the configured limits.</p>';
		echo '<form method="post">';
		wp_nonce_field( 'dutt_shd_save_categories' );
		echo '<table class="widefat striped">';
		echo '<thead><tr><th>Category</th><th>Products</th><th>DUTT status</th><th>Guidance</th></tr></thead><tbody>';

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			echo '<tr><td colspan="4">No WooCommerce product categories found.</td></tr>';
		} else {
			foreach ( $terms as $term ) {
				self::render_category_row( $term );
			}
		}

		echo '</tbody></table>';
		echo '<p>';
		submit_button( 'Save category eligibility', 'primary', 'dutt_shd_save_categories', false );
		echo '</p>';
		echo '</form>';
		echo '</div>';
	}

	private static function render_category_row( WP_Term $term ): void {
		$status = self::term_status( (int) $term->term_id );
		$name   = self::term_label( $term );
		echo '<tr>';
		echo '<td><strong>' . esc_html( $name ) . '</strong><br><code>' . esc_html( $term->slug ) . '</code></td>';
		echo '<td>' . esc_html( (string) $term->count ) . '</td>';
		echo '<td>';
		echo '<select name="dutt_category_status[' . esc_attr( (string) $term->term_id ) . ']">';
		foreach ( self::status_options() as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $status, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '</td>';
		echo '<td>' . esc_html( self::guidance_for_status( $status ) ) . '</td>';
		echo '</tr>';
	}

	private static function save_from_post(): void {

		if (
			! isset( $_POST['_wpnonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'dutt_shd_save_categories' )
		) {
			return;
		}

		$posted   = isset( $_POST['dutt_category_status'] ) && is_array( $_POST['dutt_category_status'] )
			? map_deep( wp_unslash( $_POST['dutt_category_status'] ), 'sanitize_text_field' )
			: array();
		$settings = array();
		foreach ( $posted as $term_id => $status ) {
			$term_id = absint( $term_id );
			$status  = wc_clean( (string) $status );
			if ( $term_id > 0 && in_array( $status, DUTT_SHD_Eligibility_Service::statuses(), true ) ) {
				$settings[ $term_id ] = $status;
			}
		}

		update_option( self::OPTION, $settings );
		if ( class_exists( 'WC_Cache_Helper' ) ) {
			WC_Cache_Helper::get_transient_version( 'shipping', true );
		}
	}

	private static function has_explicit_direct_status( array $terms ): bool {
		$settings = self::all();
		foreach ( $terms as $term ) {
			$term_id = (int) $term->term_id;
			if ( isset( $settings[ $term_id ] ) && in_array( $settings[ $term_id ], DUTT_SHD_Eligibility_Service::statuses(), true ) ) {
				return true;
			}
		}
		return false;
	}

	private static function resolve_statuses( array $statuses ): array {
		foreach ( $statuses as $status ) {
			if ( 'not_eligible' === $status['status'] ) {
				return $status;
			}
		}
		foreach ( $statuses as $status ) {
			if ( 'eligible' === $status['status'] ) {
				return $status;
			}
		}
		foreach ( $statuses as $status ) {
			if ( 'review' === $status['status'] ) {
				return $status;
			}
		}

		return self::result( 'review', 'category_needs_review' );
	}

	private static function status_with_reason( string $status, string $reason ): array {
		return self::result( $status, $reason );
	}

	private static function result( string $status, string $reason ): array {
		return array(
			'status' => $status,
			'reason' => $reason,
		);
	}

	private static function status_options(): array {
		return array(
			'eligible'     => 'Eligible for DUTT',
			'not_eligible' => 'Not eligible',
			'review'       => 'Needs review',
		);
	}

	private static function guidance_for_status( string $status ): string {
		if ( 'eligible' === $status ) {
			return 'DUTT can appear for products in this category, unless package limits fail.';
		}
		if ( 'not_eligible' === $status ) {
			return 'DUTT will not appear for products in this category.';
		}
		return 'DUTT will not appear until this category or product is approved.';
	}

	private static function term_label( WP_Term $term ): string {
		$ancestors = array_reverse( get_ancestors( (int) $term->term_id, 'product_cat' ) );
		$labels    = array();
		foreach ( $ancestors as $ancestor_id ) {
			$ancestor = get_term( (int) $ancestor_id, 'product_cat' );
			if ( $ancestor && ! is_wp_error( $ancestor ) ) {
				$labels[] = $ancestor->name;
			}
		}
		$labels[] = $term->name;
		return implode( ' > ', $labels );
	}
}

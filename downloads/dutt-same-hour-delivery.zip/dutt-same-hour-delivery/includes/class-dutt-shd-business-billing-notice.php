<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Business_Billing_Notice {
	public const REACTIVATION_MAX_MINUTES = 60;

	public static function normalize( array $billing ): array {
		$payment_url = trim( (string) ( $billing['payment_url'] ?? '' ) );
		$scheme      = strtolower( (string) wp_parse_url( $payment_url, PHP_URL_SCHEME ) );
		if ( 'https' !== $scheme ) {
			$payment_url = '';
		}

		$outstanding = (float) ( $billing['outstanding_amount'] ?? 0 );
		if ( ! is_finite( $outstanding ) || $outstanding < 0 ) {
			$outstanding = 0;
		}

		return array(
			'invoice_number'           => trim( (string) ( $billing['invoice_number'] ?? '' ) ),
			'due_date'                 => trim( (string) ( $billing['due_date'] ?? '' ) ),
			'outstanding_amount'       => number_format( $outstanding, 2, '.', '' ),
			'payment_url'              => $payment_url,
			'reactivation_max_minutes' => self::REACTIVATION_MAX_MINUTES,
		);
	}

	public static function from_api_response( int $status, array $data ): ?array {
		if ( 403 !== $status || 'business_billing_blocked' !== (string) ( $data['reason'] ?? '' ) ) {
			return null;
		}
		$billing = is_array( $data['billing'] ?? null ) ? $data['billing'] : array();
		return self::normalize( $billing );
	}

	public static function copy( string $locale ): array {
		$language = strtolower( substr( trim( $locale ), 0, 2 ) );
		$copy     = array(
			'el' => array(
				'title'        => 'Οι νέες αποστολές DUTT έχουν προσωρινά ανασταλεί',
				'message'      => 'Υπάρχει ληξιπρόθεσμο επαγγελματικό τιμολόγιο. Για αυτόν τον λόγο δεν μπορούν να καταχωρηθούν νέες αποστολές.',
				'reactivation' => 'Μετά την πλήρη εξόφληση, η υπηρεσία ενεργοποιείται αυτόματα μέσα σε έως μία ώρα.',
				'invoice'      => 'Τιμολόγιο',
				'amount'       => 'Οφειλόμενο ποσό',
				'pay'          => 'Προβολή και πληρωμή τιμολογίου',
			),
			'en' => array(
				'title'        => 'New DUTT deliveries are temporarily suspended',
				'message'      => 'A business invoice is overdue. For this reason, new deliveries cannot be submitted.',
				'reactivation' => 'After full payment, the service is restored automatically within up to one hour.',
				'invoice'      => 'Invoice',
				'amount'       => 'Amount due',
				'pay'          => 'View and pay invoice',
			),
			'es' => array(
				'title'        => 'Los nuevos envíos de DUTT están suspendidos temporalmente',
				'message'      => 'Hay una factura profesional vencida. Por este motivo, no se pueden registrar nuevos envíos.',
				'reactivation' => 'Tras el pago completo, el servicio se restablece automáticamente en un plazo máximo de una hora.',
				'invoice'      => 'Factura',
				'amount'       => 'Importe pendiente',
				'pay'          => 'Ver y pagar la factura',
			),
			'fr' => array(
				'title'        => 'Les nouvelles livraisons DUTT sont temporairement suspendues',
				'message'      => 'Une facture professionnelle est échue. Pour cette raison, aucune nouvelle livraison ne peut être enregistrée.',
				'reactivation' => 'Après le paiement intégral, le service est rétabli automatiquement dans un délai maximal d’une heure.',
				'invoice'      => 'Facture',
				'amount'       => 'Montant dû',
				'pay'          => 'Voir et payer la facture',
			),
			'de' => array(
				'title'        => 'Neue DUTT-Lieferungen sind vorübergehend gesperrt',
				'message'      => 'Eine Geschäftsrechnung ist überfällig. Daher können keine neuen Lieferungen eingestellt werden.',
				'reactivation' => 'Nach vollständiger Zahlung wird der Dienst innerhalb von höchstens einer Stunde automatisch wieder aktiviert.',
				'invoice'      => 'Rechnung',
				'amount'       => 'Offener Betrag',
				'pay'          => 'Rechnung ansehen und bezahlen',
			),
			'it' => array(
				'title'        => 'Le nuove consegne DUTT sono temporaneamente sospese',
				'message'      => 'Una fattura aziendale è scaduta. Per questo motivo non è possibile inserire nuove consegne.',
				'reactivation' => 'Dopo il pagamento completo, il servizio viene riattivato automaticamente entro un’ora al massimo.',
				'invoice'      => 'Fattura',
				'amount'       => 'Importo dovuto',
				'pay'          => 'Visualizza e paga la fattura',
			),
		);

		return $copy[ $language ] ?? $copy['en'];
	}
}

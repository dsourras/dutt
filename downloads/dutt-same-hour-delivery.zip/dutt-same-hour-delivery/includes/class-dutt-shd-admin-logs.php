<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Admin_Logs {
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 30 );
	}

	public static function add_menu(): void {
		add_submenu_page(
			DUTT_SHD_Onboarding::PARENT_MENU_SLUG,
			'DUTT Logs',
			'Logs',
			'manage_woocommerce',
			'dutt-logs',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'dutt-same-hour-delivery' ) );
		}

		if ( isset( $_POST['dutt_shd_clear_logs'] ) && check_admin_referer( 'dutt_shd_clear_logs' ) ) {
			DUTT_SHD_Logger::clear_recent();
			echo '<div class="notice notice-success"><p>DUTT recent logs cleared. WooCommerce log files are not deleted.</p></div>';
		}

		$selected_level = isset( $_GET['level'] ) ? sanitize_key( wp_unslash( $_GET['level'] ) ) : '';
		$logs           = DUTT_SHD_Logger::recent();
		if ( '' !== $selected_level ) {
			$logs = array_values(
				array_filter(
					$logs,
					static function ( array $row ) use ( $selected_level ): bool {
						return ( $row['level'] ?? '' ) === $selected_level;
					}
				)
			);
		}
		$logs = array_reverse( $logs );

		echo '<div class="wrap">';
		echo '<h1>DUTT Logs</h1>';
		echo '<p>Recent plugin diagnostics for checkout availability, quotes, delivery creation, connection tests and status callbacks. Full log files are also written through the WooCommerce logger.</p>';
		echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&source=' . DUTT_SHD_Logger::SOURCE ) ) . '">Open WooCommerce logs</a></p>';

		self::render_filters( $selected_level );
		self::render_clear_form();
		self::render_table( $logs );

		echo '</div>';
	}

	private static function render_filters( string $selected_level ): void {
		$levels = array(
			''         => 'All levels',
			'debug'    => 'Debug',
			'info'     => 'Info',
			'notice'   => 'Notice',
			'warning'  => 'Warning',
			'error'    => 'Error',
			'critical' => 'Critical',
		);

		echo '<form method="get" style="margin: 16px 0;">';
		echo '<input type="hidden" name="page" value="dutt-logs">';
		echo '<label for="dutt-log-level"><strong>Level:</strong> </label>';
		echo '<select id="dutt-log-level" name="level">';
		foreach ( $levels as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $selected_level, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> ';
		submit_button( 'Filter', 'secondary', '', false );
		echo '</form>';
	}

	private static function render_clear_form(): void {
		echo '<form method="post" style="margin: 16px 0;">';
		wp_nonce_field( 'dutt_shd_clear_logs' );
		submit_button( 'Clear recent logs', 'delete', 'dutt_shd_clear_logs', false );
		echo ' <span class="description">Clears only this recent diagnostics view, not WooCommerce log files.</span>';
		echo '</form>';
	}

	private static function render_table( array $logs ): void {
		echo '<table class="widefat striped">';
		echo '<thead><tr><th style="width: 170px;">Time</th><th style="width: 90px;">Level</th><th style="width: 220px;">Event</th><th>Context</th></tr></thead>';
		echo '<tbody>';

		if ( empty( $logs ) ) {
			echo '<tr><td colspan="4">No DUTT logs yet.</td></tr>';
		} else {
			foreach ( $logs as $row ) {
				$context = isset( $row['context'] ) && is_array( $row['context'] ) ? $row['context'] : array();
				echo '<tr>';
				echo '<td>' . esc_html( (string) ( $row['time'] ?? '' ) ) . '</td>';
				echo '<td><strong>' . esc_html( strtoupper( (string) ( $row['level'] ?? '' ) ) ) . '</strong></td>';
				echo '<td><code>' . esc_html( (string) ( $row['event'] ?? '' ) ) . '</code></td>';
				echo '<td><pre style="white-space: pre-wrap; margin: 0;">' . esc_html( wp_json_encode( $context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) . '</pre></td>';
				echo '</tr>';
			}
		}

		echo '</tbody></table>';
	}
}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Merchant_Overview {
	const MENU_SLUG     = 'dutt-merchant-overview';
	const EXPORT_ACTION = 'dutt_shd_export_merchant_overview';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 20 );
		add_action( 'admin_post_' . self::EXPORT_ACTION, array( __CLASS__, 'handle_export' ) );
	}

	public static function add_menu(): void {
		add_submenu_page(
			DUTT_SHD_Onboarding::PARENT_MENU_SLUG,
			'Merchant Overview',
			'Merchant Overview',
			'manage_woocommerce',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'dutt-same-hour-delivery' ) );
		}

		$range = self::date_range_from_request();
		$data  = self::overview_data( $range );

		echo '<div class="wrap">';
		echo '<h1>DUTT Merchant Overview</h1>';
		if ( class_exists( 'DUTT_SHD_Merchant_Support' ) ) {
			echo '<p><a class="button" href="' . esc_url( DUTT_SHD_Merchant_Support::support_url() ) . '">Open Dutt Support</a></p>';
		}

		self::render_filters( $range );
		self::render_source_notice( $data );
		self::render_summary_cards( $data['summary'] );
		self::render_policy_breakdown( $data['summary'] );
		self::render_orders_table( $data['rows'] );

		echo '</div>';
	}

	public static function handle_export(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to export DUTT data.', 'dutt-same-hour-delivery' ) );
		}

		check_admin_referer( self::EXPORT_ACTION );

		$range    = self::date_range_from_request();
		$data     = self::overview_data( $range, 2000 );
		$filename = sprintf( 'dutt-merchant-overview-%s-to-%s.csv', $range['start'], $range['end'] );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

		$output = fopen( 'php://output', 'w' );
		if ( false === $output ) {
			exit;
		}

		fputcsv(
			$output,
			array(
				'Date',
				'Source',
				'Order',
				'Merchant reference',
				'Operation result',
				'Settlement status',
				'Settlement mode',
				'Charge policy',
				'DUTT quote',
				'Customer charge collected by store',
				'Store contribution',
				'Merchant due to DUTT',
				'Customer receipt required',
				'Merchant invoice required',
				'Customer receipt status',
				'Merchant invoice status',
				'Payment status',
				'Dispute status',
				'Dispute reason',
				'Admin notes',
			)
		);

		foreach ( $data['rows'] as $row ) {
			fputcsv(
				$output,
				array(
					$row['date'],
					$row['source'],
					$row['order_number'],
					$row['merchant_reference'],
					$row['operation_result'],
					$row['settlement_status'],
					$row['settlement_mode'],
					$row['charge_policy'],
					self::format_csv_money( $row['quote_price'] ),
					self::format_csv_money( $row['customer_charge'] ),
					self::format_csv_money( $row['store_contribution'] ),
					self::format_csv_money( $row['merchant_due'] ),
					$row['customer_receipt_required'] ? 'yes' : 'no',
					$row['merchant_invoice_required'] ? 'yes' : 'no',
					$row['customer_receipt_status'],
					$row['merchant_invoice_status'],
					$row['payment_status'],
					$row['dispute_status'],
					$row['dispute_reason'],
					$row['admin_notes'],
				)
			);
		}

		fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Closes the streamed CSV response.
		exit;
	}

	private static function overview_data( array $range, int $limit = 500 ): array {
		$backend = self::fetch_backend_overview( $range, $limit );
		if ( $backend['success'] ) {
			return $backend;
		}

		$rows = self::local_rows_from_orders( self::dutt_orders_for_range( $range['start'], $range['end'], $limit ) );
		return array(
			'success'     => true,
			'source'      => 'woocommerce_local_fallback',
			'notice'      => $backend['message'],
			'summary'     => self::summary_from_rows( $rows ),
			'rows'        => $rows,
			'settlements' => array(),
		);
	}

	private static function fetch_backend_overview( array $range, int $limit ): array {
		$settings     = DUTT_SHD_Settings::all();
		$endpoint     = esc_url_raw( trim( (string) ( $settings['merchant_overview_api_url'] ?? '' ) ) );
		$merchant_key = trim( (string) ( $settings['merchant_key'] ?? '' ) );

		if ( '' === $endpoint || '' === $merchant_key ) {
			return self::backend_failure( 'Merchant Overview API URL or Merchant Key is missing.' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => max( 5, (int) ( $settings['api_timeout_seconds'] ?? 8 ) ),
				'headers' => array(
					'Content-Type'        => 'application/json',
					'Accept'              => 'application/json',
					'User-Agent'          => 'DUTT-WooCommerce/' . DUTT_SHD_VERSION,
					'X-DUTT-Merchant-Key' => $merchant_key,
				),
				'body'    => wp_json_encode(
					array(
						'start'    => $range['start'],
						'end'      => $range['end'],
						'limit'    => $limit,
						'site_url' => home_url(),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::backend_failure( 'Dutt ledger request failed: ' . $response->get_error_message() );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );
		if ( $status < 200 || $status >= 300 || ! is_array( $data ) || empty( $data['success'] ) ) {
			$reason = is_array( $data ) ? (string) ( $data['reason'] ?? $data['error'] ?? 'unknown_error' ) : 'invalid_response';
			return self::backend_failure( 'Dutt ledger unavailable: ' . $reason );
		}

		$rows = self::backend_rows( is_array( $data['rows'] ?? null ) ? $data['rows'] : array() );
		return array(
			'success'     => true,
			'source'      => 'dutt_merchant_ledger',
			'notice'      => '',
			'merchant'    => is_array( $data['merchant'] ?? null ) ? $data['merchant'] : array(),
			'summary'     => self::backend_summary( is_array( $data['summary'] ?? null ) ? $data['summary'] : array(), $rows ),
			'rows'        => $rows,
			'settlements' => is_array( $data['settlements'] ?? null ) ? $data['settlements'] : array(),
		);
	}

	private static function backend_failure( string $message ): array {
		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::warning( 'merchant_overview_backend_unavailable', array( 'message' => $message ) );
		}
		return array(
			'success' => false,
			'message' => $message,
		);
	}

	private static function backend_rows( array $rows ): array {
		return array_map(
			static function ( array $row ): array {
				return array(
					'date'                      => (string) ( $row['effectiveDate'] ?? '' ),
					'source'                    => (string) ( $row['source'] ?? '' ),
					'order_number'              => (string) ( $row['orderNumber'] ?? $row['sourceOrderId'] ?? '' ),
					'edit_url'                  => '',
					'external_order_id'         => (string) ( $row['sourceOrderId'] ?? '' ),
					'delivery_id'               => (string) ( $row['deliveryId'] ?? $row['duttOrderId'] ?? '' ),
					'merchant_reference'        => (string) ( $row['merchantOrderReference'] ?? $row['orderNumber'] ?? '' ),
					'operation_result'          => (string) ( $row['operationResult'] ?? '' ),
					'settlement_status'         => (string) ( $row['settlementStatus'] ?? $row['status'] ?? '' ),
					'settlement_mode'           => (string) ( $row['settlementMode'] ?? '' ),
					'charge_policy'             => (string) ( $row['chargePolicy'] ?? '' ),
					'charge_policy_label'       => self::charge_policy_label( (string) ( $row['chargePolicy'] ?? '' ) ),
					'quote_price'               => self::money( $row['quotePrice'] ?? 0 ),
					'customer_charge'           => self::money( $row['customerCharge'] ?? 0 ),
					'store_contribution'        => self::money( $row['merchantContribution'] ?? 0 ),
					'merchant_due'              => self::money( $row['merchantDueToDutt'] ?? 0 ),
					'customer_receipt_required' => ! empty( $row['customerReceiptRequired'] ),
					'merchant_invoice_required' => ! empty( $row['merchantInvoiceRequired'] ),
					'customer_receipt_status'   => (string) ( $row['customerReceiptStatus'] ?? '' ),
					'merchant_invoice_status'   => (string) ( $row['merchantInvoiceStatus'] ?? '' ),
					'payment_status'            => (string) ( $row['paymentStatus'] ?? '' ),
					'dispute_status'            => (string) ( $row['disputeStatus'] ?? '' ),
					'dispute_reason'            => (string) ( $row['disputeReason'] ?? '' ),
					'admin_notes'               => (string) ( $row['adminNotes'] ?? '' ),
				);
			},
			$rows
		);
	}

	private static function backend_summary( array $summary, array $rows ): array {
		if ( empty( $summary ) ) {
			return self::summary_from_rows( $rows );
		}
		return array(
			'count'                     => (int) ( $summary['orderCount'] ?? count( $rows ) ),
			'quote_price'               => self::money( $summary['quotePrice'] ?? 0 ),
			'customer_charge'           => self::money( $summary['customerCharge'] ?? 0 ),
			'store_contribution'        => self::money( $summary['merchantContribution'] ?? 0 ),
			'merchant_due'              => self::money( $summary['merchantDueToDutt'] ?? 0 ),
			'customer_receipt_amount'   => self::money( $summary['customerReceiptAmount'] ?? 0 ),
			'merchant_invoice_amount'   => self::money( $summary['merchantInvoiceAmount'] ?? 0 ),
			'customer_paid_count'       => (int) ( $summary['customerPaidCount'] ?? 0 ),
			'free_delivery_count'       => (int) ( $summary['freeDeliveryCount'] ?? 0 ),
			'split_count'               => (int) ( $summary['splitCostCount'] ?? 0 ),
			'customer_receipts_pending' => (int) ( $summary['customerReceiptsPending'] ?? 0 ),
			'merchant_invoices_pending' => (int) ( $summary['merchantInvoicesPending'] ?? 0 ),
			'payments_pending'          => (int) ( $summary['paymentsPending'] ?? 0 ),
			'disputes_open'             => (int) ( $summary['disputesOpen'] ?? 0 ),
		);
	}

	private static function render_filters( array $range ): void {
		$export_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => self::EXPORT_ACTION,
					'start'  => $range['start'],
					'end'    => $range['end'],
				),
				admin_url( 'admin-post.php' )
			),
			self::EXPORT_ACTION
		);

		echo '<form method="get" style="display:flex;gap:12px;align-items:end;margin:18px 0;">';
		echo '<input type="hidden" name="page" value="' . esc_attr( self::MENU_SLUG ) . '">';
		echo '<label>From<br><input type="date" name="start" value="' . esc_attr( $range['start'] ) . '"></label>';
		echo '<label>To<br><input type="date" name="end" value="' . esc_attr( $range['end'] ) . '"></label>';
		echo '<button class="button button-primary" type="submit">Apply</button>';
		echo '<a class="button" href="' . esc_url( $export_url ) . '">Export CSV</a>';
		echo '</form>';
	}

	private static function render_source_notice( array $data ): void {
		if ( 'dutt_merchant_ledger' === $data['source'] ) {
			return;
		}
		echo '<div class="notice notice-warning inline"><p>DUTT ledger temporarily unavailable.</p></div>';
	}

	private static function render_summary_cards( array $summary ): void {
		$cards = array(
			array(
				'label' => 'DUTT shipments',
				'value' => (string) $summary['count'],
			),
			array(
				'label' => 'Merchant due to DUTT',
				'value' => wc_price( $summary['merchant_due'] ),
			),
			array(
				'label' => 'Collected from customers',
				'value' => wc_price( $summary['customer_charge'] ),
			),
			array(
				'label' => 'Store-paid amount',
				'value' => wc_price( $summary['store_contribution'] ),
			),
			array(
				'label' => 'Open disputes',
				'value' => (string) ( $summary['disputes_open'] ?? 0 ),
			),
		);

		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin:18px 0;">';
		foreach ( $cards as $card ) {
			echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:14px;">';
			echo '<div style="font-size:12px;color:#646970;text-transform:uppercase;letter-spacing:.03em;">' . esc_html( $card['label'] ) . '</div>';
			echo '<div style="font-size:24px;font-weight:700;margin-top:6px;">' . wp_kses_post( $card['value'] ) . '</div>';
			echo '</div>';
		}
		echo '</div>';
	}

	private static function render_policy_breakdown( array $summary ): void {
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:14px;margin:12px 0;">';
		echo '<h2 style="margin-top:0;">Pricing policy breakdown</h2>';
		echo '<ul style="margin-bottom:0;">';
		echo '<li>Customer-paid shipments: ' . esc_html( (string) $summary['customer_paid_count'] ) . '</li>';
		echo '<li>Free delivery for customer / store-paid shipments: ' . esc_html( (string) $summary['free_delivery_count'] ) . '</li>';
		echo '<li>Split-cost shipments: ' . esc_html( (string) $summary['split_count'] ) . '</li>';
		echo '<li>Pending customer receipts: ' . esc_html( (string) ( $summary['customer_receipts_pending'] ?? 0 ) ) . '</li>';
		echo '<li>Pending merchant invoices: ' . esc_html( (string) ( $summary['merchant_invoices_pending'] ?? 0 ) ) . '</li>';
		echo '</ul>';
		echo '</div>';
	}

	private static function render_orders_table( array $rows ): void {
		echo '<h2>DUTT ledgered shipments</h2>';

		if ( empty( $rows ) ) {
			echo '<p>No DUTT ledgered shipments found for this period.</p>';
			return;
		}

		echo '<table class="widefat striped">';
		echo '<thead><tr>';
		echo '<th>Date</th><th>Source</th><th>Order</th><th>Reference</th><th>Operation</th><th>Settlement status</th><th>Mode</th><th>Policy</th><th>DUTT quote</th><th>Customer collected</th><th>Store paid</th><th>Due to DUTT</th><th>Receipt</th><th>Invoice</th><th>Payment</th><th>Dispute</th><th>Notes</th><th>Support</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			echo '<tr>';
			echo '<td>' . esc_html( $row['date'] ) . '</td>';
			echo '<td>' . esc_html( $row['source'] ?: '-' ) . '</td>';
			echo '<td>' . ( $row['edit_url'] ? '<a href="' . esc_url( $row['edit_url'] ) . '">' . esc_html( $row['order_number'] ) . '</a>' : esc_html( $row['order_number'] ?: '-' ) ) . '</td>';
			echo '<td>' . esc_html( $row['merchant_reference'] ?: '-' ) . '</td>';
			echo '<td>' . esc_html( $row['operation_result'] ?: '-' ) . '</td>';
			echo '<td>' . esc_html( $row['settlement_status'] ?: '-' ) . '</td>';
			echo '<td>' . esc_html( $row['settlement_mode'] ?: '-' ) . '</td>';
			echo '<td>' . esc_html( $row['charge_policy_label'] ?: '-' ) . '</td>';
			echo '<td>' . wp_kses_post( wc_price( $row['quote_price'] ) ) . '</td>';
			echo '<td>' . wp_kses_post( wc_price( $row['customer_charge'] ) ) . '</td>';
			echo '<td>' . wp_kses_post( wc_price( $row['store_contribution'] ) ) . '</td>';
			echo '<td><strong>' . wp_kses_post( wc_price( $row['merchant_due'] ) ) . '</strong></td>';
			echo '<td>' . esc_html( $row['customer_receipt_status'] ?: ( $row['customer_receipt_required'] ? 'pending' : 'not_required' ) ) . '</td>';
			echo '<td>' . esc_html( $row['merchant_invoice_status'] ?: ( $row['merchant_invoice_required'] ? 'pending' : 'not_required' ) ) . '</td>';
			echo '<td>' . esc_html( $row['payment_status'] ?: 'pending' ) . '</td>';
			echo '<td>' . esc_html( $row['dispute_status'] ?: 'none' ) . '</td>';
			echo '<td>' . esc_html( $row['dispute_reason'] ?: $row['admin_notes'] ?: '-' ) . '</td>';
			$support_url = class_exists( 'DUTT_SHD_Merchant_Support' )
				? DUTT_SHD_Merchant_Support::support_url(
					array(
						'order_reference' => (string) ( $row['merchant_reference'] ?: $row['order_number'] ),
						'delivery_id'     => (string) ( $row['delivery_id'] ?? '' ),
					)
				)
				: '';
			echo '<td>' . ( $support_url ? '<a href="' . esc_url( $support_url ) . '">Contact</a>' : '-' ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	private static function date_range_from_request(): array {
		$now           = current_datetime();
		$default_start = $now->modify( 'first day of this month' )->format( 'Y-m-d' );
		$default_end   = $now->format( 'Y-m-d' );
		$start         = isset( $_GET['start'] ) ? sanitize_text_field( wp_unslash( $_GET['start'] ) ) : $default_start; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
		$end           = isset( $_GET['end'] ) ? sanitize_text_field( wp_unslash( $_GET['end'] ) ) : $default_end; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report filter.
		$start         = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $start ) ? $start : $default_start;
		$end           = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $end ) ? $end : $default_end;
		if ( strtotime( $start ) > strtotime( $end ) ) {
			$tmp   = $start;
			$start = $end;
			$end   = $tmp;
		}
		return array(
			'start' => $start,
			'end'   => $end,
		);
	}

	private static function dutt_orders_for_range( string $start, string $end, int $limit = 500 ): array {
		$timezone = wp_timezone();
		$start_dt = new DateTimeImmutable( $start . ' 00:00:00', $timezone );
		$end_dt   = new DateTimeImmutable( $end . ' 23:59:59', $timezone );

		return wc_get_orders(
			array(
				'type'         => 'shop_order',
				'status'       => array_keys( wc_get_order_statuses() ),
				'limit'        => $limit,
				'orderby'      => 'date',
				'order'        => 'DESC',
				'date_created' => $start_dt->getTimestamp() . '...' . $end_dt->getTimestamp(),
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Bounded local fallback used only when the common ledger API is unavailable.
				'meta_query'   => array(
					array(
						'key'     => 'dutt_selected',
						'value'   => 'yes',
						'compare' => '=',
					),
				),
			)
		);
	}

	private static function local_rows_from_orders( array $orders ): array {
		$rows = array();
		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$quote_price        = self::order_money( $order, 'dutt_quote_price', self::dutt_shipping_total( $order ) );
			$customer_charge    = self::effective_money( $order, 'dutt_customer_charge_effective', 'dutt_customer_charge', self::dutt_shipping_total( $order ) );
			$store_contribution = self::effective_money( $order, 'dutt_store_contribution_effective', 'dutt_store_contribution', 0.0 );
			$merchant_due       = self::effective_money( $order, 'dutt_merchant_due_after_operation', '', max( $quote_price, $customer_charge + $store_contribution ) );
			$policy             = (string) $order->get_meta( 'dutt_charge_policy' );
			$created            = $order->get_date_created();
			$operation_result   = self::operation_result_label( (string) $order->get_meta( 'dutt_operation_result' ), (string) $order->get_meta( 'dutt_status' ) );
			$settlement_status  = (string) $order->get_meta( 'dutt_settlement_status' );
			if ( '' === $settlement_status ) {
				$refund_review_status = (string) $order->get_meta( 'dutt_refund_review_status' );
				$settlement_status    = 'manual_review_required' === $refund_review_status ? 'manual_review_required' : 'pending';
			}
			$settlement_mode           = (string) $order->get_meta( 'dutt_operation_mode' );
			$customer_receipt_required = self::effective_flag( $order, 'dutt_customer_receipt_required_effective', $customer_charge > 0 );
			$merchant_invoice_required = self::effective_flag( $order, 'dutt_merchant_invoice_required_effective', $store_contribution > 0 );
			$customer_receipt_status   = $customer_receipt_required ? 'pending' : 'not_required';
			$merchant_invoice_status   = $merchant_invoice_required ? 'pending' : 'not_required';
			if ( 'manual_review_required' === $settlement_status ) {
				$customer_receipt_status = $customer_receipt_required ? 'review' : 'not_required';
				$merchant_invoice_status = $merchant_invoice_required ? 'review' : 'not_required';
			}
			$notes = (string) $order->get_meta( 'dutt_operation_note' );
			if ( '' === $notes ) {
				$notes = (string) $order->get_meta( 'dutt_last_error' );
			}

			$rows[] = array(
				'date'                      => $created ? $created->date_i18n( 'Y-m-d H:i' ) : '',
				'source'                    => 'woocommerce_local',
				'order_number'              => $order->get_order_number(),
				'edit_url'                  => self::order_edit_url( $order ),
				'external_order_id'         => (string) $order->get_id(),
				'delivery_id'               => (string) $order->get_meta( 'dutt_delivery_id' ),
				'merchant_reference'        => (string) $order->get_meta( 'dutt_pickup_reference' ),
				'operation_result'          => $operation_result,
				'settlement_status'         => $settlement_status,
				'settlement_mode'           => $settlement_mode ?: 'standard',
				'charge_policy'             => $policy,
				'charge_policy_label'       => self::charge_policy_label( $policy ),
				'quote_price'               => $quote_price,
				'customer_charge'           => $customer_charge,
				'store_contribution'        => $store_contribution,
				'merchant_due'              => $merchant_due,
				'customer_receipt_required' => $customer_receipt_required,
				'merchant_invoice_required' => $merchant_invoice_required,
				'customer_receipt_status'   => $customer_receipt_status,
				'merchant_invoice_status'   => $merchant_invoice_status,
				'payment_status'            => 'manual_review_required' === $settlement_status
					? 'review'
					: ( $merchant_due <= 0.0 ? 'not_required' : 'pending' ),
				'dispute_status'            => 'none',
				'dispute_reason'            => '',
				'admin_notes'               => $notes,
			);
		}
		return $rows;
	}

	private static function summary_from_rows( array $rows ): array {
		$summary = array(
			'count'                     => 0,
			'quote_price'               => 0.0,
			'customer_charge'           => 0.0,
			'store_contribution'        => 0.0,
			'merchant_due'              => 0.0,
			'customer_receipt_amount'   => 0.0,
			'merchant_invoice_amount'   => 0.0,
			'customer_paid_count'       => 0,
			'free_delivery_count'       => 0,
			'split_count'               => 0,
			'customer_receipts_pending' => 0,
			'merchant_invoices_pending' => 0,
			'payments_pending'          => 0,
			'disputes_open'             => 0,
		);

		foreach ( $rows as $row ) {
			++$summary['count'];
			$summary['quote_price']             += $row['quote_price'];
			$summary['customer_charge']         += $row['customer_charge'];
			$summary['store_contribution']      += $row['store_contribution'];
			$summary['merchant_due']            += $row['merchant_due'];
			$summary['customer_receipt_amount'] += $row['customer_receipt_required'] ? $row['customer_charge'] : 0;
			$summary['merchant_invoice_amount'] += $row['merchant_invoice_required'] ? $row['store_contribution'] : 0;

			if ( $row['customer_charge'] <= 0.0 && $row['store_contribution'] > 0.0 ) {
				++$summary['free_delivery_count'];
			} elseif ( $row['customer_charge'] > 0.0 && $row['store_contribution'] > 0.0 ) {
				++$summary['split_count'];
			} elseif ( $row['customer_charge'] > 0.0 ) {
				++$summary['customer_paid_count'];
			}
			if ( $row['customer_receipt_required'] && ( empty( $row['customer_receipt_status'] ) || 'pending' === $row['customer_receipt_status'] ) ) {
				++$summary['customer_receipts_pending'];
			}
			if ( $row['merchant_invoice_required'] && ( empty( $row['merchant_invoice_status'] ) || 'pending' === $row['merchant_invoice_status'] ) ) {
				++$summary['merchant_invoices_pending'];
			}
			if ( empty( $row['payment_status'] ) || 'pending' === $row['payment_status'] ) {
				++$summary['payments_pending'];
			}
			if ( 'open' === $row['dispute_status'] || 'disputed' === $row['dispute_status'] ) {
				++$summary['disputes_open'];
			}
		}

		foreach ( array( 'quote_price', 'customer_charge', 'store_contribution', 'merchant_due', 'customer_receipt_amount', 'merchant_invoice_amount' ) as $key ) {
			$summary[ $key ] = round( $summary[ $key ], 2 );
		}

		return $summary;
	}

	private static function order_money( WC_Order $order, string $meta_key, float $fallback ): float {
		$value = $order->get_meta( $meta_key );
		if ( '' !== (string) $value && is_numeric( $value ) ) {
			return round( max( 0.0, (float) $value ), 2 );
		}
		return round( max( 0.0, $fallback ), 2 );
	}

	private static function effective_money( WC_Order $order, string $effective_meta_key, string $base_meta_key, float $fallback ): float {
		if ( '' !== $effective_meta_key ) {
			$effective_value = $order->get_meta( $effective_meta_key );
			if ( '' !== (string) $effective_value && is_numeric( $effective_value ) ) {
				return round( max( 0.0, (float) $effective_value ), 2 );
			}
		}

		if ( '' !== $base_meta_key ) {
			return self::order_money( $order, $base_meta_key, $fallback );
		}

		return round( max( 0.0, $fallback ), 2 );
	}

	private static function effective_flag( WC_Order $order, string $meta_key, bool $fallback ): bool {
		$value = strtolower( trim( (string) $order->get_meta( $meta_key ) ) );
		if ( 'yes' === $value || 'true' === $value || '1' === $value ) {
			return true;
		}
		if ( 'no' === $value || 'false' === $value || '0' === $value ) {
			return false;
		}

		return $fallback;
	}

	private static function dutt_shipping_total( WC_Order $order ): float {
		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( 'dutt_same_hour_delivery' === $item->get_method_id() ) {
				return round( max( 0.0, (float) $item->get_total() ), 2 );
			}
		}
		return round( max( 0.0, (float) $order->get_shipping_total() ), 2 );
	}

	private static function order_edit_url( WC_Order $order ): string {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			return admin_url( 'admin.php?page=wc-orders&action=edit&id=' . $order->get_id() );
		}
		return get_edit_post_link( $order->get_id(), '' ) ?: admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' );
	}

	private static function charge_policy_label( string $policy ): string {
		if ( class_exists( 'DUTT_SHD_Checkout' ) ) {
			return DUTT_SHD_Checkout::charge_policy_label( $policy );
		}
		return $policy;
	}

	private static function money( $value ): float {
		return is_numeric( $value ) ? round( max( 0.0, (float) $value ), 2 ) : 0.0;
	}

	private static function format_csv_money( float $value ): string {
		return number_format( $value, 2, '.', '' );
	}

	private static function operation_result_label( string $value, string $dutt_status = '' ): string {
		$value = sanitize_key( str_replace( '-', '_', strtolower( trim( $value ) ) ) );
		if ( '' === $value ) {
			$status = sanitize_key( str_replace( '-', '_', strtolower( trim( $dutt_status ) ) ) );
			if ( 'delivered' === $status || 'completed' === $status || 'complete' === $status ) {
				return 'Delivered';
			}
			if ( 'awaiting_ready_for_pickup' === $status || 'pending_dispatch' === $status ) {
				return 'Delivery pending';
			}
			return 'Standard flow';
		}

		$labels = array(
			'cancelled'                     => 'Cancelled',
			'cancel_ignored_after_delivery' => 'Cancellation ignored after delivery',
			'cancelled_pending'             => 'Cancelled before dispatch',
			'cancelled_before_dispatch'     => 'Cancelled before dispatch',
			'cancelled_before_pickup'       => 'Cancelled before pickup',
			'cancelled_accepted'            => 'Cancelled after driver acceptance',
			'cancelled_after_acceptance'    => 'Cancelled after driver acceptance',
			'refund_manual_review'          => 'Refund requires manual review',
		);

		return $labels[ $value ] ?? ucwords( str_replace( '_', ' ', $value ) );
	}
}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Refunds {
	public static function init(): void {
		add_action( 'woocommerce_order_refunded', array( __CLASS__, 'handle_order_refunded' ), 10, 2 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'handle_order_cancelled' ), 10, 2 );
	}

	public static function handle_order_refunded( int $order_id, int $refund_id ): void {
		$order  = wc_get_order( $order_id );
		$refund = wc_get_order( $refund_id );

		if ( ! $order instanceof WC_Order || ! $refund instanceof WC_Order_Refund ) {
			return;
		}

		if ( ! self::has_dutt_delivery( $order ) ) {
			return;
		}

		if ( self::is_full_refund( $order, $refund ) ) {
			$cancel_result = DUTT_SHD_Order_Meta::auto_cancel_delivery_for_order( $order, 'woocommerce_full_refund' );
			if ( ! empty( $cancel_result['success'] ) || self::is_cancelled_delivery_status( (string) $order->get_meta( 'dutt_status' ) ) ) {
				return;
			}
		}

		$result = DUTT_SHD_API_Client::report_refund( $order, $refund );
		if ( ! empty( $result['ignored'] ) ) {
			return;
		}

		if ( ! empty( $result['success'] ) ) {
			$requires_review   = ! empty( $result['requires_review'] );
			$review_status     = sanitize_key( (string) ( $result['review_status'] ?? '' ) );
			$settlement_impact = sanitize_key( (string) ( $result['settlement_impact'] ?? '' ) );
			$accounting_status = sanitize_key( (string) ( $result['accounting_status'] ?? '' ) );
			$accounting_action = sanitize_key( (string) ( $result['accounting_action'] ?? '' ) );
			$automatic         = ! empty( $result['auto_ledger_adjustment'] );

			if ( '' === $review_status ) {
				$review_status = $requires_review ? 'manual_review_required' : 'automatic_policy_applied';
			}
			if ( '' === $settlement_impact ) {
				$settlement_impact = 'none';
			}
			if ( '' === $accounting_status ) {
				$accounting_status = $requires_review ? 'pending_review' : 'policy_applied';
			}
			if ( '' === $accounting_action ) {
				$accounting_action = $requires_review ? 'manual_review' : 'automatic_status_policy';
			}

			$order->update_meta_data( 'dutt_last_refund_notice_at', current_time( 'mysql' ) );
			$order->update_meta_data( 'dutt_last_refund_hash', (string) ( $result['refund_hash'] ?? '' ) );
			$order->update_meta_data( 'dutt_refund_review_status', $review_status );
			$order->update_meta_data( 'dutt_refund_settlement_impact', $settlement_impact );
			$order->update_meta_data( 'dutt_refund_auto_ledger_adjustment', $automatic ? 'yes' : 'no' );
			$order->update_meta_data( 'dutt_refund_accounting_status', $accounting_status );
			$order->update_meta_data( 'dutt_refund_accounting_action', $accounting_action );
			$order->update_meta_data( 'dutt_operation_result', $requires_review ? 'refund_manual_review' : 'refund_policy_applied' );
			$order->update_meta_data( 'dutt_operation_mode', $requires_review ? 'manual_review' : 'automatic' );
			$order->update_meta_data( 'dutt_operation_source', 'woocommerce_refund' );
			$order->update_meta_data(
				'dutt_operation_note',
				$requires_review
					? 'Dutt shipping refund reported. Finance review is required before invoice correction.'
					: 'Dutt shipping refund reported and the configured settlement policy was applied.'
			);
			$order->update_meta_data( 'dutt_settlement_status', $requires_review ? 'manual_review_required' : $accounting_status );
			$order->add_order_note(
				$requires_review
					? 'Dutt shipping refund sent for finance review and linked invoice correction.'
					: 'Dutt shipping refund processed by the configured settlement policy.'
			);
			if ( class_exists( 'DUTT_SHD_Logger' ) ) {
				DUTT_SHD_Logger::info(
					'refund_notice_sent',
					array(
						'order_id'     => $order->get_id(),
						'order_number' => $order->get_order_number(),
						'refund_id'    => $refund->get_id(),
						'refund_hash'  => (string) ( $result['refund_hash'] ?? '' ),
						'amount'       => abs( (float) $refund->get_amount() ),
					)
				);
			}
		} else {
			$order->update_meta_data( 'dutt_last_refund_notice_error', (string) ( $result['reason'] ?? 'refund_notice_failed' ) );
			$order->add_order_note( 'Dutt refund notice failed: ' . (string) ( $result['reason'] ?? 'refund_notice_failed' ) );
			if ( class_exists( 'DUTT_SHD_Logger' ) ) {
				DUTT_SHD_Logger::warning(
					'refund_notice_failed',
					array(
						'order_id'     => $order->get_id(),
						'order_number' => $order->get_order_number(),
						'refund_id'    => $refund->get_id(),
						'reason'       => (string) ( $result['reason'] ?? 'refund_notice_failed' ),
					)
				);
			}
		}
		$order->save();
	}

	public static function handle_order_cancelled( int $order_id, $order = null ): void {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( ! self::has_dutt_delivery( $order ) ) {
			return;
		}

		$dutt_status = self::normalize_delivery_status( (string) $order->get_meta( 'dutt_status' ) );
		if ( self::is_terminal_success_status( $dutt_status ) ) {
			$order->update_meta_data( 'dutt_last_cancel_trigger', 'woocommerce_cancelled_status' );
			$order->update_meta_data( 'dutt_last_cancel_mode', 'automatic' );
			$order->update_meta_data( 'dutt_operation_result', 'cancel_ignored_after_delivery' );
			$order->update_meta_data( 'dutt_operation_mode', 'manual_review' );
			$order->update_meta_data( 'dutt_operation_stage', 'after_delivery' );
			$order->update_meta_data( 'dutt_operation_source', 'woocommerce_cancelled_status' );
			$order->update_meta_data( 'dutt_operation_note', 'WooCommerce cancellation was ignored because the Dutt delivery was already delivered. Use a refund for post-delivery financial adjustments.' );
			$order->add_order_note( 'WooCommerce cancellation was ignored because the Dutt delivery is already delivered. Use WooCommerce refund for post-delivery financial adjustments.' );
			$order->save();

			if ( 'completed' !== $order->get_status() ) {
				$order->update_status( 'completed', 'Dutt delivery is already delivered. Cancellation was reverted; use refund for post-delivery adjustments.' );
			}
			return;
		}

		DUTT_SHD_Order_Meta::auto_cancel_delivery_for_order( $order, 'woocommerce_cancelled_status' );
	}

	private static function has_dutt_delivery( WC_Order $order ): bool {
		if ( 'yes' === trim( (string) $order->get_meta( 'dutt_selected' ) ) ) {
			return true;
		}
		if ( '' !== trim( (string) $order->get_meta( 'dutt_delivery_id' ) ) ) {
			return true;
		}
		if ( '' !== trim( (string) $order->get_meta( 'mock_dutt_delivery_id' ) ) ) {
			return true;
		}
		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( 'dutt_same_hour_delivery' === $item->get_method_id() ) {
				return true;
			}
		}
		return false;
	}

	private static function is_full_refund( WC_Order $order, WC_Order_Refund $refund ): bool {
		$order_total    = round( (float) $order->get_total(), 2 );
		$refund_amount  = round( abs( (float) $refund->get_amount() ), 2 );
		$total_refunded = round( abs( (float) $order->get_total_refunded() ), 2 );

		if ( $order_total <= 0 ) {
			return false;
		}

		return $refund_amount >= ( $order_total - 0.01 ) || $total_refunded >= ( $order_total - 0.01 );
	}

	private static function is_cancelled_delivery_status( string $status ): bool {
		$status = self::normalize_delivery_status( $status );
		return 'cancelled' === $status || str_starts_with( $status, 'cancelled_' );
	}

	private static function normalize_delivery_status( string $status ): string {
		$status = sanitize_key( str_replace( '-', '_', strtolower( trim( $status ) ) ) );
		if ( 'canceled' === $status ) {
			$status = 'cancelled';
		}
		if ( 'canceled_by_admin' === $status ) {
			$status = 'cancelled_by_admin';
		}
		if ( 'canceled_by_merchant' === $status ) {
			$status = 'cancelled_by_merchant';
		}

		return $status;
	}

	private static function is_terminal_success_status( string $status ): bool {
		return in_array(
			self::normalize_delivery_status( $status ),
			array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ),
			true
		);
	}
}

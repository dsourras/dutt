<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Refunds {
	private const REFUND_RETRY_HOOK   = 'dutt_shd_retry_refund_notice';
	private const REFUND_RETRY_GROUP  = 'dutt-refund-notices';
	private const REFUND_RETRY_DELAYS = array( 300, 1800, 7200, 43200 );

	private const REFUND_NOTICE_STATUS_META       = '_dutt_refund_notice_status';
	private const REFUND_NOTICE_ATTEMPT_META      = '_dutt_refund_notice_attempt';
	private const REFUND_NOTICE_NEXT_AT_META      = '_dutt_refund_notice_next_at';
	private const REFUND_NOTICE_LAST_ERROR_META   = '_dutt_refund_notice_last_error';
	private const REFUND_NOTICE_REFUND_HASH_META  = '_dutt_refund_notice_hash';
	private const REFUND_NOTICE_TERMINAL_STATUSES = array( 'sent', 'ignored', 'permanent_failure' );

	public static function init(): void {
		add_action( 'woocommerce_order_refunded', array( __CLASS__, 'handle_order_refunded' ), 10, 2 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'handle_order_cancelled' ), 10, 2 );
		add_action( self::REFUND_RETRY_HOOK, array( __CLASS__, 'handle_refund_notice_retry' ), 10, 3 );
	}

	public static function handle_order_refunded( int $order_id, int $refund_id ): void {
		$order  = wc_get_order( $order_id );
		$refund = wc_get_order( $refund_id );

		if ( ! $order instanceof WC_Order || ! $refund instanceof WC_Order_Refund ) {
			return;
		}

		if ( ! self::has_dutt_delivery( $order ) ) {
			return;
		}

		if ( self::is_full_refund( $order, $refund ) ) {
			$cancel_result = DUTT_SHD_Order_Meta::auto_cancel_delivery_for_order( $order, 'woocommerce_full_refund' );
			if ( ! empty( $cancel_result['success'] ) || self::is_cancelled_delivery_status( (string) $order->get_meta( 'dutt_status' ) ) ) {
				return;
			}
		}

		$status = sanitize_key( (string) $refund->get_meta( self::REFUND_NOTICE_STATUS_META ) );
		if ( 'retry_scheduled' === $status || in_array( $status, self::REFUND_NOTICE_TERMINAL_STATUSES, true ) ) {
			return;
		}

		self::process_refund_notice( $order, $refund, 0 );
	}

	public static function handle_refund_notice_retry( int $order_id, int $refund_id, int $attempt ): void {
		if ( $attempt < 1 || $attempt > count( self::REFUND_RETRY_DELAYS ) ) {
			return;
		}

		$order  = wc_get_order( $order_id );
		$refund = wc_get_order( $refund_id );
		if ( ! $order instanceof WC_Order || ! $refund instanceof WC_Order_Refund ) {
			return;
		}

		if ( method_exists( $refund, 'get_parent_id' ) ) {
			$parent_id = (int) $refund->get_parent_id();
			if ( $parent_id > 0 && $parent_id !== $order_id ) {
				return;
			}
		}

		if ( ! self::has_dutt_delivery( $order ) ) {
			return;
		}

		$status            = sanitize_key( (string) $refund->get_meta( self::REFUND_NOTICE_STATUS_META ) );
		$scheduled_attempt = (int) $refund->get_meta( self::REFUND_NOTICE_ATTEMPT_META );
		if ( in_array( $status, self::REFUND_NOTICE_TERMINAL_STATUSES, true ) ) {
			return;
		}
		if ( 'retry_scheduled' === $status && $scheduled_attempt > 0 && $scheduled_attempt !== $attempt ) {
			return;
		}

		self::process_refund_notice( $order, $refund, $attempt );
	}

	private static function process_refund_notice( WC_Order $order, WC_Order_Refund $refund, int $attempt ): void {
		$result = DUTT_SHD_API_Client::report_refund( $order, $refund );
		if ( ! empty( $result['ignored'] ) ) {
			self::update_refund_notice_state( $refund, 'ignored', $attempt, '', 0, '' );
			$refund->save();
			return;
		}

		if ( ! empty( $result['success'] ) ) {
			self::record_refund_notice_success( $order, $refund, $result, $attempt );
			return;
		}

		self::handle_refund_notice_failure( $order, $refund, $result, $attempt );
	}

	private static function record_refund_notice_success(
		WC_Order $order,
		WC_Order_Refund $refund,
		array $result,
		int $attempt
	): void {
		$requires_review   = ! empty( $result['requires_review'] );
		$review_status     = sanitize_key( (string) ( $result['review_status'] ?? '' ) );
		$settlement_impact = sanitize_key( (string) ( $result['settlement_impact'] ?? '' ) );
		$accounting_status = sanitize_key( (string) ( $result['accounting_status'] ?? '' ) );
		$accounting_action = sanitize_key( (string) ( $result['accounting_action'] ?? '' ) );
		$automatic         = ! empty( $result['auto_ledger_adjustment'] );

		if ( '' === $review_status ) {
			$review_status = $requires_review ? 'manual_review_required' : 'automatic_policy_applied';
		}
		if ( '' === $settlement_impact ) {
			$settlement_impact = 'none';
		}
		if ( '' === $accounting_status ) {
			$accounting_status = $requires_review ? 'pending_review' : 'policy_applied';
		}
		if ( '' === $accounting_action ) {
			$accounting_action = $requires_review ? 'manual_review' : 'automatic_status_policy';
		}

		$order->update_meta_data( 'dutt_last_refund_notice_at', current_time( 'mysql' ) );
		$order->update_meta_data( 'dutt_last_refund_hash', (string) ( $result['refund_hash'] ?? '' ) );
		$order->update_meta_data( 'dutt_last_refund_notice_error', '' );
		$order->update_meta_data( 'dutt_refund_review_status', $review_status );
		$order->update_meta_data( 'dutt_refund_settlement_impact', $settlement_impact );
		$order->update_meta_data( 'dutt_refund_auto_ledger_adjustment', $automatic ? 'yes' : 'no' );
		$order->update_meta_data( 'dutt_refund_accounting_status', $accounting_status );
		$order->update_meta_data( 'dutt_refund_accounting_action', $accounting_action );
		$order->update_meta_data( 'dutt_operation_result', $requires_review ? 'refund_manual_review' : 'refund_policy_applied' );
		$order->update_meta_data( 'dutt_operation_mode', $requires_review ? 'manual_review' : 'automatic' );
		$order->update_meta_data( 'dutt_operation_source', 'woocommerce_refund' );
		$order->update_meta_data(
			'dutt_operation_note',
			$requires_review
				? 'Dutt shipping refund reported. Finance review is required before invoice correction.'
				: 'Dutt shipping refund reported and the configured settlement policy was applied.'
		);
		$order->update_meta_data( 'dutt_settlement_status', $requires_review ? 'manual_review_required' : $accounting_status );
		$order->add_order_note(
			$requires_review
				? 'Dutt shipping refund sent for finance review and linked invoice correction.'
				: 'Dutt shipping refund processed by the configured settlement policy.'
		);
		self::update_refund_notice_state(
			$refund,
			'sent',
			$attempt,
			'',
			0,
			(string) ( $result['refund_hash'] ?? '' )
		);

		// Save the order first. If the second save is interrupted, the idempotent backend can safely repair it on retry.
		$order->save();
		$refund->save();

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'refund_notice_sent',
				array(
					'order_id'     => $order->get_id(),
					'order_number' => $order->get_order_number(),
					'refund_id'    => $refund->get_id(),
					'refund_hash'  => (string) ( $result['refund_hash'] ?? '' ),
					'amount'       => abs( (float) $refund->get_amount() ),
					'attempt'      => $attempt,
				)
			);
		}
	}

	private static function handle_refund_notice_failure(
		WC_Order $order,
		WC_Order_Refund $refund,
		array $result,
		int $attempt
	): void {
		$reason       = sanitize_key( (string) ( $result['reason'] ?? 'refund_notice_failed' ) );
		$next_attempt = $attempt + 1;
		$retryable    = self::is_retryable_refund_failure( $result );
		$next_at      = 0;

		if ( $retryable && $next_attempt <= count( self::REFUND_RETRY_DELAYS ) ) {
			$next_at = self::schedule_refund_notice_retry( $order->get_id(), $refund->get_id(), $next_attempt );
		}

		if ( $next_at > 0 ) {
			self::update_refund_notice_state( $refund, 'retry_scheduled', $next_attempt, $reason, $next_at, '' );
			$order->update_meta_data( 'dutt_last_refund_notice_error', $reason );
			$order->update_meta_data( 'dutt_refund_review_status', 'retry_scheduled' );
			$order->update_meta_data( 'dutt_operation_result', 'refund_notice_retry_scheduled' );
			$order->update_meta_data( 'dutt_operation_mode', 'automatic' );
			$order->update_meta_data( 'dutt_operation_source', 'woocommerce_refund' );
			$order->update_meta_data( 'dutt_settlement_status', 'retry_scheduled' );
			$order->add_order_note(
				sprintf(
					'Dutt refund notice temporarily failed (%1$s). Retry %2$d of %3$d was scheduled.',
					$reason,
					$next_attempt,
					count( self::REFUND_RETRY_DELAYS )
				)
			);
			$order->save();
			$refund->save();

			self::log_refund_notice_failure( $order, $refund, $reason, $attempt, 'retry_scheduled' );
			return;
		}

		$terminal_reason = $retryable ? 'retry_exhausted_or_schedule_failed' : 'permanent_failure';
		self::update_refund_notice_state( $refund, 'permanent_failure', $attempt, $reason, 0, '' );
		$order->update_meta_data( 'dutt_last_refund_notice_error', $reason );
		$order->update_meta_data( 'dutt_refund_review_status', 'manual_review_required' );
		$order->update_meta_data( 'dutt_refund_accounting_status', 'pending_review' );
		$order->update_meta_data( 'dutt_refund_accounting_action', 'manual_review' );
		$order->update_meta_data( 'dutt_operation_result', 'refund_notice_failed' );
		$order->update_meta_data( 'dutt_operation_mode', 'manual_review' );
		$order->update_meta_data( 'dutt_operation_source', 'woocommerce_refund' );
		$order->update_meta_data( 'dutt_settlement_status', 'manual_review_required' );
		$order->add_order_note(
			sprintf(
				'Dutt refund notice failed (%1$s, %2$s). Manual finance review is required.',
				$reason,
				$terminal_reason
			)
		);
		$order->save();
		$refund->save();

		self::log_refund_notice_failure( $order, $refund, $reason, $attempt, $terminal_reason );
	}

	private static function update_refund_notice_state(
		WC_Order_Refund $refund,
		string $status,
		int $attempt,
		string $last_error,
		int $next_at,
		string $refund_hash
	): void {
		$refund->update_meta_data( self::REFUND_NOTICE_STATUS_META, $status );
		$refund->update_meta_data( self::REFUND_NOTICE_ATTEMPT_META, $attempt );
		$refund->update_meta_data( self::REFUND_NOTICE_NEXT_AT_META, $next_at );
		$refund->update_meta_data( self::REFUND_NOTICE_LAST_ERROR_META, $last_error );
		$refund->update_meta_data( self::REFUND_NOTICE_REFUND_HASH_META, $refund_hash );
	}

	private static function schedule_refund_notice_retry( int $order_id, int $refund_id, int $attempt ): int {
		$delay = self::retry_delay_seconds( $attempt );
		if ( $delay <= 0 ) {
			return 0;
		}

		$timestamp = time() + $delay;
		$args      = array( $order_id, $refund_id, $attempt );
		if ( function_exists( 'as_has_scheduled_action' )
			&& false !== as_has_scheduled_action( self::REFUND_RETRY_HOOK, $args, self::REFUND_RETRY_GROUP ) ) {
			return $timestamp;
		}
		if ( ! function_exists( 'as_has_scheduled_action' )
			&& function_exists( 'as_next_scheduled_action' )
			&& false !== as_next_scheduled_action( self::REFUND_RETRY_HOOK, $args, self::REFUND_RETRY_GROUP ) ) {
			return $timestamp;
		}

		if ( function_exists( 'as_schedule_single_action' ) ) {
			$action_id = as_schedule_single_action(
				$timestamp,
				self::REFUND_RETRY_HOOK,
				$args,
				self::REFUND_RETRY_GROUP,
				true
			);
			if ( (int) $action_id > 0 ) {
				return $timestamp;
			}

			if ( function_exists( 'as_has_scheduled_action' )
				&& false !== as_has_scheduled_action( self::REFUND_RETRY_HOOK, $args, self::REFUND_RETRY_GROUP ) ) {
				return $timestamp;
			}
		}

		if ( function_exists( 'wp_next_scheduled' ) ) {
			$scheduled = wp_next_scheduled( self::REFUND_RETRY_HOOK, $args );
			if ( false !== $scheduled ) {
				return (int) $scheduled;
			}
		}
		if ( function_exists( 'wp_schedule_single_event' )
			&& wp_schedule_single_event( $timestamp, self::REFUND_RETRY_HOOK, $args ) ) {
			return $timestamp;
		}

		return 0;
	}

	private static function retry_delay_seconds( int $attempt ): int {
		return (int) ( self::REFUND_RETRY_DELAYS[ $attempt - 1 ] ?? 0 );
	}

	private static function is_retryable_refund_failure( array $result ): bool {
		if ( array_key_exists( 'retryable', $result ) ) {
			return true === $result['retryable'];
		}

		$reason = sanitize_key( (string) ( $result['reason'] ?? '' ) );
		if ( 'refund_notice_request_failed' === $reason ) {
			return true;
		}
		if ( 'refund_notice_bad_response' !== $reason ) {
			return false;
		}

		$status = (int) ( $result['status'] ?? 0 );
		return 0 === $status
			|| ( $status >= 200 && $status < 300 )
			|| in_array( $status, array( 408, 425, 429 ), true )
			|| $status >= 500;
	}

	private static function log_refund_notice_failure(
		WC_Order $order,
		WC_Order_Refund $refund,
		string $reason,
		int $attempt,
		string $outcome
	): void {
		if ( ! class_exists( 'DUTT_SHD_Logger' ) ) {
			return;
		}

		DUTT_SHD_Logger::warning(
			'refund_notice_failed',
			array(
				'order_id'     => $order->get_id(),
				'order_number' => $order->get_order_number(),
				'refund_id'    => $refund->get_id(),
				'reason'       => $reason,
				'attempt'      => $attempt,
				'outcome'      => $outcome,
			)
		);
	}

	public static function handle_order_cancelled( int $order_id, $order = null ): void {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( ! self::has_dutt_delivery( $order ) ) {
			return;
		}

		$dutt_status = self::normalize_delivery_status( (string) $order->get_meta( 'dutt_status' ) );
		if ( self::is_terminal_success_status( $dutt_status ) ) {
			$order->update_meta_data( 'dutt_last_cancel_trigger', 'woocommerce_cancelled_status' );
			$order->update_meta_data( 'dutt_last_cancel_mode', 'automatic' );
			$order->update_meta_data( 'dutt_operation_result', 'cancel_ignored_after_delivery' );
			$order->update_meta_data( 'dutt_operation_mode', 'manual_review' );
			$order->update_meta_data( 'dutt_operation_stage', 'after_delivery' );
			$order->update_meta_data( 'dutt_operation_source', 'woocommerce_cancelled_status' );
			$order->update_meta_data( 'dutt_operation_note', 'WooCommerce cancellation was ignored because the Dutt delivery was already delivered. Use a refund for post-delivery financial adjustments.' );
			$order->add_order_note( 'WooCommerce cancellation was ignored because the Dutt delivery is already delivered. Use WooCommerce refund for post-delivery financial adjustments.' );
			$order->save();

			if ( 'completed' !== $order->get_status() ) {
				$order->update_status( 'completed', 'Dutt delivery is already delivered. Cancellation was reverted; use refund for post-delivery adjustments.' );
			}
			return;
		}

		DUTT_SHD_Order_Meta::auto_cancel_delivery_for_order( $order, 'woocommerce_cancelled_status' );
	}

	private static function has_dutt_delivery( WC_Order $order ): bool {
		if ( 'yes' === trim( (string) $order->get_meta( 'dutt_selected' ) ) ) {
			return true;
		}
		if ( '' !== trim( (string) $order->get_meta( 'dutt_delivery_id' ) ) ) {
			return true;
		}
		if ( '' !== trim( (string) $order->get_meta( 'mock_dutt_delivery_id' ) ) ) {
			return true;
		}
		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( 'dutt_same_hour_delivery' === $item->get_method_id() ) {
				return true;
			}
		}
		return false;
	}

	private static function is_full_refund( WC_Order $order, WC_Order_Refund $refund ): bool {
		$order_total_cents    = DUTT_SHD_WooCommerce_Fiscal::absolute_money_cents( $order->get_total() );
		$refund_amount_cents  = DUTT_SHD_WooCommerce_Fiscal::absolute_money_cents( $refund->get_amount() );
		$total_refunded_cents = DUTT_SHD_WooCommerce_Fiscal::absolute_money_cents( $order->get_total_refunded() );

		if ( $order_total_cents <= 0 ) {
			return false;
		}

		return $refund_amount_cents >= $order_total_cents || $total_refunded_cents >= $order_total_cents;
	}

	private static function is_cancelled_delivery_status( string $status ): bool {
		$status = self::normalize_delivery_status( $status );
		return 'cancelled' === $status || str_starts_with( $status, 'cancelled_' );
	}

	private static function normalize_delivery_status( string $status ): string {
		$status = sanitize_key( str_replace( '-', '_', strtolower( trim( $status ) ) ) );
		if ( 'canceled' === $status ) {
			$status = 'cancelled';
		}
		if ( 'canceled_by_admin' === $status ) {
			$status = 'cancelled_by_admin';
		}
		if ( 'canceled_by_merchant' === $status ) {
			$status = 'cancelled_by_merchant';
		}

		return $status;
	}

	private static function is_terminal_success_status( string $status ): bool {
		return in_array(
			self::normalize_delivery_status( $status ),
			array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ),
			true
		);
	}
}

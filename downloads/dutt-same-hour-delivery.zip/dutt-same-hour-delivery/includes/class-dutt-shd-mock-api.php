<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Mock_API {
	public static function get_quote( array $payload ): array {
		return DUTT_SHD_API_Client::get_quote( $payload );
	}

	public static function create_delivery( int $order_id ): array {
		return array(
			'success'     => true,
			'delivery_id' => 'mock_dutt_' . $order_id . '_' . wp_generate_password( 8, false, false ),
			'status'      => 'pending_dispatch',
		);
	}

	public static function cancel_delivery( string $delivery_id ): array {
		return array(
			'success'     => true,
			'delivery_id' => $delivery_id,
			'status'      => 'cancelled_by_admin',
		);
	}

	public static function get_delivery_status( string $delivery_id ): array {
		return array(
			'success'     => true,
			'delivery_id' => $delivery_id,
			'status'      => $delivery_id ? 'pending_dispatch' : 'not_created',
		);
	}
}

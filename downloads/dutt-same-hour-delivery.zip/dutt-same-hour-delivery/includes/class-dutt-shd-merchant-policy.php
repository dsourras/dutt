<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Merchant_Policy {
	const MERCHANT_AGREEMENT_VERSION = 'dutt-merchant-agreement-v1.0-2026-08-02';
	const PRIVACY_DPA_VERSION        = 'dutt-privacy-dpa-v1.0-2026-08-02';
	const REQUIRED_CURRENCY          = 'EUR';
	const REQUIRED_COUNTRY           = 'GR';
	const POLICY_EFFECTIVE_AT        = '2026-08-02T00:00:00+00:00';
	const MAX_CLOCK_SKEW_SECONDS     = 300;

	public static function normalize_currency( string $currency ): string {
		return strtoupper( trim( $currency ) );
	}

	public static function normalize_country( string $country ): string {
		$normalized = preg_replace( '/[^A-Z]/', '', strtoupper( trim( $country ) ) );
		if ( in_array( $normalized, array( 'GR', 'GRC', 'GREECE' ), true ) ) {
			return self::REQUIRED_COUNTRY;
		}

		return (string) $normalized;
	}

	public static function acceptance_timestamp_valid( string $accepted_at ): bool {
		$accepted_time  = strtotime( $accepted_at );
		$effective_time = strtotime( self::POLICY_EFFECTIVE_AT );

		return false !== $accepted_time
			&& $accepted_time >= $effective_time
			&& $accepted_time <= time() + self::MAX_CLOCK_SKEW_SECONDS;
	}

	public static function legal_acceptance_complete( array $settings ): bool {
		return 'yes' === (string) ( $settings['merchant_agreement_accepted'] ?? 'no' )
			&& self::MERCHANT_AGREEMENT_VERSION === (string) ( $settings['merchant_agreement_version'] ?? '' )
			&& self::acceptance_timestamp_valid( (string) ( $settings['merchant_agreement_accepted_at'] ?? '' ) )
			&& 'yes' === (string) ( $settings['privacy_dpa_accepted'] ?? 'no' )
			&& self::PRIVACY_DPA_VERSION === (string) ( $settings['privacy_dpa_version'] ?? '' )
			&& self::acceptance_timestamp_valid( (string) ( $settings['privacy_dpa_accepted_at'] ?? '' ) );
	}

	public static function validate(
		array $settings,
		string $currency,
		string $store_country,
		string $delivery_country
	): array {
		if ( 'yes' !== (string) ( $settings['merchant_agreement_accepted'] ?? 'no' ) ) {
			return array(
				'ok'     => false,
				'reason' => 'merchant_agreement_required',
			);
		}
		if ( self::MERCHANT_AGREEMENT_VERSION !== (string) ( $settings['merchant_agreement_version'] ?? '' ) ) {
			return array(
				'ok'     => false,
				'reason' => 'merchant_agreement_version_mismatch',
			);
		}
		if ( 'yes' !== (string) ( $settings['privacy_dpa_accepted'] ?? 'no' ) ) {
			return array(
				'ok'     => false,
				'reason' => 'privacy_dpa_required',
			);
		}
		if ( self::PRIVACY_DPA_VERSION !== (string) ( $settings['privacy_dpa_version'] ?? '' ) ) {
			return array(
				'ok'     => false,
				'reason' => 'privacy_dpa_version_mismatch',
			);
		}
		if ( ! self::legal_acceptance_complete( $settings ) ) {
			return array(
				'ok'     => false,
				'reason' => 'legal_acceptance_timestamp_invalid',
			);
		}
		if ( self::REQUIRED_CURRENCY !== self::normalize_currency( $currency ) ) {
			return array(
				'ok'                => false,
				'reason'            => 'unsupported_merchant_currency',
				'expected_currency' => self::REQUIRED_CURRENCY,
				'received_currency' => $currency,
			);
		}
		if ( self::REQUIRED_COUNTRY !== self::normalize_country( $store_country ) ) {
			return array(
				'ok'               => false,
				'reason'           => 'unsupported_merchant_country',
				'field'            => 'store_country',
				'expected_country' => self::REQUIRED_COUNTRY,
				'received_country' => $store_country,
			);
		}
		if ( self::REQUIRED_COUNTRY !== self::normalize_country( $delivery_country ) ) {
			return array(
				'ok'               => false,
				'reason'           => 'unsupported_merchant_country',
				'field'            => 'delivery_country',
				'expected_country' => self::REQUIRED_COUNTRY,
				'received_country' => $delivery_country,
			);
		}

		return array( 'ok' => true );
	}

	public static function payload( array $settings, string $delivery_country = self::REQUIRED_COUNTRY ): array {
		return array(
			'merchant_legal'     => array(
				'merchant_agreement' => array(
					'accepted'    => true,
					'version'     => (string) ( $settings['merchant_agreement_version'] ?? '' ),
					'accepted_at' => (string) ( $settings['merchant_agreement_accepted_at'] ?? '' ),
				),
				'privacy_dpa'        => array(
					'accepted'    => true,
					'version'     => (string) ( $settings['privacy_dpa_version'] ?? '' ),
					'accepted_at' => (string) ( $settings['privacy_dpa_accepted_at'] ?? '' ),
				),
			),
			'integration_market' => array(
				'currency'         => self::REQUIRED_CURRENCY,
				'store_country'    => self::REQUIRED_COUNTRY,
				'delivery_country' => self::normalize_country( $delivery_country ),
			),
		);
	}
}

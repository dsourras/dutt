<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Eligibility_Service {
	const META_MANUAL         = '_dutt_eligibility';
	const META_SCANNER_RESULT = '_dutt_scanner_result';
	const META_SCANNER_REASON = '_dutt_scanner_reason';
	const META_SCANNED_AT     = '_dutt_scanned_at';

	public static function statuses(): array {
		return array( 'eligible', 'not_eligible', 'review' );
	}

	public static function scan_product( int $product_id ): array {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return self::result( 'review', 'missing_product' );
		}

		$package_guard = self::package_guard( $product );
		if ( ! $package_guard['ok'] ) {
			return self::result( 'not_eligible', $package_guard['reason'] );
		}

		$category_status = DUTT_SHD_Category_Eligibility::product_status( $product_id );
		if ( 'eligible' === $category_status['status'] ) {
			return self::result( 'eligible', $category_status['reason'] );
		}

		if ( 'not_eligible' === $category_status['status'] ) {
			return self::result( 'not_eligible', $category_status['reason'] );
		}

		return self::result( 'review', $category_status['reason'] ?: 'category_needs_review' );
	}

	public static function save_scan_result( int $product_id ): array {
		$result = self::scan_product( $product_id );
		update_post_meta( $product_id, self::META_SCANNER_RESULT, $result['status'] );
		update_post_meta( $product_id, self::META_SCANNER_REASON, $result['reason'] );
		update_post_meta( $product_id, self::META_SCANNED_AT, current_time( 'mysql' ) );
		return $result;
	}

	public static function effective_status( int $product_id ): array {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return self::result( 'review', 'missing_product' );
		}

		$package_guard = self::package_guard( $product );
		if ( ! $package_guard['ok'] ) {
			return self::result( 'not_eligible', $package_guard['reason'] );
		}

		$manual = get_post_meta( $product_id, self::META_MANUAL, true );
		if ( in_array( $manual, self::statuses(), true ) ) {
			return self::result( $manual, 'manual_' . $manual );
		}

		$category_status = DUTT_SHD_Category_Eligibility::product_status( $product_id );
		if ( in_array( $category_status['status'], self::statuses(), true ) ) {
			return self::result( $category_status['status'], $category_status['reason'] );
		}

		return self::result( 'review', 'category_needs_review' );
	}

	public static function effective_status_without_package_guard( int $product_id ): array {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return self::result( 'review', 'missing_product' );
		}

		$manual = get_post_meta( $product_id, self::META_MANUAL, true );
		if ( in_array( $manual, self::statuses(), true ) ) {
			return self::result( $manual, 'manual_' . $manual );
		}

		$category_status = DUTT_SHD_Category_Eligibility::product_status( $product_id );
		if ( in_array( $category_status['status'], self::statuses(), true ) ) {
			return self::result( $category_status['status'], $category_status['reason'] );
		}

		return self::result( 'review', 'category_needs_review' );
	}

	private static function package_guard( WC_Product $product ): array {
		$settings = DUTT_SHD_Settings::all();
		$weight   = self::number_or_null( $product->get_weight() );
		$length   = self::number_or_null( $product->get_length() );
		$width    = self::number_or_null( $product->get_width() );
		$height   = self::number_or_null( $product->get_height() );

		if ( null !== $weight && $weight > (float) $settings['max_weight_kg'] ) {
			return array(
				'ok'     => false,
				'reason' => 'overweight',
			);
		}

		if (
			( null !== $length && $length > (float) $settings['max_length_cm'] ) ||
			( null !== $width && $width > (float) $settings['max_width_cm'] ) ||
			( null !== $height && $height > (float) $settings['max_height_cm'] )
		) {
			return array(
				'ok'     => false,
				'reason' => 'oversized',
			);
		}

		return array(
			'ok'     => true,
			'reason' => '',
		);
	}

	private static function number_or_null( $value ): ?float {
		if ( '' === $value || null === $value ) {
			return null;
		}

		$number = (float) $value;
		return is_finite( $number ) ? $number : null;
	}

	private static function result( string $status, string $reason ): array {
		return array(
			'status' => $status,
			'reason' => $reason,
		);
	}
}

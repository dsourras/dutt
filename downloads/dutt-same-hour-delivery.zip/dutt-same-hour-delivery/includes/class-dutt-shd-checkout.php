<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Checkout {
	public static function init(): void {
		add_filter( 'woocommerce_shipping_methods', array( __CLASS__, 'register_shipping_method' ) );
		add_filter( 'woocommerce_cart_shipping_method_full_label', array( __CLASS__, 'shipping_method_full_label' ), 10, 2 );
		add_filter( 'woocommerce_shipping_method_add_rate', array( __CLASS__, 'hydrate_shipping_rate_for_blocks' ), 10, 3 );
		add_filter( 'woocommerce_available_payment_gateways', array( __CLASS__, 'disable_cod_for_dutt' ), 20 );
		add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_payment_method' ), 20, 2 );
		add_action( 'woocommerce_init', array( __CLASS__, 'maybe_install_shipping_method_in_zones' ) );
	}

	public static function register_shipping_method( array $methods ): array {
		$methods['dutt_same_hour_delivery'] = 'DUTT_SHD_Shipping_Method';
		return $methods;
	}

	public static function maybe_install_shipping_method_in_zones(): void {
		if ( 'yes' !== get_option( 'dutt_shd_needs_zone_install', 'no' ) || ! class_exists( 'WC_Shipping_Zones' ) ) {
			return;
		}

		$zones          = WC_Shipping_Zones::get_zones();
		$greek_zone_ids = array();
		foreach ( $zones as $zone_data ) {
			$zone = new WC_Shipping_Zone( (int) $zone_data['id'] );
			if ( self::zone_locations_include_greece( $zone->get_zone_locations() ) ) {
				$greek_zone_ids[] = (int) $zone_data['id'];
			}
		}

		if ( empty( $greek_zone_ids ) ) {
			$zone = new WC_Shipping_Zone();
			$zone->set_zone_name( 'DUTT Greece' );
			$zone->set_locations(
				array(
					array(
						'code' => 'GR',
						'type' => 'country',
					),
				)
			);
			$zone->save();
			$greek_zone_ids[] = (int) $zone->get_id();
		}

		foreach ( $greek_zone_ids as $zone_id ) {
			$zone       = new WC_Shipping_Zone( $zone_id );
			$has_method = false;
			foreach ( $zone->get_shipping_methods() as $method ) {
				if ( 'dutt_same_hour_delivery' === $method->id ) {
					$has_method = true;
					break;
				}
			}

			if ( ! $has_method ) {
				$instance_id = $zone->add_shipping_method( 'dutt_same_hour_delivery' );
				update_option(
					'woocommerce_dutt_same_hour_delivery_' . $instance_id . '_settings',
					array(
						'enabled' => 'yes',
						'title'   => 'DUTT Same Hour Delivery',
					)
				);
			}
		}

		update_option( 'dutt_shd_needs_zone_install', 'no' );
	}

	public static function zone_locations_include_greece( array $locations ): bool {
		foreach ( $locations as $location ) {
			$type = is_object( $location ) ? (string) ( $location->type ?? '' ) : (string) ( $location['type'] ?? '' );
			$code = is_object( $location ) ? (string) ( $location->code ?? '' ) : (string) ( $location['code'] ?? '' );
			$type = strtolower( trim( $type ) );
			$code = strtoupper( trim( $code ) );

			if ( ( 'country' === $type && 'GR' === $code ) || ( 'state' === $type && str_starts_with( $code, 'GR:' ) ) ) {
				return true;
			}
			if ( 'continent' === $type && 'EU' === $code ) {
				return true;
			}
		}

		return false;
	}

	public static function evaluate_package( array $package ): array {
		$settings = DUTT_SHD_Settings::all();
		$settings = DUTT_SHD_Settings::settings_for_active_location( $settings );

		if ( ! DUTT_SHD_Settings::is_enabled() ) {
			return self::unavailable( 'plugin_disabled' );
		}

		if ( ! self::inside_service_hours( $settings['service_start'], $settings['service_end'] ) ) {
			return self::unavailable( 'outside_service_hours' );
		}

		if ( 'mock' === $settings['api_mode'] && 'available' !== $settings['mock_rider_availability'] ) {
			return self::unavailable( 'no_riders_available' );
		}

		if ( self::is_cod_selected() ) {
			return self::unavailable( 'payment_not_supported' );
		}

		$destination = $package['destination'] ?? array();
		$city        = trim( (string) ( $destination['city'] ?? '' ) );
		$address     = trim( (string) ( $destination['address'] ?? '' ) );
		$postcode    = trim( (string) ( $destination['postcode'] ?? '' ) );

		if ( '' === $city || '' === $address ) {
			return self::unavailable( 'invalid_address' );
		}

		$cart_check = self::check_cart_contents( $package, $settings );
		if ( ! $cart_check['ok'] ) {
			return self::unavailable( $cart_check['reason'] );
		}

		$metrics = self::package_metrics( $package );
		$quote   = DUTT_SHD_API_Client::get_quote(
			array(
				'city'          => $city,
				'address'       => $address,
				'postcode'      => $postcode,
				'country'       => $destination['country'] ?? 'GR',
				'weight_kg'     => $metrics['weight_kg'],
				'length_cm'     => $metrics['length_cm'],
				'width_cm'      => $metrics['width_cm'],
				'height_cm'     => $metrics['height_cm'],
				'cart_subtotal' => self::package_subtotal( $package ),
			)
		);

		if ( empty( $quote['success'] ) ) {
			return self::unavailable( $quote['reason'] ?? 'quote_failed' );
		}

		return array(
			'available' => true,
			'quote'     => $quote,
		);
	}

	public static function shipping_method_full_label( string $label, WC_Shipping_Rate $method ): string {
		if ( 'dutt_same_hour_delivery' !== $method->get_method_id() ) {
			return $label;
		}

		$settings     = DUTT_SHD_Settings::all();
		$quote        = self::current_checkout_quote( array( $method->get_id() ) );
		$estimate     = is_array( $quote ) && ! empty( $quote['estimated_time'] )
			? $quote['estimated_time']
			: $settings['api_default_estimated_time'];
		$pricing_note = is_array( $quote ) ? self::customer_pricing_note( $quote ) : '';

		$parts = array(
			'<small class="dutt-shd-estimate">Delivery estimate: ' . esc_html( $estimate ) . '</small>',
		);
		if ( '' !== $pricing_note ) {
			$parts[] = '<small class="dutt-shd-pricing-note">' . esc_html( $pricing_note ) . '</small>';
		}

		return $label . '<br>' . implode( '<br>', $parts );
	}

	public static function hydrate_shipping_rate_for_blocks( WC_Shipping_Rate $rate, array $args, WC_Shipping_Method $method ): WC_Shipping_Rate {
		if ( 'dutt_same_hour_delivery' !== $method->id ) {
			return $rate;
		}

		$estimate = '';
		if ( isset( $args['meta_data']['DUTT estimate'] ) ) {
			$estimate = str_replace( 'Approximately ', '', (string) $args['meta_data']['DUTT estimate'] );
		}
		$pricing_note = isset( $args['meta_data']['DUTT pricing note'] ) ? (string) $args['meta_data']['DUTT pricing note'] : '';

		if ( '' !== $estimate ) {
			$description = 'DUTT same-hour delivery.';
			if ( '' !== $pricing_note ) {
				$description .= ' ' . $pricing_note;
			}
			$rate->set_description( $description );
			$rate->set_delivery_time( $estimate );
		}

		return $rate;
	}

	public static function disable_cod_for_dutt( array $gateways ): array {
		if ( self::chosen_shipping_uses_dutt() ) {
			unset( $gateways['cod'] );
		}

		return $gateways;
	}

	public static function validate_payment_method( array $data, $errors ): void {
		$payment_method  = sanitize_key( (string) ( $data['payment_method'] ?? '' ) );
		$shipping_method = $data['shipping_method'] ?? array();

		if ( ! self::shipping_methods_use_dutt( $shipping_method ) ) {
			return;
		}
		if ( 1 !== count( (array) $shipping_method ) ) {
			if ( is_object( $errors ) && method_exists( $errors, 'add' ) ) {
				$errors->add(
					'dutt_split_shipping_unsupported',
					__( 'DUTT delivery cannot be combined with split-package shipping in the same order.', 'dutt-same-hour-delivery' )
				);
			}
			return;
		}

		$quote = self::current_checkout_quote( $shipping_method );
		if ( ! self::valid_checkout_quote( $quote ) ) {
			if ( is_object( $errors ) && method_exists( $errors, 'add' ) ) {
				$errors->add(
					'dutt_quote_missing',
					__( 'The DUTT delivery quote is no longer valid. Please refresh checkout and try again.', 'dutt-same-hour-delivery' )
				);
			}
			return;
		}

		if ( 'cod' !== $payment_method ) {
			return;
		}

		if ( is_object( $errors ) && method_exists( $errors, 'add' ) ) {
			$errors->add(
				'dutt_cod_disabled',
				__( 'Cash on delivery is not available for DUTT deliveries. Please choose another payment method.', 'dutt-same-hour-delivery' )
			);
		}
	}

	public static function valid_checkout_quote( $quote ): bool {
		if (
			! is_array( $quote ) ||
			! DUTT_SHD_API_Client::valid_quote_contract( $quote )
		) {
			return false;
		}

		foreach ( array( 'quote_price', 'customer_charge', 'store_contribution', 'settlement_due' ) as $key ) {
			if ( ! array_key_exists( $key, $quote ) || ! is_numeric( $quote[ $key ] ) || ! is_finite( (float) $quote[ $key ] ) || (float) $quote[ $key ] < 0 ) {
				return false;
			}
		}

		$quote_price        = (float) $quote['quote_price'];
		$customer_charge    = (float) $quote['customer_charge'];
		$store_contribution = (float) $quote['store_contribution'];
		$quote_expires_at   = (float) $quote['quote_expires_at'];
		if ( $quote_expires_at <= round( microtime( true ) * 1000 ) ) {
			return false;
		}
		if ( (int) round( $customer_charge * 100 ) + (int) round( $store_contribution * 100 ) !== (int) round( $quote_price * 100 ) ) {
			return false;
		}

		return '' !== trim( (string) ( $quote['charge_policy'] ?? '' ) );
	}

	public static function store_rate_quote( string $rate_id, array $quote ): void {
		$woocommerce = WC();
		if ( '' === trim( $rate_id ) || ! $woocommerce || ! $woocommerce->session ) {
			return;
		}

		$quotes             = $woocommerce->session->get( 'dutt_shd_quotes_by_rate', array() );
		$quotes             = is_array( $quotes ) ? $quotes : array();
		$quotes[ $rate_id ] = $quote;
		if ( count( $quotes ) > 20 ) {
			$quotes = array_slice( $quotes, -20, null, true );
		}
		$woocommerce->session->set( 'dutt_shd_quotes_by_rate', $quotes );
		$woocommerce->session->set( 'dutt_shd_last_quote', $quote );
	}

	public static function clear_rate_quote( string $rate_id ): void {
		$woocommerce = WC();
		if ( '' === trim( $rate_id ) || ! $woocommerce || ! $woocommerce->session ) {
			return;
		}

		$quotes = $woocommerce->session->get( 'dutt_shd_quotes_by_rate', array() );
		if ( ! is_array( $quotes ) || ! array_key_exists( $rate_id, $quotes ) ) {
			return;
		}
		unset( $quotes[ $rate_id ] );
		$woocommerce->session->set( 'dutt_shd_quotes_by_rate', $quotes );
	}

	public static function current_checkout_quote( $shipping_methods = null ) {
		$woocommerce = WC();
		if ( ! $woocommerce || ! $woocommerce->session ) {
			return null;
		}

		if ( null === $shipping_methods ) {
			$shipping_methods = $woocommerce->session->get( 'chosen_shipping_methods', array() );
		}
		return self::quote_for_shipping_methods(
			$shipping_methods,
			$woocommerce->session->get( 'dutt_shd_quotes_by_rate', array() ),
			$woocommerce->session->get( 'dutt_shd_last_quote' )
		);
	}

	public static function quote_for_shipping_methods( $shipping_methods, $quotes_by_rate, $legacy_quote = null ) {
		$shipping_methods = array_values( array_filter( array_map( 'strval', (array) $shipping_methods ) ) );
		if ( 1 !== count( $shipping_methods ) ) {
			return null;
		}
		$dutt_rate_ids = array_values(
			array_filter(
				$shipping_methods,
				static fn( string $rate_id ): bool => self::shipping_methods_use_dutt( array( $rate_id ) )
			)
		);
		if ( 1 !== count( $dutt_rate_ids ) ) {
			return null;
		}

		$quotes_by_rate = is_array( $quotes_by_rate ) ? $quotes_by_rate : array();
		$rate_id        = $dutt_rate_ids[0];
		if ( isset( $quotes_by_rate[ $rate_id ] ) && is_array( $quotes_by_rate[ $rate_id ] ) ) {
			return $quotes_by_rate[ $rate_id ];
		}

		return null;
	}

	public static function shipping_methods_use_dutt( $shipping_methods ): bool {
		foreach ( (array) $shipping_methods as $shipping_method ) {
			$method_id = sanitize_key( explode( ':', (string) $shipping_method, 2 )[0] );
			if ( 'dutt_same_hour_delivery' === $method_id ) {
				return true;
			}
		}

		return false;
	}

	public static function log_unavailable( string $reason, array $context = array() ): void {
		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'shipping_hidden',
				array_merge(
					array( 'reason' => $reason ),
					$context
				)
			);
		}
	}

	public static function charge_policy_label( string $policy ): string {
		$labels = array(
			'full_quote'            => 'Customer pays full DUTT quote at checkout',
			'store_absorbs'         => 'Store pays full delivery; customer sees free delivery',
			'free_over_threshold'   => 'Free delivery over order amount; otherwise customer pays quote',
			'fixed_customer_amount' => 'Customer pays fixed amount; store pays the difference',
		);

		return $labels[ $policy ] ?? $policy;
	}

	public static function customer_pricing_note( array $quote ): string {
		$policy             = (string) ( $quote['charge_policy'] ?? '' );
		$customer_charge    = max( 0.0, (float) ( $quote['customer_charge'] ?? $quote['price'] ?? 0 ) );
		$store_contribution = max( 0.0, (float) ( $quote['store_contribution'] ?? 0 ) );

		if ( $customer_charge <= 0.0 && $store_contribution > 0.0 ) {
			return 'The store covers the DUTT delivery cost for this order.';
		}

		if ( 'fixed_customer_amount' === $policy && $store_contribution > 0.0 ) {
			return 'You pay the fixed delivery amount; the store covers the remaining DUTT cost.';
		}

		if ( 'free_over_threshold' === $policy && $store_contribution > 0.0 ) {
			return 'Free DUTT delivery applies to this order; the store covers the delivery cost.';
		}

		if ( $store_contribution > 0.0 ) {
			return 'Part of the DUTT delivery cost is covered by the store.';
		}

		return 'You pay the DUTT delivery charge shown here.';
	}

	private static function check_cart_contents( array $package, array $settings ): array {
		$total_weight = 0.0;
		foreach ( $package['contents'] ?? array() as $cart_item ) {
			$product = $cart_item['data'] ?? null;
			if ( ! $product instanceof WC_Product ) {
				return array(
					'ok'     => false,
					'reason' => 'product_not_eligible',
				);
			}

			$product_id     = (int) $product->get_id();
			$location_rules = self::check_location_product_rules( $product, $settings );
			if ( ! $location_rules['ok'] ) {
				return array(
					'ok'     => false,
					'reason' => $location_rules['reason'],
				);
			}

			$eligibility = DUTT_SHD_Eligibility_Service::effective_status_without_package_guard( $product_id );
			if ( 'not_eligible' === $eligibility['status'] ) {
				return array(
					'ok'     => false,
					'reason' => 'product_not_eligible',
				);
			}
			if ( ! $location_rules['has_allow_rules'] && 'eligible' !== $eligibility['status'] ) {
				return array(
					'ok'     => false,
					'reason' => 'product_not_eligible',
				);
			}

			$qty           = isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 1;
			$total_weight += (float) $product->get_weight() * max( 1, $qty );

			if (
				( (float) $product->get_length() > (float) $settings['max_length_cm'] ) ||
				( (float) $product->get_width() > (float) $settings['max_width_cm'] ) ||
				( (float) $product->get_height() > (float) $settings['max_height_cm'] )
			) {
				return array(
					'ok'     => false,
					'reason' => 'oversized',
				);
			}
		}

		if ( $total_weight > (float) $settings['max_weight_kg'] ) {
			return array(
				'ok'     => false,
				'reason' => 'overweight',
			);
		}

		return array(
			'ok'     => true,
			'reason' => '',
		);
	}

	private static function check_location_product_rules( WC_Product $product, array $settings ): array {
		$product_ids      = self::product_lookup_ids( $product );
		$category_ids     = self::product_category_ids( $product_ids );
		$deny_products    = self::setting_id_list( $settings, 'not_eligible_product_ids' );
		$deny_categories  = self::setting_id_list( $settings, 'not_eligible_category_ids' );
		$allow_products   = self::setting_id_list( $settings, 'eligible_product_ids' );
		$allow_categories = self::setting_id_list( $settings, 'eligible_category_ids' );

		if ( self::intersects( $product_ids, $deny_products ) || self::intersects( $category_ids, $deny_categories ) ) {
			return array(
				'ok'              => false,
				'reason'          => 'product_not_eligible',
				'has_allow_rules' => ! empty( $allow_products ) || ! empty( $allow_categories ),
			);
		}

		$has_allow_rules = ! empty( $allow_products ) || ! empty( $allow_categories );
		if ( $has_allow_rules && ! self::intersects( $product_ids, $allow_products ) && ! self::intersects( $category_ids, $allow_categories ) ) {
			return array(
				'ok'              => false,
				'reason'          => 'product_not_eligible',
				'has_allow_rules' => true,
			);
		}

		return array(
			'ok'              => true,
			'reason'          => '',
			'has_allow_rules' => $has_allow_rules,
		);
	}

	private static function product_lookup_ids( WC_Product $product ): array {
		$ids = array( (int) $product->get_id() );
		if ( method_exists( $product, 'get_parent_id' ) ) {
			$parent_id = (int) $product->get_parent_id();
			if ( $parent_id > 0 ) {
				$ids[] = $parent_id;
			}
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	private static function product_category_ids( array $product_ids ): array {
		$category_ids = array();
		foreach ( $product_ids as $product_id ) {
			if ( function_exists( 'wc_get_product_cat_ids' ) ) {
				$category_ids = array_merge( $category_ids, array_map( 'absint', wc_get_product_cat_ids( (int) $product_id ) ) );
				continue;
			}

			$terms = get_the_terms( (int) $product_id, 'product_cat' );
			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$category_ids[] = absint( $term->term_id );
				}
			}
		}
		return array_values( array_unique( array_filter( $category_ids ) ) );
	}

	private static function setting_id_list( array $settings, string $key ): array {
		$value = $settings[ $key ] ?? array();
		if ( is_string( $value ) ) {
			$value = preg_split( '/[,\s]+/', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		return array_values(
			array_unique(
				array_filter(
					array_map( 'absint', $value )
				)
			)
		);
	}

	private static function intersects( array $left, array $right ): bool {
		if ( empty( $left ) || empty( $right ) ) {
			return false;
		}
		return ! empty( array_intersect( $left, $right ) );
	}

	private static function package_subtotal( array $package ): float {
		if ( isset( $package['contents_cost'] ) && is_numeric( $package['contents_cost'] ) ) {
			return max( 0.0, (float) $package['contents_cost'] );
		}

		$subtotal = 0.0;
		foreach ( $package['contents'] ?? array() as $cart_item ) {
			$subtotal += isset( $cart_item['line_total'] ) ? (float) $cart_item['line_total'] : 0.0;
		}

		return max( 0.0, $subtotal );
	}

	private static function package_metrics( array $package ): array {
		$total_weight = 0.0;
		$max_length   = 0.0;
		$max_width    = 0.0;
		$max_height   = 0.0;

		foreach ( $package['contents'] ?? array() as $cart_item ) {
			$product = $cart_item['data'] ?? null;
			if ( ! $product instanceof WC_Product ) {
				continue;
			}

			$qty           = isset( $cart_item['quantity'] ) ? max( 1, (int) $cart_item['quantity'] ) : 1;
			$total_weight += (float) $product->get_weight() * $qty;
			$max_length    = max( $max_length, (float) $product->get_length() );
			$max_width     = max( $max_width, (float) $product->get_width() );
			$max_height    = max( $max_height, (float) $product->get_height() );
		}

		return array(
			'weight_kg' => round( $total_weight, 3 ),
			'length_cm' => round( $max_length, 2 ),
			'width_cm'  => round( $max_width, 2 ),
			'height_cm' => round( $max_height, 2 ),
		);
	}

	private static function is_cod_selected(): bool {
		if ( ! WC()->session ) {
			return false;
		}
		return 'cod' === WC()->session->get( 'chosen_payment_method' );
	}

	private static function chosen_shipping_uses_dutt(): bool {
		if ( ! WC()->session ) {
			return false;
		}

		return self::shipping_methods_use_dutt( WC()->session->get( 'chosen_shipping_methods', array() ) );
	}

	private static function inside_service_hours( string $start, string $end ): bool {
		$now           = current_time( 'H:i' );
		$start_minutes = self::time_to_minutes( $start );
		$end_minutes   = self::time_to_minutes( $end );
		$now_minutes   = self::time_to_minutes( $now );

		if ( null === $start_minutes || null === $end_minutes || null === $now_minutes ) {
			return false;
		}

		if ( $start_minutes <= $end_minutes ) {
			return $now_minutes >= $start_minutes && $now_minutes <= $end_minutes;
		}

		return $now_minutes >= $start_minutes || $now_minutes <= $end_minutes;
	}

	private static function time_to_minutes( string $time ): ?int {
		if ( ! preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', trim( $time ), $matches ) ) {
			return null;
		}
		return ( (int) $matches[1] * 60 ) + (int) $matches[2];
	}

	private static function same_city( string $checkout_city, string $store_city ): bool {
		$checkout = self::normalize_city_for_compare( $checkout_city );
		$store    = self::normalize_city_for_compare( $store_city );
		return $checkout === $store;
	}

	private static function normalize_city_for_compare( string $city ): string {
		$city = mb_strtolower( trim( $city ), 'UTF-8' );
		$city = strtr(
			$city,
			array(
				'ά' => 'α',
				'έ' => 'ε',
				'ή' => 'η',
				'ί' => 'ι',
				'ϊ' => 'ι',
				'ΐ' => 'ι',
				'ό' => 'ο',
				'ύ' => 'υ',
				'ϋ' => 'υ',
				'ΰ' => 'υ',
				'ώ' => 'ω',
			)
		);
		$city = strtr(
			$city,
			array(
				'α' => 'a',
				'β' => 'v',
				'γ' => 'g',
				'δ' => 'd',
				'ε' => 'e',
				'ζ' => 'z',
				'η' => 'i',
				'θ' => 'th',
				'ι' => 'i',
				'κ' => 'k',
				'λ' => 'l',
				'μ' => 'm',
				'ν' => 'n',
				'ξ' => 'x',
				'ο' => 'o',
				'π' => 'p',
				'ρ' => 'r',
				'σ' => 's',
				'ς' => 's',
				'τ' => 't',
				'υ' => 'y',
				'φ' => 'f',
				'χ' => 'ch',
				'ψ' => 'ps',
				'ω' => 'o',
			)
		);
		$city = preg_replace( '/[^a-z0-9]+/', ' ', $city );

		return preg_replace( '/\s+/', ' ', trim( (string) $city ) );
	}

	private static function normalize_city( string $city ): string {
		$city = mb_strtolower( trim( $city ) );
		$city = strtr(
			$city,
			array(
				'ά' => 'α',
				'έ' => 'ε',
				'ή' => 'η',
				'ί' => 'ι',
				'ό' => 'ο',
				'ύ' => 'υ',
				'ώ' => 'ω',
				'ϊ' => 'ι',
				'ΐ' => 'ι',
				'ϋ' => 'υ',
				'ΰ' => 'υ',
			)
		);

		return preg_replace( '/\s+/', ' ', $city );
	}

	private static function unavailable( string $reason ): array {
		return array(
			'available' => false,
			'reason'    => $reason,
		);
	}
}

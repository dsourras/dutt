<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Product_Eligibility {
	public static function init(): void {
		add_action( 'woocommerce_product_options_shipping', array( __CLASS__, 'render_field' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_field' ) );
	}

	public static function render_field(): void {
		global $post;

		echo '<div class="options_group">';
		woocommerce_wp_select(
			array(
				'id'          => DUTT_SHD_Eligibility_Service::META_MANUAL,
				'label'       => 'DUTT Eligibility',
				'description' => 'Optional product override. Auto uses the DUTT category eligibility settings.',
				'desc_tip'    => true,
				'value'       => get_post_meta( $post->ID, DUTT_SHD_Eligibility_Service::META_MANUAL, true ) ?: 'auto',
				'options'     => array(
					'auto'         => 'Auto',
					'eligible'     => 'Eligible for motorcycle delivery',
					'not_eligible' => 'Not eligible',
					'review'       => 'Needs review',
				),
			)
		);

		$result = get_post_meta( $post->ID, DUTT_SHD_Eligibility_Service::META_SCANNER_RESULT, true );
		$reason = get_post_meta( $post->ID, DUTT_SHD_Eligibility_Service::META_SCANNER_REASON, true );
		if ( $result ) {
			echo '<p class="form-field"><label>Scanner suggestion</label><span>' . esc_html( $result . ' / ' . $reason ) . '</span></p>';
		}
		echo '</div>';
	}

	public static function save_field( int $post_id ): void {

		if (
			! isset( $_POST['woocommerce_meta_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woocommerce_meta_nonce'] ) ), 'woocommerce_save_data' )
		) {
			return;
		}

		$value = isset( $_POST[ DUTT_SHD_Eligibility_Service::META_MANUAL ] )
			? sanitize_text_field( wp_unslash( $_POST[ DUTT_SHD_Eligibility_Service::META_MANUAL ] ) )
		: 'auto';
		if ( ! in_array( $value, array( 'auto', 'eligible', 'not_eligible', 'review' ), true ) ) {
			$value = 'auto';
		}

		update_post_meta( $post_id, DUTT_SHD_Eligibility_Service::META_MANUAL, $value );
	}
}

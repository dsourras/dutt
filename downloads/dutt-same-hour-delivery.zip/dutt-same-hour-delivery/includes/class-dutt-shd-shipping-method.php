<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Shipping_Method extends WC_Shipping_Method {
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'dutt_same_hour_delivery';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = 'DUTT Same Hour Delivery';
		$this->method_description = 'Same-hour motorcycle delivery using DUTT API quotes.';
		$this->supports           = array( 'shipping-zones', 'instance-settings' );
		$this->tax_status         = 'taxable';

		$this->init();
	}

	public function init(): void {
		$this->instance_form_fields = array(
			'enabled' => array(
				'title'   => 'Enable this shipping method instance',
				'type'    => 'checkbox',
				'label'   => 'Enable DUTT for this shipping zone',
				'default' => 'yes',
			),
			'title'   => array(
				'title'   => 'Method title',
				'type'    => 'text',
				'default' => 'DUTT Same Hour Delivery',
			),
		);

		$this->init_settings();
		$this->enabled = $this->get_option( 'enabled', 'yes' );
		$this->title   = $this->get_option( 'title', 'DUTT Same Hour Delivery' );

		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	public function calculate_shipping( $package = array() ): void {
		if ( 'yes' !== $this->enabled ) {
			DUTT_SHD_Checkout::log_unavailable( 'method_instance_disabled', $this->package_log_context( $package ) );
			return;
		}

		$result = DUTT_SHD_Checkout::evaluate_package( $package );
		if ( empty( $result['available'] ) ) {
			DUTT_SHD_Checkout::log_unavailable( $result['reason'] ?? 'unknown', $this->package_log_context( $package ) );
			return;
		}

		$quote = $result['quote'];
		if ( ! isset( $quote['customer_charge'] ) || ! is_numeric( $quote['customer_charge'] ) ) {
			DUTT_SHD_Checkout::log_unavailable( 'backend_charge_missing', $this->package_log_context( $package ) );
			return;
		}

		$pricing_note = DUTT_SHD_Checkout::customer_pricing_note( $quote );
		$this->add_rate(
			array(
				'id'        => $this->get_rate_id(),
				'label'     => $this->title,
				'cost'      => (float) $quote['customer_charge'],
				'package'   => $package,
				'meta_data' => array(
					'DUTT estimate'        => 'Approximately ' . $quote['estimated_time'],
					'DUTT distance'        => isset( $quote['distance_km'] ) ? $quote['distance_km'] . ' km' : '',
					'DUTT pricing version' => $quote['pricing_version'] ?? '',
					'DUTT pricing note'    => $pricing_note,
				),
			)
		);

		if ( WC()->session ) {
			WC()->session->set( 'dutt_shd_last_quote', $quote );
		}

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'shipping_rate_added',
				array_merge(
					$this->package_log_context( $package ),
					array(
						'customer_charge'    => $quote['customer_charge'],
						'store_contribution' => $quote['store_contribution'] ?? '',
						'charge_policy'      => $quote['charge_policy'] ?? '',
						'distance_km'        => $quote['distance_km'] ?? '',
						'estimated_time'     => $quote['estimated_time'] ?? '',
						'pricing_version'    => $quote['pricing_version'] ?? '',
					)
				)
			);
		}
	}

	private function package_log_context( array $package ): array {
		$destination = $package['destination'] ?? array();
		return array(
			'instance_id' => $this->instance_id,
			'city'        => $destination['city'] ?? '',
			'postcode'    => $destination['postcode'] ?? '',
			'country'     => $destination['country'] ?? '',
			'items_count' => count( $package['contents'] ?? array() ),
		);
	}
}

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Scanner_Admin {
	const OPTION_OFFSET = 'dutt_shd_scanner_offset';
	const BATCH_SIZE    = 20;

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 20 );
	}

	public static function add_menu(): void {
		add_submenu_page(
			DUTT_SHD_Onboarding::PARENT_MENU_SLUG,
			'Product Eligibility Scanner',
			'Product Eligibility Scanner',
			'manage_woocommerce',
			'dutt-product-scanner',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'dutt-same-hour-delivery' ) );
		}

		$results = array();
		if ( isset( $_POST['dutt_shd_scan'] ) && check_admin_referer( 'dutt_shd_scan_products' ) ) {
			if ( 'reset' === sanitize_key( wp_unslash( (string) $_POST['dutt_shd_scan'] ) ) ) {
				update_option( self::OPTION_OFFSET, 0 );
			}
			$results = self::process_batch( self::BATCH_SIZE );
		}

		$total  = (int) wp_count_posts( 'product' )->publish;
		$offset = max( 0, (int) get_option( self::OPTION_OFFSET, 0 ) );
		if ( $offset > $total ) {
			$offset = $total;
			update_option( self::OPTION_OFFSET, $offset );
		}
		$is_complete = $total > 0 && $offset >= $total;

		echo '<div class="wrap">';
		echo '<h1>DUTT product eligibility check</h1>';
		echo '<p>This tool checks products in small batches, so large WooCommerce shops do not freeze while the plugin reviews the catalog.</p>';
		echo '<p>It saves a suggestion for each product. The final Dutt availability is still controlled by approved categories, product-level overrides, weight and dimensions.</p>';
		echo '<p><strong>Checked products:</strong> ' . esc_html( (string) $offset ) . ' of ' . esc_html( (string) $total ) . '</p>';
		if ( $is_complete ) {
			echo '<div class="notice notice-success inline"><p>All published products have been checked. You can start again if categories, weights or dimensions changed.</p></div>';
		}
		echo '<form method="post">';
		wp_nonce_field( 'dutt_shd_scan_products' );
		submit_button( 'Check next ' . self::BATCH_SIZE . ' products', 'primary', 'dutt_shd_scan', false, $is_complete ? array( 'disabled' => 'disabled' ) : array() );
		echo ' ';
		echo '<button type="submit" class="button" name="dutt_shd_scan" value="reset">Start again from first product</button>';
		echo '</form>';

		if ( $results ) {
			echo '<h2>Checked in this batch</h2>';
			echo '<table class="widefat striped"><thead><tr><th>Product</th><th>SKU</th><th>Dutt suggestion</th><th>Reason</th></tr></thead><tbody>';
			foreach ( $results as $row ) {
				echo '<tr>';
				echo '<td><a href="' . esc_url( get_edit_post_link( $row['id'] ) ) . '">' . esc_html( $row['name'] ) . '</a></td>';
				echo '<td>' . esc_html( $row['sku'] ) . '</td>';
				echo '<td><strong>' . esc_html( $row['status'] ) . '</strong></td>';
				echo '<td>' . esc_html( $row['reason'] ) . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	private static function process_batch( int $batch_size ): array {
		$offset = (int) get_option( self::OPTION_OFFSET, 0 );
		$total  = (int) wp_count_posts( 'product' )->publish;
		if ( $offset >= $total ) {
			update_option( self::OPTION_OFFSET, $total );
			return array();
		}

		$query = new WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => $batch_size,
				'offset'         => $offset,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		$results = array();
		foreach ( $query->posts as $product_id ) {
			$product   = wc_get_product( $product_id );
			$result    = DUTT_SHD_Eligibility_Service::save_scan_result( (int) $product_id );
			$results[] = array(
				'id'     => (int) $product_id,
				'name'   => $product ? $product->get_name() : 'Unknown product',
				'sku'    => $product ? $product->get_sku() : '',
				'status' => $result['status'],
				'reason' => $result['reason'],
			);
		}

		update_option( self::OPTION_OFFSET, min( $total, $offset + count( $query->posts ) ) );
		return $results;
	}
}

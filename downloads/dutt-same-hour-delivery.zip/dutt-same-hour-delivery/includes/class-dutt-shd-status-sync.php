<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Status_Sync {
	const REST_NAMESPACE        = 'dutt-shd/v1';
	const REST_ROUTE            = '/status';
	const SECRET_OPTION         = 'dutt_shd_webhook_secret';
	const PROCESSED_EVENTS_META = '_dutt_processed_webhook_events';
	const EVENT_CLAIM_PREFIX    = 'dutt_shd_webhook_event_';
	const EVENT_CLAIM_SECONDS   = 120;
	const EVENT_DEDUP_SECONDS   = 604800;
	public static function init(): void {
		add_action( 'init', array( __CLASS__, 'ensure_webhook_secret' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function ensure_webhook_secret(): string {
		$secret = (string) get_option( self::SECRET_OPTION, '' );
		if ( '' !== $secret ) {
			return $secret;
		}

		$secret = wp_generate_password( 64, false, false );
		update_option( self::SECRET_OPTION, $secret, false );
		return $secret;
	}

	public static function callback_url(): string {
		if ( defined( 'DUTT_SHD_PUBLIC_BASE_URL' ) && '' !== trim( (string) DUTT_SHD_PUBLIC_BASE_URL ) ) {
			return esc_url_raw( trailingslashit( (string) DUTT_SHD_PUBLIC_BASE_URL ) . 'wp-json/' . self::REST_NAMESPACE . self::REST_ROUTE );
		}

		return esc_url_raw( rest_url( self::REST_NAMESPACE . self::REST_ROUTE ) );
	}

	public static function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE,
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_status_update' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public static function handle_status_update( WP_REST_Request $request ) {
		$raw_body = (string) $request->get_body();
		if ( '' === $raw_body ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array( 'reason' => 'empty_payload' ) );
			return new WP_Error( 'dutt_empty_payload', 'Empty status payload.', array( 'status' => 400 ) );
		}

		$authentication_error = DUTT_SHD_Webhook_Security::callback_authentication_error(
			self::ensure_webhook_secret(),
			(string) $request->get_header( 'x-dutt-timestamp' ),
			$raw_body,
			(string) $request->get_header( 'x-dutt-signature' )
		);
		if ( '' !== $authentication_error ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array( 'reason' => $authentication_error ) );
			return new WP_Error( 'dutt_invalid_signature', 'Invalid or expired Dutt status signature.', array( 'status' => 401 ) );
		}
		$payload = json_decode( $raw_body, true );
		if ( ! is_array( $payload ) || array_is_list( $payload ) ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array( 'reason' => 'invalid_json' ) );
			return new WP_Error( 'dutt_invalid_json', 'Invalid status payload JSON.', array( 'status' => 400 ) );
		}
		$event_name_error = DUTT_SHD_Webhook_Security::event_name_error(
			(string) $request->get_header( 'x-dutt-event' ),
			(string) ( $payload['event'] ?? '' )
		);
		if ( '' !== $event_name_error ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array( 'reason' => $event_name_error ) );
			return new WP_Error( 'dutt_invalid_event_name', 'Invalid Dutt callback event name.', array( 'status' => 400 ) );
		}

		$header_event_id  = (string) $request->get_header( 'x-dutt-event-id' );
		$payload_event_id = (string) ( $payload['event_id'] ?? '' );
		$event_id_error   = DUTT_SHD_Webhook_Security::event_id_error( $header_event_id, $payload_event_id );
		if ( '' !== $event_id_error ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array( 'reason' => $event_id_error ) );
			return new WP_Error( 'dutt_invalid_event_id', 'Invalid Dutt callback event ID.', array( 'status' => 400 ) );
		}
		$event_id            = trim( $payload_event_id );
		$payload['event_id'] = $event_id;
		$status              = self::normalize_delivery_status( (string) ( $payload['status'] ?? '' ) );
		if ( '' === $status ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array_merge( array( 'reason' => 'missing_status' ), self::compact_payload( $payload ) ) );
			return new WP_Error( 'dutt_missing_status', 'Missing Dutt status.', array( 'status' => 400 ) );
		}

		$order_context = self::resolve_order_context( $payload );
		if ( ! $order_context ) {
			self::log_callback_event( 'warning', 'status_callback_rejected', array_merge( array( 'reason' => 'order_not_found' ), self::compact_payload( $payload ) ) );
			return new WP_Error( 'dutt_order_not_found', 'WooCommerce order not found for Dutt status update.', array( 'status' => 404 ) );
		}

		$order            = $order_context['order'];
		$is_return        = ! empty( $order_context['is_return'] );
		$processed_events = $order->get_meta( self::PROCESSED_EVENTS_META );
		$processed_events = is_array( $processed_events ) ? $processed_events : array();
		if ( DUTT_SHD_Webhook_Security::event_was_processed( $processed_events, $event_id ) ) {
			self::log_callback_event(
				'info',
				'status_callback_duplicate',
				array_merge( array( 'order_id' => $order->get_id() ), self::compact_payload( $payload ) )
			);
			return rest_ensure_response(
				array(
					'success'  => true,
					'order_id' => $order->get_id(),
					'status'   => $is_return ? (string) $order->get_meta( 'dutt_return_status' ) : (string) $order->get_meta( 'dutt_status' ),
					'skipped'  => 'duplicate_event',
				)
			);
		}

		if ( ! self::claim_event_id( $event_id ) ) {
				self::log_callback_event(
					'warning',
					'status_callback_event_in_progress',
					array_merge( array( 'order_id' => $order->get_id() ), self::compact_payload( $payload ) )
				);
			return new WP_Error( 'dutt_event_in_progress', 'Dutt callback event is already being processed.', array( 'status' => 409 ) );
		}

		$old_status = (string) $order->get_meta( $is_return ? 'dutt_return_status' : 'dutt_status' );
		if ( ! DUTT_SHD_Webhook_Security::transition_is_allowed( $old_status, $status ) ) {
			self::remember_processed_event( $order, $processed_events, $event_id, $status );
			$order->save();
			self::finalize_event_id( $event_id );
			self::log_callback_event(
				'warning',
				'status_callback_terminal_regression_blocked',
				array_merge(
					array(
						'order_id'        => $order->get_id(),
						'current_status'  => $old_status,
						'incoming_status' => $status,
					),
					self::compact_payload( $payload )
				)
			);
			return rest_ensure_response(
				array(
					'success'  => true,
					'order_id' => $order->get_id(),
					'status'   => $old_status,
					'skipped'  => 'terminal_status_regression',
				)
			);
		}

		self::remember_processed_event( $order, $processed_events, $event_id, $status );
		if ( $is_return ) {
			$response = self::handle_return_status_update( $order, $payload, $status );
			self::finalize_event_id( $event_id );
			return $response;
		}

		$now             = current_time( 'mysql' );
		$compact_payload = self::compact_payload( $payload );
		$order->update_meta_data( 'dutt_status', $status );
		$order->update_meta_data( 'dutt_status_synced_at', $now );
		$order->update_meta_data( 'dutt_status_last_payload', $compact_payload );
		self::save_tracking_payload( $order, $payload );

		if ( $old_status === $status ) {
			$order->save();
			self::finalize_event_id( $event_id );
			self::log_callback_event(
				'info',
				'status_callback_unchanged',
				array_merge(
					array( 'order_id' => $order->get_id() ),
					$compact_payload
				)
			);
			return rest_ensure_response(
				array(
					'success'  => true,
					'order_id' => $order->get_id(),
					'status'   => $status,
					'skipped'  => 'unchanged',
				)
			);
		}

		self::append_status_history( $order, $payload, $status, $old_status, $now );

		$reference = (string) ( $payload['pickup_reference'] ?? $payload['merchant_order_reference'] ?? $order->get_meta( 'dutt_pickup_reference' ) );
		$note      = 'Dutt status updated: ' . self::status_label( $status );
		if ( '' !== $reference ) {
			$note .= ' (' . $reference . ')';
		}
		$order->add_order_note( $note );

		self::maybe_update_woocommerce_status( $order, $status );
		$order->save();
		self::finalize_event_id( $event_id );
		self::log_callback_event(
			'info',
			'status_callback_synced',
			array_merge(
				array(
					'order_id'   => $order->get_id(),
					'old_status' => $old_status,
					'new_status' => $status,
				),
				$compact_payload
			)
		);

		return rest_ensure_response(
			array(
				'success'  => true,
				'order_id' => $order->get_id(),
				'status'   => $status,
			)
		);
	}

	private static function handle_return_status_update( WC_Order $order, array $payload, string $status ) {

		$old_status      = (string) $order->get_meta( 'dutt_return_status' );
		$now             = current_time( 'mysql' );
		$compact_payload = self::compact_payload( $payload );

		$order->update_meta_data( 'dutt_return_status', $status );
		$order->update_meta_data( 'dutt_return_status_synced_at', $now );
		$order->update_meta_data( 'dutt_return_status_last_payload', $compact_payload );

		$delivery_id = sanitize_text_field( (string) ( $payload['delivery_id'] ?? $payload['dutt_order_id'] ?? '' ) );
		if ( '' !== $delivery_id && '' === (string) $order->get_meta( 'dutt_return_delivery_id' ) ) {
			$order->update_meta_data( 'dutt_return_delivery_id', $delivery_id );
		}

		$tracking_url = esc_url_raw( (string) ( $payload['tracking_url'] ?? $payload['trackingUrl'] ?? '' ) );
		if ( '' !== $tracking_url ) {
			$order->update_meta_data( 'dutt_return_tracking_url', $tracking_url );
		}

		if ( $old_status === $status ) {
			$order->save();
			self::log_callback_event(
				'info',
				'return_status_callback_unchanged',
				array_merge(
					array( 'order_id' => $order->get_id() ),
					$compact_payload
				)
			);
			return rest_ensure_response(
				array(
					'success'   => true,
					'order_id'  => $order->get_id(),
					'status'    => $status,
					'is_return' => true,
					'skipped'   => 'unchanged',
				)
			);
		}

		self::append_return_status_history( $order, $payload, $status, $old_status, $now );

		$reference = (string) ( $payload['pickup_reference'] ?? $payload['merchant_order_reference'] ?? $order->get_meta( 'dutt_return_pickup_reference' ) );
		$note      = 'Dutt return status updated: ' . self::status_label( $status );
		if ( '' !== $reference ) {
			$note .= ' (' . $reference . ')';
		}
		$order->add_order_note( $note );
		$order->save();

		self::log_callback_event(
			'info',
			'return_status_callback_synced',
			array_merge(
				array(
					'order_id'   => $order->get_id(),
					'old_status' => $old_status,
					'new_status' => $status,
				),
				$compact_payload
			)
		);

		return rest_ensure_response(
			array(
				'success'   => true,
				'order_id'  => $order->get_id(),
				'status'    => $status,
				'is_return' => true,
			)
		);
	}

	private static function remember_processed_event( WC_Order $order, array $events, string $event_id, string $status ): void {

			$order->update_meta_data(
				self::PROCESSED_EVENTS_META,
				DUTT_SHD_Webhook_Security::remember_event( $events, $event_id, $status, gmdate( 'c' ) )
			);
	}

	private static function claim_event_id( string $event_id ): bool {

		$key = self::event_claim_key( $event_id );
		if ( wp_using_ext_object_cache() ) {
				return wp_cache_add( $key, 'processing', 'dutt_shd_webhooks', self::EVENT_CLAIM_SECONDS );
		}

		$value_option   = '_transient_' . $key;
		$timeout_option = '_transient_timeout_' . $key;
		$now            = time();
		$current_value  = get_option( $value_option, false );
		$current_expiry = (int) get_option( $timeout_option, 0 );

		if ( false !== $current_value ) {
			if ( 0 < $current_expiry && $current_expiry < $now ) {
				delete_option( $value_option );
				delete_option( $timeout_option );
			} else {
				return false;
			}
		}

		if ( ! add_option( $value_option, 'processing', '', false ) ) {
			return false;
		}
		update_option( $timeout_option, $now + self::EVENT_CLAIM_SECONDS, false );
		return true;
	}

	private static function finalize_event_id( string $event_id ): void {

		$key = self::event_claim_key( $event_id );
		if ( wp_using_ext_object_cache() ) {
				wp_cache_set( $key, 'processed', 'dutt_shd_webhooks', self::EVENT_DEDUP_SECONDS );
			return;
		}

		update_option( '_transient_' . $key, 'processed', false );
		update_option( '_transient_timeout_' . $key, time() + self::EVENT_DEDUP_SECONDS, false );
	}

	private static function event_claim_key( string $event_id ): string {

		return self::EVENT_CLAIM_PREFIX . hash( 'sha256', $event_id );
	}

	private static function resolve_order( array $payload ): ?WC_Order {

		$woo_order_id = absint( $payload['woo_order_id'] ?? $payload['woocommerce_order_id'] ?? 0 );
		$delivery_id  = sanitize_text_field( (string) ( $payload['delivery_id'] ?? $payload['dutt_order_id'] ?? '' ) );
		if ( $woo_order_id ) {
			$order = wc_get_order( $woo_order_id );
			if ( $order instanceof WC_Order ) {
				$stored_delivery_id = trim( (string) $order->get_meta( 'dutt_delivery_id' ) );
				if ( '' === $delivery_id || '' === $stored_delivery_id || ! hash_equals( $stored_delivery_id, $delivery_id ) ) {
					return null;
				}
				return $order;
			}
		}

		if ( '' === $delivery_id ) {
			return null;
		}

		return self::resolve_order_by_meta( 'dutt_delivery_id', $delivery_id );
	}

	private static function resolve_order_context( array $payload ): ?array {
		if ( self::payload_is_return_delivery( $payload ) ) {
			$return_order = self::resolve_return_order( $payload );
			if ( $return_order ) {
				return array(
					'order'     => $return_order,
					'is_return' => true,
				);
			}
		}

		$order = self::resolve_order( $payload );
		if ( $order ) {
			return array(
				'order'     => $order,
				'is_return' => false,
			);
		}

		$return_order = self::resolve_return_order( $payload );
		if ( $return_order ) {
			return array(
				'order'     => $return_order,
				'is_return' => true,
			);
		}

		return null;
	}

	private static function payload_is_return_delivery( array $payload ): bool {
		$order_type = sanitize_key( (string) ( $payload['order_type'] ?? $payload['orderType'] ?? '' ) );
		if ( 'merchant_return' === $order_type ) {
			return true;
		}

		$external_order_id = sanitize_text_field( (string) ( $payload['external_order_id'] ?? $payload['externalOrderId'] ?? '' ) );
		if ( str_starts_with( $external_order_id, 'return_wc_' ) ) {
			return true;
		}

			$reference = sanitize_text_field( (string) ( $payload['pickup_reference'] ?? $payload['merchant_order_reference'] ?? '' ) );
			return str_starts_with( strtoupper( $reference ), 'RETURN-' );
	}

	private static function resolve_return_order( array $payload ): ?WC_Order {
		$delivery_id = sanitize_text_field( (string) ( $payload['delivery_id'] ?? $payload['dutt_order_id'] ?? '' ) );
		$order       = self::resolve_order_by_meta( 'dutt_return_delivery_id', $delivery_id );
		if ( $order ) {
			return $order;
		}

		$external_order_id = sanitize_text_field( (string) ( $payload['external_order_id'] ?? $payload['externalOrderId'] ?? '' ) );
		$order             = self::resolve_order_by_meta( 'dutt_return_external_order_id', $external_order_id );
		if ( $order ) {
			return $order;
		}

		$linked               = isset( $payload['linked_original_order'] ) && is_array( $payload['linked_original_order'] )
		? $payload['linked_original_order']
		: array();
		$linked_dutt_order_id = sanitize_text_field( (string) ( $linked['dutt_order_id'] ?? $linked['duttOrderId'] ?? '' ) );
		return self::resolve_order_by_meta( 'dutt_delivery_id', $linked_dutt_order_id );
	}

	private static function resolve_order_by_meta( string $meta_key, string $meta_value ): ?WC_Order {
		if ( '' === $meta_value ) {
			return null;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => 1,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Exact delivery-ID lookup limited to one result.
				'meta_key'   => $meta_key,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Exact delivery-ID lookup limited to one result.
				'meta_value' => $meta_value,
				'return'     => 'objects',
			)
		);

		return ! empty( $orders ) && $orders[0] instanceof WC_Order ? $orders[0] : null;
	}

	private static function compact_payload( array $payload ): array {
		$compact = array(
			'delivery_id'              => sanitize_text_field( (string) ( $payload['delivery_id'] ?? '' ) ),
			'dutt_order_id'            => sanitize_text_field( (string) ( $payload['dutt_order_id'] ?? '' ) ),
			'city_id'                  => sanitize_text_field( (string) ( $payload['city_id'] ?? '' ) ),
			'status'                   => sanitize_key( (string) ( $payload['status'] ?? '' ) ),
			'previous_status'          => sanitize_key( (string) ( $payload['previous_status'] ?? '' ) ),
			'pickup_reference'         => sanitize_text_field( (string) ( $payload['pickup_reference'] ?? '' ) ),
			'merchant_order_reference' => sanitize_text_field( (string) ( $payload['merchant_order_reference'] ?? '' ) ),
			'event_time'               => sanitize_text_field( (string) ( $payload['event_time'] ?? '' ) ),
			'event_id'                 => sanitize_text_field( (string) ( $payload['event_id'] ?? '' ) ),
			'driver_id'                => sanitize_text_field( (string) ( $payload['driver_id'] ?? $payload['driverId'] ?? '' ) ),
			'driver_name'              => sanitize_text_field( (string) ( $payload['driver_name'] ?? $payload['driverName'] ?? '' ) ),
			'driver_phone'             => sanitize_text_field( (string) ( $payload['driver_phone'] ?? $payload['driverPhone'] ?? '' ) ),
			'eta_pickup'               => sanitize_text_field( (string) ( $payload['eta_pickup'] ?? $payload['etaPickup'] ?? $payload['eta_pickup_at'] ?? '' ) ),
			'eta_delivery'             => sanitize_text_field( (string) ( $payload['eta_delivery'] ?? $payload['etaDelivery'] ?? $payload['eta_delivery_at'] ?? $payload['estimated_time'] ?? '' ) ),
			'failed_reason'            => sanitize_text_field( (string) ( $payload['failed_reason'] ?? $payload['failure_reason'] ?? $payload['failureReason'] ?? '' ) ),
			'failed_stage'             => sanitize_text_field( (string) ( $payload['failed_stage'] ?? $payload['failure_stage'] ?? $payload['failureStage'] ?? '' ) ),
		);

		if ( array_key_exists( 'return_required', $payload ) || array_key_exists( 'returnRequired', $payload ) ) {
			$compact['return_required'] = ! empty( $payload['return_required'] ) || ! empty( $payload['returnRequired'] );
		}
		if ( array_key_exists( 'return_completed', $payload ) || array_key_exists( 'returnCompleted', $payload ) ) {
			$compact['return_completed'] = ! empty( $payload['return_completed'] ) || ! empty( $payload['returnCompleted'] );
		}

		return $compact;
	}

	public static function save_tracking_payload( WC_Order $order, array $payload ): void {
		$compact  = self::compact_payload( $payload );
		$meta_map = array(
			'driver_id'        => 'dutt_driver_id',
			'driver_name'      => 'dutt_driver_name',
			'driver_phone'     => 'dutt_driver_phone',
			'eta_pickup'       => 'dutt_eta_pickup',
			'eta_delivery'     => 'dutt_eta_delivery',
			'failed_reason'    => 'dutt_failure_reason',
			'failed_stage'     => 'dutt_failure_stage',
			'return_required'  => 'dutt_return_required',
			'return_completed' => 'dutt_return_completed',
		);

		foreach ( $meta_map as $payload_key => $meta_key ) {
			if (
				array_key_exists( $payload_key, $compact ) &&
				in_array( $payload_key, array( 'return_required', 'return_completed' ), true )
			) {
				$order->update_meta_data( $meta_key, ! empty( $compact[ $payload_key ] ) ? '1' : '0' );
			} elseif ( array_key_exists( $payload_key, $compact ) && '' !== (string) $compact[ $payload_key ] ) {
				$order->update_meta_data( $meta_key, $compact[ $payload_key ] );
			}
		}

		if ( ! empty( $payload['history'] ) && is_array( $payload['history'] ) ) {
			$history = array();
			foreach ( $payload['history'] as $entry ) {
				if ( is_array( $entry ) ) {
					$history[] = self::compact_history_entry( $entry );
				}
			}
			$history = array_values( array_filter( $history ) );
			if ( ! empty( $history ) ) {
				$order->update_meta_data( 'dutt_status_history', array_slice( $history, -30 ) );
			}
		}
	}

	private static function compact_history_entry( array $entry ): array {
		return array(
			'status'          => sanitize_key( (string) ( $entry['status'] ?? $entry['state'] ?? $entry['sourceStatus'] ?? '' ) ),
			'previous_status' => sanitize_key( (string) ( $entry['previous_status'] ?? $entry['previousStatus'] ?? $entry['previousState'] ?? '' ) ),
			'event'           => sanitize_text_field( (string) ( $entry['event'] ?? $entry['type'] ?? '' ) ),
			'synced_at'       => sanitize_text_field( (string) ( $entry['synced_at'] ?? '' ) ),
			'event_time'      => sanitize_text_field( (string) ( $entry['event_time'] ?? $entry['at'] ?? $entry['timestamp'] ?? '' ) ),
			'source'          => sanitize_text_field( (string) ( $entry['source'] ?? '' ) ),
			'failed_reason'   => sanitize_text_field( (string) ( $entry['failed_reason'] ?? $entry['failure_reason'] ?? $entry['reason'] ?? '' ) ),
		);
	}

	private static function append_status_history( WC_Order $order, array $payload, string $status, string $old_status, string $now ): void {
		$history = $order->get_meta( 'dutt_status_history' );
		if ( ! is_array( $history ) ) {
			$history = array();
		}

		$history[] = array(
			'status'          => $status,
			'previous_status' => $old_status,
			'event'           => sanitize_text_field( (string) ( $payload['event'] ?? $payload['type'] ?? 'delivery.status_updated' ) ),
			'event_id'        => sanitize_text_field( (string) ( $payload['event_id'] ?? '' ) ),
			'synced_at'       => $now,
			'event_time'      => sanitize_text_field( (string) ( $payload['event_time'] ?? '' ) ),
			'driver_name'     => sanitize_text_field( (string) ( $payload['driver_name'] ?? $payload['driverName'] ?? '' ) ),
			'eta_pickup'      => sanitize_text_field( (string) ( $payload['eta_pickup'] ?? $payload['etaPickup'] ?? '' ) ),
			'eta_delivery'    => sanitize_text_field( (string) ( $payload['eta_delivery'] ?? $payload['etaDelivery'] ?? $payload['estimated_time'] ?? '' ) ),
			'failed_reason'   => sanitize_text_field( (string) ( $payload['failed_reason'] ?? $payload['failure_reason'] ?? $payload['failureReason'] ?? '' ) ),
		);

		$order->update_meta_data( 'dutt_status_history', array_slice( $history, -30 ) );
	}

	private static function append_return_status_history( WC_Order $order, array $payload, string $status, string $old_status, string $now ): void {
		$history = $order->get_meta( 'dutt_return_status_history' );
		if ( ! is_array( $history ) ) {
			$history = array();
		}

		$history[] = array(
			'status'          => $status,
			'previous_status' => $old_status,
			'event'           => sanitize_text_field( (string) ( $payload['event'] ?? $payload['type'] ?? 'delivery.status_updated' ) ),
			'event_id'        => sanitize_text_field( (string) ( $payload['event_id'] ?? '' ) ),
			'synced_at'       => $now,
			'event_time'      => sanitize_text_field( (string) ( $payload['event_time'] ?? '' ) ),
			'driver_name'     => sanitize_text_field( (string) ( $payload['driver_name'] ?? $payload['driverName'] ?? '' ) ),
			'eta_pickup'      => sanitize_text_field( (string) ( $payload['eta_pickup'] ?? $payload['etaPickup'] ?? '' ) ),
			'eta_delivery'    => sanitize_text_field( (string) ( $payload['eta_delivery'] ?? $payload['etaDelivery'] ?? $payload['estimated_time'] ?? '' ) ),
			'failed_reason'   => sanitize_text_field( (string) ( $payload['failed_reason'] ?? $payload['failure_reason'] ?? $payload['failureReason'] ?? '' ) ),
		);

		$order->update_meta_data( 'dutt_return_status_history', array_slice( $history, -30 ) );
	}

	private static function maybe_update_woocommerce_status( WC_Order $order, string $dutt_status ): void {
		$current           = $order->get_status();
		$normalized_status = self::normalize_delivery_status( $dutt_status );

		if ( in_array( $normalized_status, array( 'delivered', 'completed', 'complete', 'confirmed_by_user' ), true ) ) {
			if ( 'completed' !== $current ) {
				$order->update_status( 'completed', 'Dutt delivery completed.' );
			}
			return;
		}
	}

	public static function status_label( string $status ): string {
		$status = self::normalize_delivery_status( $status );
		if ( '' === $status ) {
			return '-';
		}

		$labels = array(
			'awaiting_ready_for_pickup' => 'Awaiting ready for pickup',
			'pending_dispatch'          => 'Pending dispatch',
			'pending'                   => 'Pending',
			'assigned'                  => 'Assigned',
			'accepted'                  => 'Accepted',
			'picked_up'                 => 'Picked up',
			'delivered'                 => 'Delivered',
			'completed'                 => 'Delivered',
			'complete'                  => 'Delivered',
			'confirmed_by_user'         => 'Delivered',
			'cancelled'                 => 'Cancelled',
			'cancelled_by_admin'        => 'Cancelled by admin',
			'cancelled_by_merchant'     => 'Cancelled by merchant',
			'cancel_failed'             => 'Cancel failed',
			'create_failed'             => 'Create failed',
			'retrying_dispatch'         => 'Retrying dispatch',
		);

		return $labels[ $status ] ?? ucwords( str_replace( '_', ' ', $status ) );
	}

	private static function normalize_delivery_status( string $status ): string {
		$status = sanitize_key( str_replace( '-', '_', strtolower( trim( $status ) ) ) );

		$aliases = array(
			'canceled'             => 'cancelled',
			'canceled_by_admin'    => 'cancelled_by_admin',
			'canceled_by_merchant' => 'cancelled_by_merchant',
		);

		return $aliases[ $status ] ?? $status;
	}

	private static function is_cancelled_status( string $status ): bool {
		return 'cancelled' === $status || str_starts_with( $status, 'cancelled_' );
	}

	private static function log_callback_event( string $level, string $event, array $context ): void {
		if ( ! class_exists( 'DUTT_SHD_Logger' ) ) {
			return;
		}

		DUTT_SHD_Logger::log( $level, $event, $context );
	}
}

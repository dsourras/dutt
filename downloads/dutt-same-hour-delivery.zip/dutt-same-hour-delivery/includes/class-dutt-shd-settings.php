<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_Settings {
	const SECTION                       = 'dutt_same_hour_delivery';
	const BUSINESS_BILLING_BLOCK_OPTION = 'dutt_shd_business_billing_block';

	public static function init(): void {
		add_filter( 'woocommerce_get_sections_shipping', array( __CLASS__, 'add_shipping_section' ) );
		add_filter( 'woocommerce_get_settings_shipping', array( __CLASS__, 'add_shipping_settings' ), 10, 2 );
		add_action( 'woocommerce_admin_field_dutt_connection_test', array( __CLASS__, 'render_connection_test_field' ) );
		add_action( 'admin_post_dutt_shd_connection_test', array( __CLASS__, 'handle_connection_test' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_admin_notices' ) );
		add_action( 'woocommerce_update_options_shipping_' . self::SECTION, array( __CLASS__, 'save_shipping_settings' ), 5 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_dutt_shd_merchant_key', array( __CLASS__, 'sanitize_merchant_key_option' ), 10, 3 );
	}

	public static function defaults(): array {
		return array(
			'enabled'                          => 'yes',
			'api_mode'                         => 'live',
			'quote_api_url'                    => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttWooCommerceQuote',
			'connection_test_api_url'          => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttWooCommerceConnectionTest',
			'create_delivery_api_url'          => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttWooCommerceCreateDelivery',
			'cancel_delivery_api_url'          => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttWooCommerceCancelDelivery',
			'return_order_api_url'             => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantCreateOrder',
			'return_mark_ready_api_url'        => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantMarkReady',
			'status_api_url'                   => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantGetStatus',
			'merchant_overview_api_url'        => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantLedgerOverview',
			'merchant_settlement_sync_api_url' => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantSettlementSyncOperation',
			'refund_notice_api_url'            => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantRefundNotice',
			'merchant_support_api_url'         => 'https://us-central1-sendygo-cd034.cloudfunctions.net/duttMerchantSupport',
			'merchant_key'                     => '',
			'api_key'                          => '',
			'api_timeout_seconds'              => '8',
			'api_default_estimated_time'       => '30-45 minutes',
			'store_name'                       => get_bloginfo( 'name' ),
			'store_city'                       => '',
			'store_address'                    => '',
			'legal_name'                       => get_bloginfo( 'name' ),
			'vat_number'                       => '',
			'tax_office'                       => '',
			'billing_address'                  => '',
			'billing_city'                     => '',
			'billing_postcode'                 => '',
			'billing_email'                    => get_option( 'admin_email' ),
			'business_activity'                => '',
			'merchant_agreement_accepted'      => 'no',
			'merchant_agreement_version'       => '',
			'merchant_agreement_accepted_at'   => '',
			'privacy_dpa_accepted'             => 'no',
			'privacy_dpa_version'              => '',
			'privacy_dpa_accepted_at'          => '',
			'service_radius_km'                => '6',
			'max_weight_kg'                    => '8',
			'max_length_cm'                    => '50',
			'max_width_cm'                     => '40',
			'max_height_cm'                    => '40',
			'vat_note'                         => 'The DUTT quote is returned by the DUTT API. WooCommerce tax display follows this store configuration.',
			'customer_charge_policy'           => 'full_quote',
			'free_delivery_threshold'          => '50',
			'fixed_customer_charge'            => '3',
			'preparation_minutes'              => '10',
			'service_start'                    => '09:00',
			'service_end'                      => '21:00',
			'cash_on_delivery'                 => 'no',
			'diagnostic_logging'               => 'no',
			'mock_rider_availability'          => 'available',
			'mock_estimated_time'              => '30-45 minutes',
		);
	}

	public static function get( string $key ) {
		$defaults = self::defaults();
		if ( 'api_mode' === $key && ! self::mock_mode_enabled() ) {
			return 'live';
		}
		return get_option( 'dutt_shd_' . $key, $defaults[ $key ] ?? '' );
	}

	public static function mock_mode_enabled(): bool {
		return defined( 'DUTT_SHD_ENABLE_MOCK_MODE' ) && true === DUTT_SHD_ENABLE_MOCK_MODE;
	}

	public static function developer_settings_enabled(): bool {
		return defined( 'DUTT_SHD_ENABLE_DEVELOPER_SETTINGS' ) && true === DUTT_SHD_ENABLE_DEVELOPER_SETTINGS;
	}

	public static function all(): array {
		$settings = array();
		foreach ( self::defaults() as $key => $value ) {
			$settings[ $key ] = self::get( $key );
		}
		return $settings;
	}

	public static function settings_for_active_location( array $settings ): array {
		$normalized = array_merge(
			array(
				'eligible_product_ids'      => array(),
				'eligible_category_ids'     => array(),
				'not_eligible_product_ids'  => array(),
				'not_eligible_category_ids' => array(),
			),
			$settings
		);

		$filtered = apply_filters( 'dutt_shd_active_location_settings', $normalized, $settings );
		if ( ! is_array( $filtered ) ) {
			return $normalized;
		}

		return array_merge( $normalized, $filtered );
	}

	public static function has_merchant_key( ?array $settings = null ): bool {
		$settings = $settings ?: self::all();
		return '' !== trim( (string) ( $settings['merchant_key'] ?? '' ) );
	}

	public static function sanitize_merchant_key_option( $value, array $option, $raw_value ) {
		$submitted = trim( (string) $raw_value );
		if ( '' !== $submitted ) {
			return $submitted;
		}

		$existing = trim( (string) get_option( 'dutt_shd_merchant_key', '' ) );
		return '' !== $existing ? $existing : '';
	}

	public static function save_shipping_settings(): void {

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if (
			! isset( $_POST['_wpnonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'woocommerce-settings' )
		) {
			return;
		}

		$page    = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin route selection.
		$tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin route selection.
		$section = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin route selection.
		if ( 'wc-settings' !== $page || 'shipping' !== $tab || self::SECTION !== $section ) {
			return;
		}

		$has_dutt_posted_field = false;
		foreach ( array_keys( self::defaults() ) as $key ) {
			if ( isset( $_POST[ 'dutt_shd_' . $key ] ) ) {
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Presence check only; WC_Admin_Settings sanitizes values.
				$has_dutt_posted_field = true;
				break;
			}
		}

		if ( ! $has_dutt_posted_field ) {
			return;
		}

		WC_Admin_Settings::save_fields( self::add_shipping_settings( array(), self::SECTION ) );
		self::sync_legal_acceptance_metadata();
	}

	public static function is_enabled(): bool {
		$settings = self::all();
		return 'yes' === (string) ( $settings['enabled'] ?? '' )
			&& self::has_merchant_key( $settings )
			&& empty( self::missing_required_billing_fields( $settings ) )
			&& ! empty( self::merchant_integration_policy_status( $settings )['ok'] );
	}

	public static function merchant_agreement_url(): string {
		return plugins_url( 'legal/merchant-agreement-v1.0-2026-08-02.html', DUTT_SHD_PLUGIN_FILE );
	}

	public static function privacy_dpa_url(): string {
		return plugins_url( 'legal/privacy-dpa-v1.0-2026-08-02.html', DUTT_SHD_PLUGIN_FILE );
	}

	public static function store_base_country(): string {
		if ( function_exists( 'wc_get_base_location' ) ) {
			$location = wc_get_base_location();
			if ( is_array( $location ) && ! empty( $location['country'] ) ) {
				return (string) $location['country'];
			}
		}

		$default_country = (string) get_option( 'woocommerce_default_country', '' );
		return explode( ':', $default_country )[0];
	}

	public static function merchant_integration_policy_status(
		?array $settings = null,
		?string $delivery_country = null,
		?string $currency = null
	): array {
		$settings         = $settings ?: self::all();
		$store_country    = self::store_base_country();
		$delivery_country = null === $delivery_country || '' === trim( $delivery_country )
			? $store_country
			: $delivery_country;
		$currency         = null === $currency || '' === trim( $currency )
			? ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '' )
			: $currency;

		return DUTT_SHD_Merchant_Policy::validate(
			$settings,
			(string) $currency,
			$store_country,
			(string) $delivery_country
		);
	}

	public static function merchant_integration_policy_payload(
		?array $settings = null,
		string $delivery_country = DUTT_SHD_Merchant_Policy::REQUIRED_COUNTRY
	): array {
		return DUTT_SHD_Merchant_Policy::payload( $settings ?: self::all(), $delivery_country );
	}

	private static function sync_legal_acceptance_metadata(): void {
		self::sync_single_legal_acceptance(
			'merchant_agreement',
			DUTT_SHD_Merchant_Policy::MERCHANT_AGREEMENT_VERSION
		);
		self::sync_single_legal_acceptance(
			'privacy_dpa',
			DUTT_SHD_Merchant_Policy::PRIVACY_DPA_VERSION
		);
	}

	private static function sync_single_legal_acceptance( string $prefix, string $current_version ): void {
		$accepted_option = 'dutt_shd_' . $prefix . '_accepted';
		$version_option  = 'dutt_shd_' . $prefix . '_version';
		$time_option     = 'dutt_shd_' . $prefix . '_accepted_at';
		$accepted        = 'yes' === (string) get_option( $accepted_option, 'no' );

		if ( ! $accepted ) {
			delete_option( $version_option );
			delete_option( $time_option );
			return;
		}

		if ( (string) get_option( $version_option, '' ) !== $current_version ) {
			update_option( $version_option, $current_version, false );
			update_option( $time_option, gmdate( DATE_ATOM ), false );
		}
	}

	private static function invalidate_stale_legal_acceptance(): void {
		$requirements = array(
			'merchant_agreement' => DUTT_SHD_Merchant_Policy::MERCHANT_AGREEMENT_VERSION,
			'privacy_dpa'        => DUTT_SHD_Merchant_Policy::PRIVACY_DPA_VERSION,
		);

		foreach ( $requirements as $prefix => $version ) {
			$accepted_option = 'dutt_shd_' . $prefix . '_accepted';
			$version_option  = 'dutt_shd_' . $prefix . '_version';
			$time_option     = 'dutt_shd_' . $prefix . '_accepted_at';
			if (
				'yes' === (string) get_option( $accepted_option, 'no' ) &&
				(
					(string) get_option( $version_option, '' ) !== $version ||
					! DUTT_SHD_Merchant_Policy::acceptance_timestamp_valid( (string) get_option( $time_option, '' ) )
				)
			) {
				update_option( $accepted_option, 'no', false );
				delete_option( $version_option );
				delete_option( $time_option );
			}
		}
	}

	public static function remember_business_billing_block( array $billing ): void {
		$normalized = DUTT_SHD_Business_Billing_Notice::normalize( $billing );
		$current    = get_option( self::BUSINESS_BILLING_BLOCK_OPTION, array() );
		if ( is_array( $current ) && $current === $normalized ) {
			return;
		}
		update_option( self::BUSINESS_BILLING_BLOCK_OPTION, $normalized, false );
	}

	public static function clear_business_billing_block(): void {
		if ( false !== get_option( self::BUSINESS_BILLING_BLOCK_OPTION, false ) ) {
			delete_option( self::BUSINESS_BILLING_BLOCK_OPTION );
		}
	}

	public static function business_billing_block(): array {
		$value = get_option( self::BUSINESS_BILLING_BLOCK_OPTION, array() );
		return is_array( $value ) ? $value : array();
	}

	public static function render_admin_notices(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$billing_block = self::business_billing_block();
		if ( ! empty( $billing_block ) ) {
			$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
			$copy   = DUTT_SHD_Business_Billing_Notice::copy( (string) $locale );
			echo '<div class="notice notice-error dutt-business-billing-notice">';
			echo '<p><strong>' . esc_html( $copy['title'] ) . '</strong></p>';
			echo '<p>' . esc_html( $copy['message'] ) . '</p>';
			echo '<p>';
			if ( '' !== (string) ( $billing_block['invoice_number'] ?? '' ) ) {
				echo esc_html( $copy['invoice'] . ': ' . $billing_block['invoice_number'] ) . '<br>';
			}
			if ( (float) ( $billing_block['outstanding_amount'] ?? 0 ) > 0 ) {
				echo esc_html( $copy['amount'] . ': ' . number_format_i18n( (float) $billing_block['outstanding_amount'], 2 ) . ' EUR' );
			}
			echo '</p>';
			echo '<p><strong>' . esc_html( $copy['reactivation'] ) . '</strong></p>';
			if ( '' !== (string) ( $billing_block['payment_url'] ?? '' ) ) {
				echo '<p><a class="button button-primary" target="_blank" rel="noopener noreferrer" href="'
					. esc_url( $billing_block['payment_url'] ) . '">' . esc_html( $copy['pay'] ) . '</a></p>';
			}
			echo '</div>';
		}

		$page    = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin route selection.
		$tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin route selection.
		$section = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin route selection.
		if ( 'wc-settings' !== $page || 'shipping' !== $tab || self::SECTION !== $section ) {
			return;
		}

		$settings = self::all();
		if ( 'yes' !== (string) ( $settings['enabled'] ?? '' ) || self::has_merchant_key( $settings ) ) {
			return;
		}

		echo '<div class="notice notice-warning"><p>'
			. esc_html__( 'Merchant key is required before Dutt delivery can be used.', 'dutt-same-hour-delivery' )
			. '</p></div>';
	}

	public static function merchant_billing_profile( ?array $settings = null ): array {
		$settings   = $settings ?: self::all();
		$vat_number = preg_replace( '/\D+/', '', (string) ( $settings['vat_number'] ?? '' ) );

		return array(
			'legal_name'        => trim( (string) ( $settings['legal_name'] ?? '' ) ),
			'vat_number'        => $vat_number,
			'tax_office'        => trim( (string) ( $settings['tax_office'] ?? '' ) ),
			'billing_address'   => trim( (string) ( $settings['billing_address'] ?? '' ) ),
			'billing_city'      => trim( (string) ( $settings['billing_city'] ?? '' ) ),
			'billing_postcode'  => trim( (string) ( $settings['billing_postcode'] ?? '' ) ),
			'billing_email'     => sanitize_email( (string) ( $settings['billing_email'] ?? '' ) ),
			'business_activity' => trim( (string) ( $settings['business_activity'] ?? '' ) ),
		);
	}

	public static function missing_required_billing_fields( ?array $settings = null ): array {
		$profile = self::merchant_billing_profile( $settings );
		$missing = array();

		$required = array(
			'legal_name'       => 'Legal business name',
			'vat_number'       => 'VAT / AFM',
			'tax_office'       => 'Tax office / DOY',
			'billing_address'  => 'Billing address',
			'billing_city'     => 'Billing city',
			'billing_postcode' => 'Billing postcode',
			'billing_email'    => 'Billing email',
		);

		foreach ( $required as $key => $label ) {
			if ( '' === (string) ( $profile[ $key ] ?? '' ) ) {
				$missing[] = $label;
			}
		}

		if ( '' !== $profile['vat_number'] && ! preg_match( '/^\d{9}$/', $profile['vat_number'] ) ) {
			$missing[] = 'VAT / AFM must be 9 digits';
		}

		if ( '' !== $profile['billing_email'] && ! is_email( $profile['billing_email'] ) ) {
			$missing[] = 'Billing email must be valid';
		}

		return array_values( array_unique( $missing ) );
	}

	public static function add_shipping_section( array $sections ): array {
		$sections[ self::SECTION ] = 'DUTT Same Hour Delivery';
		return $sections;
	}

	public static function add_shipping_settings( array $settings, string $current_section ): array {
		if ( self::SECTION !== $current_section ) {
			return $settings;
		}
		self::invalidate_stale_legal_acceptance();

		$fields = array(
			array(
				'title' => 'DUTT Same Hour Delivery',
				'type'  => 'title',
				'desc'  => 'Portable WooCommerce settings for DUTT same-hour motorcycle delivery.',
				'id'    => 'dutt_shd_settings_title',
			),
			array(
				'title'   => 'Enable / Disable DUTT',
				'id'      => 'dutt_shd_enabled',
				'type'    => 'checkbox',
				'default' => self::defaults()['enabled'],
				'desc'    => 'Enable DUTT as a checkout shipping option.',
			),
			array(
				'title'   => 'DUTT quote mode',
				'id'      => 'dutt_shd_api_mode',
				'type'    => 'select',
				'default' => self::defaults()['api_mode'],
				'options' => array(
					'live' => 'Live DUTT API',
					'mock' => 'Demo/mock mode',
				),
				'desc'    => 'Use Live DUTT API for production stores. Mock mode is only for local demos.',
			),
			array(
				'title'   => 'DUTT Quote API URL',
				'id'      => 'dutt_shd_quote_api_url',
				'type'    => 'text',
				'default' => self::defaults()['quote_api_url'],
				'desc'    => 'Endpoint that returns distance, price and estimated time.',
			),
			array(
				'title'   => 'DUTT Create Delivery API URL',
				'id'      => 'dutt_shd_create_delivery_api_url',
				'type'    => 'text',
				'default' => self::defaults()['create_delivery_api_url'],
				'desc'    => 'Endpoint called when the merchant marks a WooCommerce order Ready for Dutt pickup.',
			),
			array(
				'title'   => 'DUTT Cancel Delivery API URL',
				'id'      => 'dutt_shd_cancel_delivery_api_url',
				'type'    => 'text',
				'default' => self::defaults()['cancel_delivery_api_url'],
				'desc'    => 'Endpoint called when the merchant cancels a created DUTT delivery from the WooCommerce order screen.',
			),
			array(
				'title'   => 'DUTT Return Order API URL',
				'id'      => 'dutt_shd_return_order_api_url',
				'type'    => 'text',
				'default' => self::defaults()['return_order_api_url'],
				'desc'    => 'Generic merchant API endpoint used to create a return pickup request.',
			),
			array(
				'title'   => 'DUTT Return Dispatch API URL',
				'id'      => 'dutt_shd_return_mark_ready_api_url',
				'type'    => 'text',
				'default' => self::defaults()['return_mark_ready_api_url'],
				'desc'    => 'Generic merchant API endpoint used to dispatch a confirmed return pickup.',
			),
			array(
				'title'   => 'DUTT Status API URL',
				'id'      => 'dutt_shd_status_api_url',
				'type'    => 'text',
				'default' => self::defaults()['status_api_url'],
				'desc'    => 'Endpoint used to refresh merchant-facing delivery tracking for an order.',
			),
			array(
				'title'   => 'DUTT Merchant Overview API URL',
				'id'      => 'dutt_shd_merchant_overview_api_url',
				'type'    => 'text',
				'default' => self::defaults()['merchant_overview_api_url'],
				'desc'    => 'Endpoint used by WooCommerce > Merchant Overview to show the common Dutt merchant ledger.',
			),
			array(
				'title'   => 'DUTT Refund Notice API URL',
				'id'      => 'dutt_shd_refund_notice_api_url',
				'type'    => 'text',
				'default' => self::defaults()['refund_notice_api_url'],
				'desc'    => 'Endpoint notified when a WooCommerce refund is created for a Dutt delivery order.',
			),
			array(
				'title'   => 'DUTT Merchant Support API URL',
				'id'      => 'dutt_shd_merchant_support_api_url',
				'type'    => 'text',
				'default' => self::defaults()['merchant_support_api_url'],
				'desc'    => 'Common merchant support endpoint.',
			),
			array(
				'title'   => 'DUTT Connection Test API URL',
				'id'      => 'dutt_shd_connection_test_api_url',
				'type'    => 'text',
				'default' => self::defaults()['connection_test_api_url'],
				'desc'    => 'Endpoint used by this settings page to validate the merchant key.',
			),
			array(
				'title'   => 'DUTT Merchant Key',
				'id'      => 'dutt_shd_merchant_key',
				'type'    => 'password',
				'default' => self::defaults()['merchant_key'],
				'desc'    => 'Paste the merchant key generated from DUTT Admin. Keep this private. If a key is already saved, leaving this field blank keeps the existing key.',
			),
			array(
				'title'   => 'Merchant Agreement',
				'id'      => 'dutt_shd_merchant_agreement_accepted',
				'type'    => 'checkbox',
				'default' => self::defaults()['merchant_agreement_accepted'],
				'desc'    => sprintf(
					'I have read and accept the <a href="%s" target="_blank" rel="noopener noreferrer">DUTT Merchant Agreement</a> (%s).',
					esc_url( self::merchant_agreement_url() ),
					esc_html( DUTT_SHD_Merchant_Policy::MERCHANT_AGREEMENT_VERSION )
				),
			),
			array(
				'title'   => 'Privacy and DPA',
				'id'      => 'dutt_shd_privacy_dpa_accepted',
				'type'    => 'checkbox',
				'default' => self::defaults()['privacy_dpa_accepted'],
				'desc'    => sprintf(
					'I have read and accept the <a href="%1$s" target="_blank" rel="noopener noreferrer">DUTT Privacy and Data Processing Addendum</a> (%2$s) and acknowledge the <a href="%3$s" target="_blank" rel="noopener noreferrer">Privacy Notice</a>.',
					esc_url( self::privacy_dpa_url() ),
					esc_html( DUTT_SHD_Merchant_Policy::PRIVACY_DPA_VERSION ),
					esc_url( 'https://dutt.gr/privacy.html' )
				),
			),
			array(
				'title' => 'Connection test',
				'id'    => 'dutt_shd_connection_test',
				'type'  => 'dutt_connection_test',
			),
			array(
				'title'             => 'API timeout seconds',
				'id'                => 'dutt_shd_api_timeout_seconds',
				'type'              => 'number',
				'default'           => self::defaults()['api_timeout_seconds'],
				'custom_attributes' => array(
					'min' => '3',
					'max' => '30',
				),
			),
			array(
				'title'   => 'Default estimate label',
				'id'      => 'dutt_shd_api_default_estimated_time',
				'type'    => 'text',
				'default' => self::defaults()['api_default_estimated_time'],
				'desc'    => 'Used only if the API does not return an estimate label.',
			),
			array(
				'title'   => 'Store name',
				'id'      => 'dutt_shd_store_name',
				'type'    => 'text',
				'default' => self::defaults()['store_name'],
			),
			array(
				'title'   => 'Store city',
				'id'      => 'dutt_shd_store_city',
				'type'    => 'text',
				'default' => self::defaults()['store_city'],
			),
			array(
				'title'   => 'Store address',
				'id'      => 'dutt_shd_store_address',
				'type'    => 'text',
				'default' => self::defaults()['store_address'],
				'desc'    => 'Enter the pickup address as normal text. DUTT resolves it automatically.',
			),
			array(
				'title'   => 'Legal business name',
				'id'      => 'dutt_shd_legal_name',
				'type'    => 'text',
				'default' => self::defaults()['legal_name'],
				'desc'    => 'Required for monthly settlement and invoicing.',
			),
			array(
				'title'             => 'VAT / AFM',
				'id'                => 'dutt_shd_vat_number',
				'type'              => 'text',
				'default'           => self::defaults()['vat_number'],
				'desc'              => 'Required. Greek AFM must be 9 digits.',
				'custom_attributes' => array( 'pattern' => '\d{9}' ),
			),
			array(
				'title'   => 'Tax office / DOY',
				'id'      => 'dutt_shd_tax_office',
				'type'    => 'text',
				'default' => self::defaults()['tax_office'],
				'desc'    => 'Required for invoicing.',
			),
			array(
				'title'   => 'Billing address',
				'id'      => 'dutt_shd_billing_address',
				'type'    => 'text',
				'default' => self::defaults()['billing_address'],
				'desc'    => 'Required fiscal address for invoices.',
			),
			array(
				'title'   => 'Billing city',
				'id'      => 'dutt_shd_billing_city',
				'type'    => 'text',
				'default' => self::defaults()['billing_city'],
			),
			array(
				'title'   => 'Billing postcode',
				'id'      => 'dutt_shd_billing_postcode',
				'type'    => 'text',
				'default' => self::defaults()['billing_postcode'],
			),
			array(
				'title'   => 'Billing email',
				'id'      => 'dutt_shd_billing_email',
				'type'    => 'email',
				'default' => self::defaults()['billing_email'],
				'desc'    => 'Monthly settlement and invoicing email.',
			),
			array(
				'title'   => 'Business activity',
				'id'      => 'dutt_shd_business_activity',
				'type'    => 'text',
				'default' => self::defaults()['business_activity'],
				'desc'    => 'Optional, but useful for accounting.',
			),
			array(
				'title'             => 'Service radius in km',
				'id'                => 'dutt_shd_service_radius_km',
				'type'              => 'number',
				'default'           => self::defaults()['service_radius_km'],
				'custom_attributes' => array(
					'step' => '0.1',
					'min'  => '0',
				),
			),
			array(
				'title'             => 'Maximum allowed weight',
				'id'                => 'dutt_shd_max_weight_kg',
				'type'              => 'number',
				'default'           => self::defaults()['max_weight_kg'],
				'desc'              => 'kg',
				'custom_attributes' => array(
					'step' => '0.1',
					'min'  => '0',
				),
			),
			array(
				'title'             => 'Maximum package length',
				'id'                => 'dutt_shd_max_length_cm',
				'type'              => 'number',
				'default'           => self::defaults()['max_length_cm'],
				'desc'              => 'cm',
				'custom_attributes' => array(
					'step' => '0.1',
					'min'  => '0',
				),
			),
			array(
				'title'             => 'Maximum package width',
				'id'                => 'dutt_shd_max_width_cm',
				'type'              => 'number',
				'default'           => self::defaults()['max_width_cm'],
				'desc'              => 'cm',
				'custom_attributes' => array(
					'step' => '0.1',
					'min'  => '0',
				),
			),
			array(
				'title'             => 'Maximum package height',
				'id'                => 'dutt_shd_max_height_cm',
				'type'              => 'number',
				'default'           => self::defaults()['max_height_cm'],
				'desc'              => 'cm',
				'custom_attributes' => array(
					'step' => '0.1',
					'min'  => '0',
				),
			),
			array(
				'title'   => 'VAT note',
				'id'      => 'dutt_shd_vat_note',
				'type'    => 'textarea',
				'default' => self::defaults()['vat_note'],
				'desc'    => 'The checkout shipping amount is the customer-facing charge. Any store-paid difference is stored separately on the WooCommerce order for merchant reconciliation.',
			),
			array(
				'title'   => 'Customer delivery charge policy',
				'id'      => 'dutt_shd_customer_charge_policy',
				'type'    => 'select',
				'default' => self::defaults()['customer_charge_policy'],
				'options' => array(
					'full_quote'            => 'Customer pays full DUTT quote at checkout',
					'store_absorbs'         => 'Store pays full delivery; customer sees free delivery',
					'free_over_threshold'   => 'Free delivery over order amount; otherwise customer pays quote',
					'fixed_customer_amount' => 'Customer pays fixed amount; store pays the difference',
				),
				'desc'    => 'Controls the WooCommerce shipping amount paid by the customer. The full DUTT quote, customer charge, and store-paid amount are stored on the order.',
			),
			array(
				'title'             => 'Free delivery threshold',
				'id'                => 'dutt_shd_free_delivery_threshold',
				'type'              => 'number',
				'default'           => self::defaults()['free_delivery_threshold'],
				'desc'              => get_woocommerce_currency_symbol(),
				'custom_attributes' => array(
					'step' => '0.01',
					'min'  => '0',
				),
			),
			array(
				'title'             => 'Fixed customer charge',
				'id'                => 'dutt_shd_fixed_customer_charge',
				'type'              => 'number',
				'default'           => self::defaults()['fixed_customer_charge'],
				'desc'              => get_woocommerce_currency_symbol(),
				'custom_attributes' => array(
					'step' => '0.01',
					'min'  => '0',
				),
			),
			array(
				'title'             => 'Preparation time in minutes',
				'id'                => 'dutt_shd_preparation_minutes',
				'type'              => 'number',
				'default'           => self::defaults()['preparation_minutes'],
				'custom_attributes' => array( 'min' => '0' ),
			),
			array(
				'title'   => 'Service starts',
				'id'      => 'dutt_shd_service_start',
				'type'    => 'text',
				'default' => self::defaults()['service_start'],
				'desc'    => 'Format: HH:MM',
			),
			array(
				'title'   => 'Service ends',
				'id'      => 'dutt_shd_service_end',
				'type'    => 'text',
				'default' => self::defaults()['service_end'],
				'desc'    => 'Format: HH:MM',
			),
			array(
				'title'   => 'Enable diagnostic logging',
				'id'      => 'dutt_shd_diagnostic_logging',
				'type'    => 'checkbox',
				'default' => self::defaults()['diagnostic_logging'],
				'desc'    => 'Opt in to redacted Dutt diagnostics in WooCommerce logs and the Dutt Logs page.',
			),
			array(
				'title'   => 'Demo rider availability',
				'id'      => 'dutt_shd_mock_rider_availability',
				'type'    => 'select',
				'default' => self::defaults()['mock_rider_availability'],
				'options' => array(
					'available'   => 'available',
					'unavailable' => 'unavailable',
				),
			),
			array(
				'title'   => 'Legacy mock estimated delivery time',
				'id'      => 'dutt_shd_mock_estimated_time',
				'type'    => 'text',
				'default' => self::defaults()['mock_estimated_time'],
				'desc'    => 'Kept for backward compatibility. New quotes use Default estimate label or the API estimate.',
			),
			array(
				'type' => 'sectionend',
				'id'   => 'dutt_shd_settings_end',
			),
		);

		$hidden_in_production = array();

		if ( ! self::developer_settings_enabled() ) {
			$hidden_in_production = array_merge(
				$hidden_in_production,
				array(
					'dutt_shd_quote_api_url',
					'dutt_shd_create_delivery_api_url',
					'dutt_shd_cancel_delivery_api_url',
					'dutt_shd_return_order_api_url',
					'dutt_shd_return_mark_ready_api_url',
					'dutt_shd_status_api_url',
					'dutt_shd_merchant_overview_api_url',
					'dutt_shd_refund_notice_api_url',
					'dutt_shd_merchant_support_api_url',
					'dutt_shd_connection_test_api_url',
					'dutt_shd_api_timeout_seconds',
				)
			);
		}

		if ( ! self::mock_mode_enabled() ) {
			$hidden_in_production = array_merge(
				$hidden_in_production,
				array(
					'dutt_shd_api_mode',
					'dutt_shd_mock_rider_availability',
					'dutt_shd_mock_estimated_time',
				)
			);
		}

		if ( empty( $hidden_in_production ) ) {
			return $fields;
		}

		return array_values(
			array_filter(
				$fields,
				static function ( array $field ) use ( $hidden_in_production ): bool {
					return ! isset( $field['id'] ) || ! in_array( $field['id'], $hidden_in_production, true );
				}
			)
		);
	}

	public static function render_connection_test_field( array $value ): void {
		$test_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=dutt_shd_connection_test' ),
			'dutt_shd_connection_test'
		);
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Display-only redirect values; both are sanitized and escaped.
		$status  = isset( $_GET['dutt_connection_status'] )
			? sanitize_key( wp_unslash( $_GET['dutt_connection_status'] ) )
			: '';
		$message = isset( $_GET['dutt_connection_message'] )
			? sanitize_text_field( wp_unslash( $_GET['dutt_connection_message'] ) )
			: '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$notice_class = 'success' === $status ? 'notice notice-success inline' : 'notice notice-error inline';
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo esc_html( $value['title'] ?? 'Connection test' ); ?>
			</th>
			<td class="forminp">
				<a class="button button-secondary" href="<?php echo esc_url( $test_url ); ?>">
					<?php esc_html_e( 'Test Dutt connection', 'dutt-same-hour-delivery' ); ?>
				</a>
				<p class="description">
					<?php esc_html_e( 'Uses the currently saved Merchant Key and endpoint settings. Save changes before testing.', 'dutt-same-hour-delivery' ); ?>
				</p>
				<?php if ( '' !== $message ) : ?>
					<div class="<?php echo esc_attr( $notice_class ); ?>">
						<p><?php echo esc_html( $message ); ?></p>
					</div>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	public static function handle_connection_test(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to test the DUTT connection.', 'dutt-same-hour-delivery' ) );
		}

		check_admin_referer( 'dutt_shd_connection_test' );

		$settings = self::all();
		if ( ! self::has_merchant_key( $settings ) ) {
			self::redirect_connection_test_result(
				'error',
				'Merchant key is required before Dutt delivery can be used.'
			);
		}

		$missing_fields = self::missing_required_billing_fields( $settings );
		if ( ! empty( $missing_fields ) ) {
			self::redirect_connection_test_result(
				'error',
				'Complete required merchant invoice details before testing: ' . implode( ', ', $missing_fields )
			);
		}

		$policy_status = self::merchant_integration_policy_status( $settings );
		if ( empty( $policy_status['ok'] ) ) {
			self::redirect_connection_test_result(
				'error',
				'DUTT merchant policy validation failed: ' . (string) ( $policy_status['reason'] ?? 'unknown_policy_error' )
			);
		}

		$endpoint = esc_url_raw( trim( (string) ( $settings['connection_test_api_url'] ?? '' ) ) );
		if ( '' === $endpoint ) {
			self::redirect_connection_test_result( 'error', 'DUTT connection test endpoint is missing.' );
		}

		$headers = array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
			'User-Agent'   => 'DUTT-WooCommerce/' . DUTT_SHD_VERSION,
		);

		$merchant_key   = trim( (string) ( $settings['merchant_key'] ?? '' ) );
		$legacy_api_key = trim( (string) ( $settings['api_key'] ?? '' ) );
		if ( '' !== $merchant_key ) {
			$headers['X-DUTT-Merchant-Key'] = $merchant_key;
		} elseif ( '' !== $legacy_api_key ) {
			$headers['X-DUTT-API-Key'] = $legacy_api_key;
		} else {
			self::redirect_connection_test_result( 'error', 'Add and save a DUTT Merchant Key before testing the connection.' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => max( 3, (int) ( $settings['api_timeout_seconds'] ?? 8 ) ),
				'headers' => $headers,
				'body'    => wp_json_encode(
					array_merge(
						array(
							'source'           => 'woocommerce',
							'site_url'         => home_url(),
							'store'            => array(
								'name'    => trim( (string) ( $settings['store_name'] ?? '' ) ),
								'city'    => trim( (string) ( $settings['store_city'] ?? '' ) ),
								'address' => trim( (string) ( $settings['store_address'] ?? '' ) ),
								'billing' => self::merchant_billing_profile( $settings ),
							),
							'merchant_billing' => self::merchant_billing_profile( $settings ),
						),
						self::merchant_integration_policy_payload( $settings )
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			self::redirect_connection_test_result( 'error', 'DUTT connection failed: ' . $response->get_error_message() );
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$raw_body    = (string) wp_remote_retrieve_body( $response );
		$data        = json_decode( $raw_body, true );

		if ( $status_code < 200 || $status_code >= 300 || ! is_array( $data ) ) {
			self::redirect_connection_test_result( 'error', 'DUTT connection failed. HTTP status: ' . $status_code );
		}

		if ( empty( $data['success'] ) ) {
			$reason = sanitize_text_field( (string) ( $data['reason'] ?? 'unknown_error' ) );
			self::redirect_connection_test_result( 'error', 'DUTT connection failed: ' . $reason );
		}

		$merchant_name = sanitize_text_field( (string) ( $data['merchant_name'] ?? '' ) );
		$merchant_city = sanitize_text_field( (string) ( $data['merchant_city'] ?? '' ) );
		$message       = 'DUTT connection is working.';
		if ( '' !== $merchant_name ) {
			$message .= ' Merchant: ' . $merchant_name;
		}
		if ( '' !== $merchant_city ) {
			$message .= ' (' . $merchant_city . ')';
		}

		self::redirect_connection_test_result( 'success', $message );
	}

	private static function redirect_connection_test_result( string $status, string $message ): void {
		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::log(
				'success' === $status ? 'info' : 'warning',
				'connection_test_' . $status,
				array( 'message' => $message )
			);
		}

		$fallback = admin_url( 'admin.php?page=wc-settings&tab=shipping&section=' . self::SECTION );
		$referer  = wp_get_referer();
		$target   = $referer ? remove_query_arg( array( 'dutt_connection_status', 'dutt_connection_message' ), $referer ) : $fallback;

		wp_safe_redirect(
			add_query_arg(
				array(
					'dutt_connection_status'  => $status,
					'dutt_connection_message' => $message,
				),
				$target
			)
		);
		exit;
	}
}

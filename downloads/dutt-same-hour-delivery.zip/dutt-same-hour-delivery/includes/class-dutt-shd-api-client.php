<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DUTT_SHD_API_Client {
	public static function merchant_support( array $payload ): array {
		$settings = DUTT_SHD_Settings::all();
		$endpoint = esc_url_raw( trim( (string) ( $settings['merchant_support_api_url'] ?? '' ) ) );
		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'merchant_support_endpoint_missing' );
		}

		return self::post_json_endpoint( $endpoint, $payload, $settings, 'merchant_support' );
	}

	public static function get_quote( array $payload ): array {
		$settings = DUTT_SHD_Settings::all();
		$country  = trim( (string) ( $payload['country'] ?? 'GR' ) );
		$policy   = DUTT_SHD_Settings::merchant_integration_policy_status(
			$settings,
			$country,
			get_woocommerce_currency()
		);
		if ( empty( $policy['ok'] ) ) {
			return self::fail( (string) ( $policy['reason'] ?? 'merchant_integration_policy_failed' ), $policy );
		}

		if ( 'mock' === $settings['api_mode'] ) {
			return self::get_mock_quote( $payload, $settings );
		}

		$endpoint = esc_url_raw( trim( (string) $settings['quote_api_url'] ) );
		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'api_endpoint_missing' );
		}

		$body = array_merge(
			array(
				'store'                   => array(
					'name'    => trim( (string) $settings['store_name'] ),
					'city'    => trim( (string) $settings['store_city'] ),
					'address' => trim( (string) $settings['store_address'] ),
					'country' => 'Greece',
					'billing' => DUTT_SHD_Settings::merchant_billing_profile( $settings ),
				),
				'delivery'                => array(
					'city'     => trim( (string) ( $payload['city'] ?? '' ) ),
					'address'  => trim( (string) ( $payload['address'] ?? '' ) ),
					'postcode' => trim( (string) ( $payload['postcode'] ?? '' ) ),
					'country'  => $country,
				),
				'package'                 => array(
					'weight_kg' => self::number_or_null( $payload['weight_kg'] ?? null ),
					'length_cm' => self::number_or_null( $payload['length_cm'] ?? null ),
					'width_cm'  => self::number_or_null( $payload['width_cm'] ?? null ),
					'height_cm' => self::number_or_null( $payload['height_cm'] ?? null ),
				),
				'constraints'             => array(
					'service_radius_km'   => self::number_or_null( $settings['service_radius_km'] ),
					'preparation_minutes' => self::number_or_null( $settings['preparation_minutes'] ),
				),
				'cart'                    => array(
					'subtotal' => self::number_or_null( $payload['cart_subtotal'] ?? null ),
				),
				'delivery_pricing_policy' => array(
					'customer_charge_policy'  => trim( (string) ( $settings['customer_charge_policy'] ?? 'full_quote' ) ),
					'free_delivery_threshold' => self::number_or_null( $settings['free_delivery_threshold'] ?? null ),
					'fixed_customer_charge'   => self::number_or_null( $settings['fixed_customer_charge'] ?? null ),
				),
				'currency'                => get_woocommerce_currency(),
				'source'                  => 'woocommerce',
				'site_url'                => home_url(),
				'merchant_billing'        => DUTT_SHD_Settings::merchant_billing_profile( $settings ),
			),
			DUTT_SHD_Settings::merchant_integration_policy_payload( $settings, $country )
		);

		$headers = array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
			'User-Agent'   => 'DUTT-WooCommerce/' . DUTT_SHD_VERSION,
		);

		$merchant_key   = trim( (string) ( $settings['merchant_key'] ?? '' ) );
		$legacy_api_key = trim( (string) ( $settings['api_key'] ?? '' ) );
		if ( '' !== $merchant_key ) {
			$headers['X-DUTT-Merchant-Key'] = $merchant_key;
		} elseif ( '' !== $legacy_api_key ) {
			$headers['X-DUTT-API-Key'] = $legacy_api_key;
		}

		$cache_key    = self::quote_cache_key( $endpoint, $headers, $body );
		$cached_quote = self::get_cached_quote( $cache_key );
		if ( is_array( $cached_quote ) ) {
			return $cached_quote;
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 3, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => $headers,
				'body'                => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( 'api_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );
		$billing  = is_array( $data ) ? DUTT_SHD_Business_Billing_Notice::from_api_response( $status, $data ) : null;
		if ( is_array( $billing ) ) {
			DUTT_SHD_Settings::remember_business_billing_block( $billing );
			return self::fail(
				'business_billing_blocked',
				array(
					'status'  => $status,
					'billing' => $billing,
				)
			);
		}

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				'api_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? 'quote_failed' ), $data );
		}
		if ( 'EUR' !== strtoupper( trim( (string) ( $data['currency'] ?? '' ) ) ) || '' === trim( (string) ( $data['quote_id'] ?? '' ) ) ) {
			return self::fail( 'quote_contract_invalid' );
		}
		$gross      = self::number_or_null( $data['price_with_vat'] ?? $data['customer_gross'] ?? $data['price'] ?? null );
		$net        = self::number_or_null( $data['price_net'] ?? $data['customer_net'] ?? null );
		$vat_rate   = self::normalize_vat_rate( $data['vat_rate'] ?? null, $gross, $net );
		$vat_amount = self::number_or_null( $data['vat_amount'] ?? null );
		if ( null === $vat_amount && null !== $gross && null !== $net ) {
			$vat_amount = round( max( 0, $gross - $net ), 2 );
		}

		if ( null === $gross && null === $net ) {
			return self::fail( 'quote_price_missing' );
		}

		$display_price = self::resolve_woocommerce_shipping_cost( $gross, $net );
		$charge        = self::quote_charge_from_backend( $data );
		if ( empty( $charge['ok'] ) ) {
			return self::fail(
				'quote_charge_policy_invalid',
				array(
					'missing_fields' => $charge['missing_fields'] ?? array(),
					'invalid_fields' => $charge['invalid_fields'] ?? array(),
				)
			);
		}

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'quote_success',
				array(
					'mode'            => $settings['api_mode'],
					'endpoint_host'   => self::endpoint_host( $endpoint ),
					'city'            => $body['delivery']['city'],
					'postcode'        => $body['delivery']['postcode'],
					'price'           => $display_price,
					'price_with_vat'  => null !== $gross ? $gross : '',
					'price_net'       => null !== $net ? $net : '',
					'distance_km'     => self::number_or_null( $data['distance_km'] ?? $data['distance'] ?? null ),
					'quote_id'        => (string) ( $data['quote_id'] ?? '' ),
					'pricing_version' => (string) ( $data['pricing_version'] ?? '' ),
				)
			);
		}

		$quote = array(
			'success'                        => true,
			'price'                          => $display_price,
			'price_with_vat'                 => null !== $gross ? $gross : $display_price,
			'price_net'                      => null !== $net ? $net : null,
			'vat_rate'                       => $vat_rate,
			'vat_amount'                     => $vat_amount,
			'quote_price'                    => $charge['quote_price'],
			'quote_price_net'                => $charge['quote_price_net'],
			'quote_price_vat'                => $charge['quote_price_vat'],
			'customer_charge'                => $charge['customer_charge'],
			'customer_charge_net'            => $charge['customer_charge_net'],
			'customer_charge_vat'            => $charge['customer_charge_vat'],
			'store_contribution'             => $charge['store_contribution'],
			'store_contribution_net'         => $charge['store_contribution_net'],
			'store_contribution_vat'         => $charge['store_contribution_vat'],
			'settlement_due'                 => $charge['settlement_due'],
			'settlement_due_net'             => $charge['settlement_due_net'],
			'settlement_due_vat'             => $charge['settlement_due_vat'],
			'merchant_due_to_dutt'           => $charge['merchant_due_to_dutt'],
			'merchant_due_to_dutt_net'       => $charge['merchant_due_to_dutt_net'],
			'merchant_due_to_dutt_vat'       => $charge['merchant_due_to_dutt_vat'],
			'fiscal_billing_model'           => $charge['fiscal_billing_model'],
			'charge_policy'                  => $charge['charge_policy'],
			'cart_subtotal'                  => $charge['cart_subtotal'],
			'customer_receipt_required'      => $charge['customer_receipt_required'],
			'customer_receipt_document_kind' => $charge['customer_receipt_document_kind'],
			'merchant_invoice_required'      => $charge['merchant_invoice_required'],
			'merchant_invoice_document_kind' => $charge['merchant_invoice_document_kind'],
			'merchant_invoice_amount'        => $charge['merchant_invoice_amount'],
			'merchant_invoice_net'           => $charge['merchant_invoice_net'],
			'merchant_invoice_vat'           => $charge['merchant_invoice_vat'],
			'fiscal_provider_ready'          => $charge['fiscal_provider_ready'],
			'estimated_time'                 => (string) ( $data['estimated_time'] ?? $data['estimated_time_label'] ?? $settings['api_default_estimated_time'] ),
			'distance_km'                    => self::number_or_null( $data['distance_km'] ?? $data['distance'] ?? null ),
			'currency'                       => (string) ( $data['currency'] ?? get_woocommerce_currency() ),
			'quote_id'                       => (string) ( $data['quote_id'] ?? '' ),
			'quote_created_at'               => self::number_or_null( $data['quote_created_at'] ?? null ),
			'quote_expires_at'               => self::number_or_null( $data['quote_expires_at'] ?? null ),
			'quote_valid_seconds'            => self::number_or_null( $data['quote_valid_seconds'] ?? null ),
			'pricing_version'                => (string) ( $data['pricing_version'] ?? '' ),
			'raw'                            => $data,
		);

		DUTT_SHD_Settings::clear_business_billing_block();
		self::set_cached_quote( $cache_key, $quote );
		return $quote;
	}

	public static function create_delivery( WC_Order $order ): array {
		if ( self::is_cash_on_delivery_method( $order->get_payment_method() ) ) {
			return self::fail(
				'plugin_cod_disabled',
				array( 'message' => 'Cash on delivery is not available for DUTT deliveries.' )
			);
		}

		$settings         = DUTT_SHD_Settings::all();
		$delivery_country = $order->get_shipping_country() ?: $order->get_billing_country() ?: 'GR';
		$policy           = DUTT_SHD_Settings::merchant_integration_policy_status(
			$settings,
			$delivery_country,
			$order->get_currency()
		);
		if ( empty( $policy['ok'] ) ) {
			return self::fail( (string) ( $policy['reason'] ?? 'merchant_integration_policy_failed' ), $policy );
		}

		if ( 'mock' === $settings['api_mode'] ) {
			$delivery         = DUTT_SHD_Mock_API::create_delivery( $order->get_id() );
			$pickup_reference = self::pickup_reference( $order );
			if ( class_exists( 'DUTT_SHD_Logger' ) ) {
				DUTT_SHD_Logger::info(
					'delivery_create_success',
					array(
						'mode'             => 'mock',
						'order_id'         => $order->get_id(),
						'order_number'     => $order->get_order_number(),
						'pickup_reference' => $pickup_reference,
						'delivery_id'      => (string) ( $delivery['delivery_id'] ?? '' ),
						'status'           => (string) ( $delivery['status'] ?? 'pending_dispatch' ),
					)
				);
			}
			return array(
				'success'          => true,
				'delivery_id'      => (string) ( $delivery['delivery_id'] ?? '' ),
				'status'           => (string) ( $delivery['status'] ?? 'pending_dispatch' ),
				'order_number'     => $pickup_reference,
				'pickup_reference' => $pickup_reference,
				'tracking_url'     => '',
				'tracking_token'   => '',
				'raw'              => $delivery,
			);
		}

		$endpoint = esc_url_raw( trim( (string) $settings['create_delivery_api_url'] ) );
		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'create_delivery_endpoint_missing' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 5, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => self::api_headers( $settings ),
				'body'                => wp_json_encode( self::create_delivery_payload( $order, $settings ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( 'create_delivery_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );
		$billing  = is_array( $data ) ? DUTT_SHD_Business_Billing_Notice::from_api_response( $status, $data ) : null;
		if ( is_array( $billing ) ) {
			DUTT_SHD_Settings::remember_business_billing_block( $billing );
			return self::fail(
				'business_billing_blocked',
				array(
					'status'  => $status,
					'billing' => $billing,
				)
			);
		}

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				'create_delivery_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? 'create_delivery_failed' ), $data );
		}
		$delivery_id = (string) ( $data['delivery_id'] ?? $data['dutt_order_id'] ?? $data['order_id'] ?? '' );
		if ( '' === $delivery_id ) {
			return self::fail( 'create_delivery_id_missing', $data );
		}

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'delivery_create_success',
				array(
					'mode'             => $settings['api_mode'],
					'endpoint_host'    => self::endpoint_host( $endpoint ),
					'order_id'         => $order->get_id(),
					'order_number'     => $order->get_order_number(),
					'pickup_reference' => self::pickup_reference( $order ),
					'delivery_id'      => $delivery_id,
					'status'           => (string) ( $data['status'] ?? 'pending_dispatch' ),
				)
			);
		}

		return array(
			'success'          => true,
			'delivery_id'      => $delivery_id,
			'status'           => (string) ( $data['status'] ?? 'pending_dispatch' ),
			'city_id'          => (string) ( $data['city_id'] ?? '' ),
			'order_number'     => (string) ( $data['order_number'] ?? '' ),
			'pickup_reference' => (string) ( $data['pickup_reference'] ?? $data['merchant_order_reference'] ?? $data['order_number'] ?? '' ),
			'tracking_url'     => esc_url_raw( (string) ( $data['tracking_url'] ?? $data['trackingUrl'] ?? '' ) ),
			'tracking_token'   => sanitize_text_field( (string) ( $data['tracking_token'] ?? $data['trackingToken'] ?? '' ) ),
			'estimated_time'   => (string) ( $data['estimated_time'] ?? '' ),
			'raw'              => $data,
		);
	}

	public static function create_return_delivery( WC_Order $order, array $return_data ): array {
		$settings       = DUTT_SHD_Settings::all();
		$pickup_country = $order->get_shipping_country() ?: $order->get_billing_country() ?: 'GR';
		$policy         = DUTT_SHD_Settings::merchant_integration_policy_status(
			$settings,
			$pickup_country,
			$order->get_currency()
		);
		if ( empty( $policy['ok'] ) ) {
			return self::fail( (string) ( $policy['reason'] ?? 'merchant_integration_policy_failed' ), $policy );
		}

		if ( 'mock' === $settings['api_mode'] ) {
			$delivery         = DUTT_SHD_Mock_API::create_delivery( 'return_' . $order->get_id() );
			$pickup_reference = self::return_pickup_reference( $order );

			return array(
				'success'           => true,
				'delivery_id'       => (string) ( $delivery['delivery_id'] ?? '' ),
				'status'            => (string) ( $delivery['status'] ?? 'pending_dispatch' ),
				'order_number'      => $pickup_reference,
				'pickup_reference'  => $pickup_reference,
				'tracking_url'      => '',
				'tracking_token'    => '',
				'external_order_id' => self::return_external_order_id( $order ),
				'raw'               => $delivery,
			);
		}

		$create_endpoint = esc_url_raw( trim( (string) ( $settings['return_order_api_url'] ?? '' ) ) );
		if ( ! self::valid_https_endpoint( $create_endpoint ) ) {
			return self::fail( 'return_order_endpoint_missing' );
		}

		$ready_endpoint = esc_url_raw( trim( (string) ( $settings['return_mark_ready_api_url'] ?? '' ) ) );
		if ( ! self::valid_https_endpoint( $ready_endpoint ) ) {
			return self::fail( 'return_dispatch_endpoint_missing' );
		}

		$payload = self::return_delivery_payload( $order, $settings, $return_data );
		$created = self::post_json_endpoint( $create_endpoint, $payload, $settings, 'return_order' );
		if ( empty( $created['success'] ) ) {
			return $created;
		}

		$ready_payload = array_merge(
			$payload,
			array(
				'external_hash' => (string) ( $created['external_hash'] ?? '' ),
			)
		);
		$dispatched    = self::post_json_endpoint( $ready_endpoint, $ready_payload, $settings, 'return_dispatch' );
		if ( empty( $dispatched['success'] ) ) {
			return array_merge(
				$dispatched,
				array(
					'return_order_created' => true,
					'external_order_id'    => $payload['external_order_id'],
					'external_hash'        => (string) ( $created['external_hash'] ?? '' ),
				)
			);
		}

		$delivery_id = (string) ( $dispatched['delivery_id'] ?? $dispatched['dutt_order_id'] ?? $dispatched['order_id'] ?? '' );
		if ( '' === $delivery_id ) {
			return self::fail( 'return_delivery_id_missing', $dispatched );
		}

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'return_delivery_created',
				array(
					'endpoint_host'    => self::endpoint_host( $ready_endpoint ),
					'order_id'         => $order->get_id(),
					'order_number'     => $order->get_order_number(),
					'pickup_reference' => self::return_pickup_reference( $order ),
					'delivery_id'      => $delivery_id,
					'status'           => (string) ( $dispatched['status'] ?? 'pending_dispatch' ),
				)
			);
		}

		return array(
			'success'           => true,
			'delivery_id'       => $delivery_id,
			'status'            => (string) ( $dispatched['status'] ?? 'pending_dispatch' ),
			'city_id'           => (string) ( $dispatched['city_id'] ?? '' ),
			'order_number'      => (string) ( $dispatched['order_number'] ?? '' ),
			'pickup_reference'  => (string) ( $dispatched['pickup_reference'] ?? $dispatched['merchant_order_reference'] ?? $dispatched['order_number'] ?? self::return_pickup_reference( $order ) ),
			'tracking_url'      => esc_url_raw( (string) ( $dispatched['tracking_url'] ?? $dispatched['trackingUrl'] ?? '' ) ),
			'tracking_token'    => sanitize_text_field( (string) ( $dispatched['tracking_token'] ?? $dispatched['trackingToken'] ?? '' ) ),
			'estimated_time'    => (string) ( $dispatched['estimated_time'] ?? '' ),
			'external_order_id' => $payload['external_order_id'],
			'external_hash'     => (string) ( $dispatched['external_hash'] ?? $created['external_hash'] ?? '' ),
			'raw'               => $dispatched,
		);
	}

	public static function cancel_delivery( WC_Order $order ): array {
		$settings    = DUTT_SHD_Settings::all();
		$delivery_id = self::order_delivery_id( $order );

		if ( '' === $delivery_id ) {
			return self::fail( 'cancel_delivery_id_missing' );
		}

		if ( 'mock' === $settings['api_mode'] ) {
			$result = DUTT_SHD_Mock_API::cancel_delivery( $delivery_id );
			if ( class_exists( 'DUTT_SHD_Logger' ) ) {
				DUTT_SHD_Logger::info(
					'delivery_cancel_success',
					array(
						'mode'         => 'mock',
						'order_id'     => $order->get_id(),
						'order_number' => $order->get_order_number(),
						'delivery_id'  => $delivery_id,
						'status'       => (string) ( $result['status'] ?? 'cancelled_by_admin' ),
					)
				);
			}
			return $result;
		}

		$endpoint = esc_url_raw( trim( (string) ( $settings['cancel_delivery_api_url'] ?? '' ) ) );
		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'cancel_delivery_endpoint_missing' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 5, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => self::api_headers( $settings ),
				'body'                => wp_json_encode(
					array(
						'delivery_id'   => $delivery_id,
						'dutt_order_id' => $delivery_id,
						'city_id'       => (string) $order->get_meta( 'dutt_city_id' ),
						'reason'        => 'cancelled_from_woocommerce',
						'order'         => array(
							'id'               => (string) $order->get_id(),
							'number'           => (string) $order->get_order_number(),
							'pickup_reference' => self::pickup_reference( $order ),
							'status'           => $order->get_status(),
						),
						'source'        => 'woocommerce',
						'site_url'      => home_url(),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( 'cancel_delivery_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				'cancel_delivery_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? 'cancel_delivery_failed' ), $data );
		}

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'delivery_cancel_success',
				array(
					'mode'          => $settings['api_mode'],
					'endpoint_host' => self::endpoint_host( $endpoint ),
					'order_id'      => $order->get_id(),
					'order_number'  => $order->get_order_number(),
					'delivery_id'   => $delivery_id,
					'status'        => (string) ( $data['status'] ?? 'cancelled_by_admin' ),
				)
			);
		}

		return array(
			'success'         => true,
			'delivery_id'     => (string) ( $data['delivery_id'] ?? $delivery_id ),
			'status'          => (string) ( $data['status'] ?? 'cancelled_by_admin' ),
			'previous_status' => (string) ( $data['previous_status'] ?? '' ),
			'raw'             => $data,
		);
	}

	public static function get_delivery_status( WC_Order $order ): array {
		$settings    = DUTT_SHD_Settings::all();
		$delivery_id = self::order_delivery_id( $order );
		$endpoint    = esc_url_raw( trim( (string) ( $settings['status_api_url'] ?? '' ) ) );

		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'status_endpoint_missing' );
		}

		if ( '' === $delivery_id ) {
			return self::fail( 'status_delivery_id_missing' );
		}

		if ( 'mock' === $settings['api_mode'] ) {
			return array(
				'success'      => true,
				'delivery_id'  => $delivery_id,
				'status'       => (string) $order->get_meta( 'dutt_status' ),
				'eta_delivery' => (string) $order->get_meta( 'dutt_estimated_time' ),
				'history'      => $order->get_meta( 'dutt_status_history' ),
			);
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 5, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => self::api_headers( $settings ),
				'body'                => wp_json_encode(
					array(
						'delivery_id'       => $delivery_id,
						'dutt_order_id'     => $delivery_id,
						'city_id'           => (string) $order->get_meta( 'dutt_city_id' ),
						'external_order_id' => (string) $order->get_id(),
						'order'             => array(
							'id'               => (string) $order->get_id(),
							'number'           => (string) $order->get_order_number(),
							'pickup_reference' => self::pickup_reference( $order ),
						),
						'source'            => 'woocommerce',
						'site_url'          => home_url(),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( 'status_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				'status_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? 'status_failed' ), $data );
		}

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'delivery_status_refresh_success',
				array(
					'endpoint_host' => self::endpoint_host( $endpoint ),
					'order_id'      => $order->get_id(),
					'delivery_id'   => $delivery_id,
					'status'        => (string) ( $data['status'] ?? '' ),
				)
			);
		}

		return $data;
	}

	public static function report_refund( WC_Order $order, WC_Order_Refund $refund ): array {
		$settings = DUTT_SHD_Settings::all();
		$endpoint = esc_url_raw( trim( (string) ( $settings['refund_notice_api_url'] ?? '' ) ) );

		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'refund_notice_endpoint_missing' );
		}

		$delivery_id = self::order_delivery_id( $order );
		if ( '' === trim( $delivery_id ) ) {
			return array(
				'success'         => true,
				'ignored'         => true,
				'reason'          => 'ignored_pre_dispatch_refund',
				'requires_review' => false,
			);
		}

		$amount          = abs( (float) $refund->get_amount() );
		$shipping_refund = DUTT_SHD_WooCommerce_Fiscal::refund_shipping_context( $order, $refund );
		$body            = array(
			'source'               => 'woocommerce',
			'site_url'             => home_url(),
			'external_order_id'    => (string) $order->get_id(),
			'order_number'         => (string) $order->get_order_number(),
			'refund_id'            => (string) $refund->get_id(),
			'amount'               => $amount,
			'currency'             => $order->get_currency(),
			'status'               => 'reported',
			'reason'               => (string) $refund->get_reason(),
			'dutt_order_id'        => $delivery_id,
			'delivery_id'          => $delivery_id,
			'refund_scope'         => (string) $shipping_refund['status'],
			'dutt_shipping_refund' => $shipping_refund,
			'city_id'              => (string) $order->get_meta( 'dutt_city_id' ),
			'order'                => array(
				'id'               => (string) $order->get_id(),
				'number'           => (string) $order->get_order_number(),
				'status'           => $order->get_status(),
				'total'            => (float) $order->get_total(),
				'pickup_reference' => self::pickup_reference( $order ),
			),
			'refund'               => array(
				'id'         => (string) $refund->get_id(),
				'amount'     => $amount,
				'reason'     => (string) $refund->get_reason(),
				'created_at' => $refund->get_date_created() ? $refund->get_date_created()->date( DATE_ATOM ) : '',
			),
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 5, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => self::api_headers( $settings ),
				'body'                => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( 'refund_notice_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				'refund_notice_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? 'refund_notice_failed' ), $data );
		}

		return array(
			'success'                => true,
			'refund_id'              => (string) ( $data['refund_id'] ?? $refund->get_id() ),
			'refund_hash'            => (string) ( $data['refund_hash'] ?? '' ),
			'requires_review'        => ! empty( $data['requires_review'] ),
			'ignored'                => ! empty( $data['ignored'] ),
			'review_status'          => (string) ( $data['review_status'] ?? '' ),
			'settlement_impact'      => (string) ( $data['settlement_impact'] ?? '' ),
			'auto_ledger_adjustment' => ! empty( $data['auto_ledger_adjustment'] ),
			'accounting_status'      => (string) ( $data['accounting_status'] ?? '' ),
			'accounting_action'      => (string) ( $data['accounting_action'] ?? '' ),
			'reason'                 => (string) ( $data['reason'] ?? '' ),
			'raw'                    => $data,
		);
	}

	public static function sync_settlement_operation( WC_Order $order ): array {
		$settings    = DUTT_SHD_Settings::all();
		$endpoint    = esc_url_raw( trim( (string) ( $settings['merchant_settlement_sync_api_url'] ?? '' ) ) );
		$delivery_id = self::order_delivery_id( $order );

		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( 'merchant_settlement_sync_endpoint_missing' );
		}

		if ( '' === $delivery_id ) {
			return self::fail( 'merchant_settlement_sync_delivery_id_missing' );
		}

		$operation = array(
			'operationResult'  => (string) $order->get_meta( 'dutt_operation_result' ),
			'settlementMode'   => (string) $order->get_meta( 'dutt_operation_mode' ),
			'settlementStatus' => (string) $order->get_meta( 'dutt_settlement_status' ),
			'paymentStatus'    => (string) $order->get_meta( 'dutt_payment_status' ),
			'disputeStatus'    => (string) $order->get_meta( 'dutt_dispute_status' ),
			'disputeReason'    => (string) $order->get_meta( 'dutt_dispute_reason' ),
			'adminNotes'       => (string) $order->get_meta( 'dutt_admin_notes' ),
		);
		self::add_optional_money( $operation, 'merchantChargeGross', $order, 'dutt_merchant_charge_gross' );
		self::add_optional_money( $operation, 'driverCompensationGross', $order, 'dutt_driver_compensation_gross' );
		self::add_optional_money( $operation, 'customerChargeEffective', $order, 'dutt_customer_charge_effective' );
		self::add_optional_money( $operation, 'storeContributionEffective', $order, 'dutt_store_contribution_effective' );
		self::add_optional_money( $operation, 'merchantDueToDutt', $order, 'dutt_merchant_due_after_operation' );
		self::add_optional_bool( $operation, 'customerReceiptRequiredEffective', $order, 'dutt_customer_receipt_required_effective' );
		self::add_optional_bool( $operation, 'merchantInvoiceRequiredEffective', $order, 'dutt_merchant_invoice_required_effective' );

		$payload = array(
			'delivery_id'       => $delivery_id,
			'dutt_order_id'     => $delivery_id,
			'city_id'           => (string) $order->get_meta( 'dutt_city_id' ),
			'external_order_id' => (string) $order->get_id(),
			'order_number'      => (string) $order->get_order_number(),
			'operation'         => $operation,
			'source'            => 'woocommerce',
			'site_url'          => home_url(),
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 5, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => self::api_headers( $settings ),
				'body'                => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( 'merchant_settlement_sync_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				'merchant_settlement_sync_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? $data['error'] ?? 'merchant_settlement_sync_failed' ), $data );
		}

		return array(
			'success'    => true,
			'settlement' => $data['settlement'] ?? array(),
			'raw'        => $data,
		);
	}

	private static function get_mock_quote( array $payload, array $settings ): array {
		$address = trim( (string) ( $payload['address'] ?? '' ) );
		$city    = trim( (string) ( $payload['city'] ?? '' ) );

		if ( '' === $address || '' === $city ) {
			return self::fail( 'invalid_address' );
		}

		if ( 'available' !== $settings['mock_rider_availability'] ) {
			return self::fail( 'no_riders_available' );
		}

		$distance_km = self::mock_distance_km( $address, $city, (float) $settings['service_radius_km'] );
		if ( $distance_km > (float) $settings['service_radius_km'] ) {
			return self::fail( 'outside_service_area', array( 'distance_km' => $distance_km ) );
		}

		$gross         = self::calculate_demo_distance_price( $distance_km );
		$net           = round( $gross / 1.24, 2 );
		$vat           = round( max( 0, $gross - $net ), 2 );
		$cart_subtotal = max( 0.0, self::number_or_null( $payload['cart_subtotal'] ?? null ) ?? 0.0 );
		$policy        = sanitize_key( (string) ( $settings['customer_charge_policy'] ?? 'full_quote' ) );
		$customer      = $gross;
		if ( 'store_absorbs' === $policy ) {
			$customer = 0.0;
		} elseif ( 'free_over_threshold' === $policy && $cart_subtotal >= ( self::number_or_null( $settings['free_delivery_threshold'] ?? null ) ?? 0.0 ) ) {
			$customer = 0.0;
		} elseif ( 'fixed_customer_amount' === $policy ) {
			$customer = min( $gross, max( 0.0, self::number_or_null( $settings['fixed_customer_charge'] ?? null ) ?? 0.0 ) );
		}
		$customer     = round( $customer, 2 );
		$customer_net = round( $customer / 1.24, 2 );
		$customer_vat = round( max( 0, $customer - $customer_net ), 2 );
		$store        = round( max( 0, $gross - $customer ), 2 );
		$store_net    = round( max( 0, $net - $customer_net ), 2 );
		$store_vat    = round( max( 0, $vat - $customer_vat ), 2 );

		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::info(
				'quote_success',
				array(
					'mode'            => 'mock',
					'city'            => $city,
					'price'           => self::resolve_woocommerce_shipping_cost( $gross, null ),
					'price_with_vat'  => $gross,
					'price_net'       => $net,
					'vat_rate'        => 0.24,
					'vat_amount'      => $vat,
					'distance_km'     => $distance_km,
					'pricing_version' => 'woocommerce_mock_distance_v1',
				)
			);
		}

		$quote_created_at = round( microtime( true ) * 1000 );
		return array(
			'success'                        => true,
			'price'                          => self::resolve_woocommerce_shipping_cost( $gross, null ),
			'price_with_vat'                 => $gross,
			'price_net'                      => $net,
			'vat_rate'                       => 0.24,
			'vat_amount'                     => $vat,
			'estimated_time'                 => $settings['api_default_estimated_time'],
			'distance_km'                    => $distance_km,
			'currency'                       => get_woocommerce_currency(),
			'quote_id'                       => 'mock_' . md5( $address . '|' . $city . '|' . $distance_km ),
			'quote_created_at'               => $quote_created_at,
			'quote_expires_at'               => $quote_created_at + 1800000,
			'quote_valid_seconds'            => 1800,
			'pricing_version'                => 'woocommerce_mock_distance_v1',
			'quote_price'                    => $gross,
			'quote_price_net'                => $net,
			'quote_price_vat'                => $vat,
			'customer_charge'                => $customer,
			'customer_charge_net'            => $customer_net,
			'customer_charge_vat'            => $customer_vat,
			'store_contribution'             => $store,
			'store_contribution_net'         => $store_net,
			'store_contribution_vat'         => $store_vat,
			'settlement_due'                 => $gross,
			'settlement_due_net'             => $net,
			'settlement_due_vat'             => $vat,
			'merchant_due_to_dutt'           => $gross,
			'merchant_due_to_dutt_net'       => $net,
			'merchant_due_to_dutt_vat'       => $vat,
			'fiscal_billing_model'           => 'merchant_b2b_v1',
			'charge_policy'                  => $policy,
			'cart_subtotal'                  => $cart_subtotal,
			'customer_receipt_required'      => false,
			'customer_receipt_document_kind' => '',
			'merchant_invoice_required'      => true,
			'merchant_invoice_document_kind' => 'service_invoice',
			'merchant_invoice_amount'        => $gross,
			'merchant_invoice_net'           => $net,
			'merchant_invoice_vat'           => $vat,
			'fiscal_provider_ready'          => true,
		);
	}

	private static function api_headers( array $settings ): array {
		$headers = array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
			'User-Agent'   => 'DUTT-WooCommerce/' . DUTT_SHD_VERSION,
		);

		$merchant_key   = trim( (string) ( $settings['merchant_key'] ?? '' ) );
		$legacy_api_key = trim( (string) ( $settings['api_key'] ?? '' ) );
		if ( '' !== $merchant_key ) {
			$headers['X-DUTT-Merchant-Key'] = $merchant_key;
		} elseif ( '' !== $legacy_api_key ) {
			$headers['X-DUTT-API-Key'] = $legacy_api_key;
		}

		return $headers;
	}

	private static function quote_cache_key( string $endpoint, array $headers, array $body ): string {
		$auth = (string) ( $headers['X-DUTT-Merchant-Key'] ?? $headers['X-DUTT-API-Key'] ?? '' );
		return hash(
			'sha256',
			wp_json_encode(
				array(
					'version'  => DUTT_SHD_VERSION,
					'endpoint' => $endpoint,
					'auth'     => '' !== $auth ? hash( 'sha256', $auth ) : '',
					'body'     => $body,
				)
			)
		);
	}

	private static function get_cached_quote( string $cache_key ): ?array {
		$woocommerce = function_exists( 'WC' ) ? WC() : null;
		if ( '' === $cache_key || ! $woocommerce || ! $woocommerce->session ) {
			return null;
		}

		$cache = $woocommerce->session->get( 'dutt_shd_quote_cache' );
		if ( ! is_array( $cache ) || empty( $cache[ $cache_key ] ) || ! is_array( $cache[ $cache_key ] ) ) {
			return null;
		}

		$entry      = $cache[ $cache_key ];
		$expires_at = isset( $entry['expires_at'] ) ? (int) $entry['expires_at'] : 0;
		if ( $expires_at < time() || empty( $entry['quote'] ) || ! is_array( $entry['quote'] ) ) {
			unset( $cache[ $cache_key ] );
			$woocommerce->session->set( 'dutt_shd_quote_cache', $cache );
			return null;
		}

		$quote              = $entry['quote'];
		$quote['cache_hit'] = true;
		return $quote;
	}

	private static function set_cached_quote( string $cache_key, array $quote ): void {
		$woocommerce = function_exists( 'WC' ) ? WC() : null;
		if ( '' === $cache_key || empty( $quote['success'] ) || ! $woocommerce || ! $woocommerce->session ) {
			return;
		}

		$cache = $woocommerce->session->get( 'dutt_shd_quote_cache' );
		$cache = is_array( $cache ) ? $cache : array();
		$now   = time();
		foreach ( $cache as $key => $entry ) {
			$expires_at = is_array( $entry ) && isset( $entry['expires_at'] ) ? (int) $entry['expires_at'] : 0;
			if ( $expires_at < $now ) {
				unset( $cache[ $key ] );
			}
		}

		$cache[ $cache_key ] = array(
			'expires_at' => $now + 60,
			'quote'      => $quote,
		);

		$cache_count = count( $cache );
		while ( 10 < $cache_count ) {
			array_shift( $cache );
			--$cache_count;
		}

		$woocommerce->session->set( 'dutt_shd_quote_cache', $cache );
	}

	private static function post_json_endpoint( string $endpoint, array $payload, array $settings, string $context ): array {
		if ( ! self::valid_https_endpoint( $endpoint ) ) {
			return self::fail( $context . '_endpoint_missing' );
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'             => max( 5, (int) $settings['api_timeout_seconds'] ),
				'redirection'         => 0,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 1048576,
				'headers'             => self::api_headers( $settings ),
				'body'                => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( $context . '_request_failed', array( 'message' => $response->get_error_message() ) );
		}

		$status   = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );

		if ( $status < 200 || $status >= 300 || ! is_array( $data ) ) {
			return self::fail(
				$context . '_bad_response',
				array(
					'status' => $status,
					'body'   => substr( $raw_body, 0, 500 ),
				)
			);
		}

		if ( true !== ( $data['success'] ?? null ) ) {
			return self::fail( (string) ( $data['reason'] ?? $data['error'] ?? $context . '_failed' ), $data );
		}

		return $data;
	}

	private static function return_delivery_payload( WC_Order $order, array $settings, array $return_data ): array {
		$reference         = self::return_pickup_reference( $order );
		$external_order_id = self::return_external_order_id( $order );
		$customer_name     = self::return_value( $return_data, 'pickup_name', self::order_customer_name( $order ) );
		$customer_phone    = self::return_value( $return_data, 'pickup_phone', self::order_customer_phone( $order ) );
		$customer_email    = self::return_value( $return_data, 'pickup_email', (string) $order->get_billing_email() );
		$pickup_address    = self::return_value( $return_data, 'pickup_address', self::order_customer_address( $order ) );
		$pickup_city       = self::return_value( $return_data, 'pickup_city', self::order_customer_city( $order ) );
		$pickup_postcode   = self::return_value( $return_data, 'pickup_postcode', self::order_customer_postcode( $order ) );
		$store_name        = self::return_value( $return_data, 'delivery_name', trim( (string) $settings['store_name'] ) );
		$store_phone       = self::return_value( $return_data, 'delivery_phone', '' );
		$store_address     = self::return_value( $return_data, 'delivery_address', trim( (string) $settings['store_address'] ) );
		$store_city        = self::return_value( $return_data, 'delivery_city', trim( (string) $settings['store_city'] ) );
		$store_postcode    = self::return_value( $return_data, 'delivery_postcode', '' );
		$reason            = self::return_value( $return_data, 'reason', 'merchant_requested_return' );
		$notes             = self::return_value( $return_data, 'notes', '' );
		$metrics           = self::order_package_metrics( $order );
		$created_at        = gmdate( DATE_ATOM );

		return array_merge(
			array(
				'external_order_id'     => $external_order_id,
				'merchant_order_id'     => $external_order_id,
				'order_type'            => 'merchant_return',
				'source'                => 'merchant_return',
				'channel'               => 'woocommerce',
				'integration'           => 'woocommerce',
				'site_url'              => home_url(),
				'store'                 => array(
					'name'                => trim( (string) $settings['store_name'] ),
					'city'                => trim( (string) $settings['store_city'] ),
					'address'             => trim( (string) $settings['store_address'] ),
					'country'             => 'Greece',
					'service_radius_km'   => self::number_or_null( $settings['service_radius_km'] ),
					'preparation_minutes' => 0,
					'site_url'            => home_url(),
					'billing'             => DUTT_SHD_Settings::merchant_billing_profile( $settings ),
				),
				'merchant_billing'      => DUTT_SHD_Settings::merchant_billing_profile( $settings ),
				'pickup'                => array(
					'name'     => $customer_name,
					'phone'    => $customer_phone,
					'email'    => $customer_email,
					'address'  => $pickup_address,
					'city'     => $pickup_city,
					'postcode' => $pickup_postcode,
					'country'  => $order->get_shipping_country() ?: $order->get_billing_country() ?: 'GR',
					'notes'    => $notes,
				),
				'delivery'              => array(
					'name'     => $store_name,
					'phone'    => $store_phone,
					'address'  => $store_address,
					'city'     => $store_city,
					'postcode' => $store_postcode,
					'country'  => 'GR',
					'notes'    => 'Return to merchant location.',
				),
				'package'               => $metrics,
				'constraints'           => array(
					'service_radius_km'   => self::number_or_null( $settings['service_radius_km'] ),
					'preparation_minutes' => 0,
				),
				'order'                 => array(
					'id'                   => $external_order_id,
					'number'               => $reference,
					'pickup_reference'     => $reference,
					'order_type'           => 'merchant_return',
					'status'               => 'return_requested',
					'currency'             => $order->get_currency(),
					'total'                => 0,
					'payment_method'       => 'merchant_return',
					'payment_method_title' => 'Merchant return',
					'customer_name'        => $customer_name,
					'customer_email'       => $customer_email,
					'customer_phone'       => $customer_phone,
					'customer_note'        => $notes,
					'items'                => $metrics['items'],
				),
				'return'                => array(
					'type'                       => 'merchant_return',
					'reason'                     => $reason,
					'notes'                      => $notes,
					'original_external_order_id' => (string) $order->get_id(),
					'original_order_number'      => (string) $order->get_order_number(),
					'original_pickup_reference'  => self::pickup_reference( $order ),
					'original_dutt_order_id'     => self::order_delivery_id( $order ),
					'original_dutt_city_id'      => (string) $order->get_meta( 'dutt_city_id' ),
					'origin_adapter'             => 'woocommerce',
					'created_at'                 => $created_at,
				),
				'linked_original_order' => array(
					'adapter'           => 'woocommerce',
					'external_order_id' => (string) $order->get_id(),
					'order_number'      => (string) $order->get_order_number(),
					'pickup_reference'  => self::pickup_reference( $order ),
					'dutt_order_id'     => self::order_delivery_id( $order ),
					'city_id'           => (string) $order->get_meta( 'dutt_city_id' ),
				),
				'currency'              => $order->get_currency(),
				'webhook'               => self::status_webhook_payload(),
			),
			DUTT_SHD_Settings::merchant_integration_policy_payload(
				$settings,
				$order->get_shipping_country() ?: $order->get_billing_country() ?: 'GR'
			)
		);
	}

	private static function create_delivery_payload( WC_Order $order, array $settings ): array {
		$shipping_name             = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
		$billing_name              = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$billing_email             = (string) $order->get_billing_email();
		$shipping_phone            = method_exists( $order, 'get_shipping_phone' ) ? (string) $order->get_shipping_phone() : '';
		$delivery_address_1        = $order->get_shipping_address_1() ?: $order->get_billing_address_1();
		$delivery_address_2        = $order->get_shipping_address_2() ?: $order->get_billing_address_2();
		$delivery_city             = $order->get_shipping_city() ?: $order->get_billing_city();
		$delivery_postcode         = $order->get_shipping_postcode() ?: $order->get_billing_postcode();
		$delivery_country          = $order->get_shipping_country() ?: $order->get_billing_country();
		$metrics                   = self::order_package_metrics( $order );
		$woocommerce_fiscal        = DUTT_SHD_WooCommerce_Fiscal::ownership_payload( $order );
		$fallback_shipping_total   = $woocommerce_fiscal['shipping_total_gross'];
		$quote_price               = self::meta_money_or_fallback( $order, 'dutt_quote_price', $fallback_shipping_total );
		$customer_charge           = self::meta_money_or_fallback( $order, 'dutt_customer_charge', $fallback_shipping_total );
		$store_contribution        = self::meta_money_or_fallback( $order, 'dutt_store_contribution', 0.0 );
		$vat_rate                  = self::meta_number_or_null( $order, 'dutt_vat_rate' );
		$quote_price_net           = self::meta_money_or_fallback( $order, 'dutt_quote_price_net', self::gross_net_vat_breakdown( $quote_price, $vat_rate )['net'] );
		$quote_price_vat           = self::meta_money_or_fallback( $order, 'dutt_quote_price_vat', self::gross_net_vat_breakdown( $quote_price, $vat_rate )['vat'] );
		$customer_charge_net       = self::meta_money_or_fallback( $order, 'dutt_customer_charge_net', self::gross_net_vat_breakdown( $customer_charge, $vat_rate )['net'] );
		$customer_charge_vat       = self::meta_money_or_fallback( $order, 'dutt_customer_charge_vat', self::gross_net_vat_breakdown( $customer_charge, $vat_rate )['vat'] );
		$store_contribution_net    = self::meta_money_or_fallback( $order, 'dutt_store_contribution_net', self::gross_net_vat_breakdown( $store_contribution, $vat_rate )['net'] );
		$store_contribution_vat    = self::meta_money_or_fallback( $order, 'dutt_store_contribution_vat', self::gross_net_vat_breakdown( $store_contribution, $vat_rate )['vat'] );
		$settlement_due            = self::meta_money_or_fallback( $order, 'dutt_settlement_due', round( $customer_charge + $store_contribution, 2 ) );
		$settlement_due_net        = self::meta_money_or_fallback( $order, 'dutt_settlement_due_net', self::gross_net_vat_breakdown( $settlement_due, $vat_rate )['net'] );
		$settlement_due_vat        = self::meta_money_or_fallback( $order, 'dutt_settlement_due_vat', self::gross_net_vat_breakdown( $settlement_due, $vat_rate )['vat'] );
		$customer_receipt_required = 'yes' === (string) $order->get_meta( 'dutt_customer_receipt_required' );
		$merchant_invoice_required = 'yes' === (string) $order->get_meta( 'dutt_merchant_invoice_required' );
		$fiscal_billing_model      = sanitize_key( (string) $order->get_meta( 'dutt_fiscal_billing_model' ) );
		$merchant_invoice_amount   = self::meta_money_or_fallback( $order, 'dutt_merchant_invoice_amount', $settlement_due );
		$merchant_invoice_net      = self::meta_money_or_fallback( $order, 'dutt_merchant_invoice_net', self::gross_net_vat_breakdown( $merchant_invoice_amount, $vat_rate )['net'] );
		$merchant_invoice_vat      = self::meta_money_or_fallback( $order, 'dutt_merchant_invoice_vat', self::gross_net_vat_breakdown( $merchant_invoice_amount, $vat_rate )['vat'] );
		$fiscal_breakdown          = array(
			'provider_ready'        => 'yes' === (string) $order->get_meta( 'dutt_fiscal_provider_ready' ),
			'billing_model'         => $fiscal_billing_model,
			'vat_rate'              => $vat_rate,
			'quote'                 => array(
				'gross' => $quote_price,
				'net'   => $quote_price_net,
				'vat'   => $quote_price_vat,
			),
			'customer_charge'       => array(
				'gross'         => $customer_charge,
				'net'           => $customer_charge_net,
				'vat'           => $customer_charge_vat,
				'required'      => $customer_receipt_required,
				'document_kind' => (string) $order->get_meta( 'dutt_customer_receipt_document_kind' ),
			),
			'merchant_contribution' => array(
				'gross'         => $store_contribution,
				'net'           => $store_contribution_net,
				'vat'           => $store_contribution_vat,
				'required'      => $merchant_invoice_required,
				'document_kind' => (string) $order->get_meta( 'dutt_merchant_invoice_document_kind' ),
			),
			'merchant_invoice'      => array(
				'gross'         => $merchant_invoice_amount,
				'net'           => $merchant_invoice_net,
				'vat'           => $merchant_invoice_vat,
				'required'      => $merchant_invoice_required,
				'document_kind' => (string) $order->get_meta( 'dutt_merchant_invoice_document_kind' ),
			),
			'settlement_due'        => array(
				'gross' => $settlement_due,
				'net'   => $settlement_due_net,
				'vat'   => $settlement_due_vat,
			),
		);

		return array_merge(
			array(
				'store'            => array(
					'name'                => trim( (string) $settings['store_name'] ),
					'city'                => trim( (string) $settings['store_city'] ),
					'address'             => trim( (string) $settings['store_address'] ),
					'country'             => 'Greece',
					'service_radius_km'   => self::number_or_null( $settings['service_radius_km'] ),
					'preparation_minutes' => self::number_or_null( $settings['preparation_minutes'] ),
					'site_url'            => home_url(),
					'billing'             => DUTT_SHD_Settings::merchant_billing_profile( $settings ),
				),
				'merchant_billing' => DUTT_SHD_Settings::merchant_billing_profile( $settings ),
				'pickup'           => array(
					'name'    => trim( (string) $settings['store_name'] ),
					'city'    => trim( (string) $settings['store_city'] ),
					'address' => trim( (string) $settings['store_address'] ),
					'country' => 'Greece',
				),
				'delivery'         => array(
					'name'      => $shipping_name ?: $billing_name,
					'email'     => $billing_email,
					'phone'     => $shipping_phone ?: $order->get_billing_phone(),
					'address'   => trim( $delivery_address_1 . ' ' . $delivery_address_2 ),
					'address_1' => $delivery_address_1,
					'address_2' => $delivery_address_2,
					'city'      => $delivery_city,
					'postcode'  => $delivery_postcode,
					'country'   => $delivery_country ?: 'GR',
					'notes'     => $order->get_customer_note(),
				),
				'package'          => $metrics,
				'constraints'      => array(
					'service_radius_km'   => self::number_or_null( $settings['service_radius_km'] ),
					'preparation_minutes' => self::number_or_null( $settings['preparation_minutes'] ),
				),
				'order'            => array(
					'id'                   => (string) $order->get_id(),
					'number'               => (string) $order->get_order_number(),
					'pickup_reference'     => self::pickup_reference( $order ),
					'status'               => $order->get_status(),
					'currency'             => $order->get_currency(),
					'total'                => $order->get_total(),
					'shipping_total'       => $woocommerce_fiscal['shipping_total_net'],
					'shipping_tax'         => $woocommerce_fiscal['shipping_tax'],
					'shipping_total_gross' => $woocommerce_fiscal['shipping_total_gross'],
					'payment_method'       => $order->get_payment_method(),
					'payment_method_title' => $order->get_payment_method_title(),
					'customer_name'        => $shipping_name ?: $billing_name,
					'customer_email'       => $billing_email,
					'customer_phone'       => $shipping_phone ?: $order->get_billing_phone(),
					'customer_note'        => $order->get_customer_note(),
					'items'                => $metrics['items'],
				),
				'quote'            => array(
					'quote_id'                       => (string) $order->get_meta( 'dutt_quote_id' ),
					'quote_created_at'               => self::meta_number_or_null( $order, 'dutt_quote_created_at' ),
					'quote_expires_at'               => self::meta_number_or_null( $order, 'dutt_quote_expires_at' ),
					'quote_valid_seconds'            => self::meta_number_or_null( $order, 'dutt_quote_valid_seconds' ),
					'distance_km'                    => (string) $order->get_meta( 'dutt_distance_km' ),
					'pricing_version'                => (string) $order->get_meta( 'dutt_pricing_version' ),
					'estimated_time'                 => (string) $order->get_meta( 'dutt_estimated_time' ),
					'price'                          => $quote_price,
					'price_with_vat'                 => $quote_price,
					'price_net'                      => $quote_price_net,
					'vat_rate'                       => $vat_rate,
					'vat_amount'                     => $quote_price_vat,
					'customer_charge'                => $customer_charge,
					'customer_charge_net'            => $customer_charge_net,
					'customer_charge_vat'            => $customer_charge_vat,
					'store_contribution'             => $store_contribution,
					'store_contribution_net'         => $store_contribution_net,
					'store_contribution_vat'         => $store_contribution_vat,
					'settlement_due'                 => $settlement_due,
					'settlement_due_net'             => $settlement_due_net,
					'settlement_due_vat'             => $settlement_due_vat,
					'customer_receipt_required'      => $customer_receipt_required,
					'customer_receipt_document_kind' => (string) $order->get_meta( 'dutt_customer_receipt_document_kind' ),
					'merchant_invoice_required'      => $merchant_invoice_required,
					'merchant_invoice_document_kind' => (string) $order->get_meta( 'dutt_merchant_invoice_document_kind' ),
					'fiscal_billing_model'           => $fiscal_billing_model,
					'merchant_invoice_amount'        => $merchant_invoice_amount,
					'merchant_invoice_net'           => $merchant_invoice_net,
					'merchant_invoice_vat'           => $merchant_invoice_vat,
					'charge_policy'                  => (string) $order->get_meta( 'dutt_charge_policy' ),
					'cart_subtotal'                  => (string) $order->get_meta( 'dutt_cart_subtotal' ),
				),
				'charge'           => array(
					'quote_price'                    => $quote_price,
					'quote_price_net'                => $quote_price_net,
					'quote_price_vat'                => $quote_price_vat,
					'customer_charge'                => $customer_charge,
					'customer_charge_net'            => $customer_charge_net,
					'customer_charge_vat'            => $customer_charge_vat,
					'store_contribution'             => $store_contribution,
					'store_contribution_net'         => $store_contribution_net,
					'store_contribution_vat'         => $store_contribution_vat,
					'settlement_due'                 => $settlement_due,
					'settlement_due_net'             => $settlement_due_net,
					'settlement_due_vat'             => $settlement_due_vat,
					'vat_rate'                       => $vat_rate,
					'customer_receipt_required'      => $customer_receipt_required,
					'customer_receipt_document_kind' => (string) $order->get_meta( 'dutt_customer_receipt_document_kind' ),
					'merchant_invoice_required'      => $merchant_invoice_required,
					'merchant_invoice_document_kind' => (string) $order->get_meta( 'dutt_merchant_invoice_document_kind' ),
					'fiscal_billing_model'           => $fiscal_billing_model,
					'merchant_invoice_amount'        => $merchant_invoice_amount,
					'merchant_invoice_net'           => $merchant_invoice_net,
					'merchant_invoice_vat'           => $merchant_invoice_vat,
					'policy'                         => (string) $order->get_meta( 'dutt_charge_policy' ),
				),
				'fiscal'           => $fiscal_breakdown,
				'commerce_fiscal'  => $woocommerce_fiscal,
				'currency'         => $order->get_currency(),
				'source'           => 'woocommerce',
				'site_url'         => home_url(),
				'webhook'          => self::status_webhook_payload(),
			),
			DUTT_SHD_Settings::merchant_integration_policy_payload(
				$settings,
				$delivery_country ?: 'GR'
			)
		);
	}

	private static function gross_net_vat_breakdown( float $gross, ?float $vat_rate ): array {
		$gross = round( max( 0.0, $gross ), 2 );
		$rate  = is_numeric( $vat_rate ) ? max( 0.0, (float) $vat_rate ) : 0.0;
		$net   = $rate > 0.0 ? round( $gross / ( 1 + $rate ), 2 ) : $gross;
		$vat   = round( max( 0.0, $gross - $net ), 2 );

		return array(
			'gross' => $gross,
			'net'   => $net,
			'vat'   => $vat,
		);
	}

	private static function normalize_vat_rate( $value, $gross = null, $net = null ): ?float {
		if ( is_numeric( $value ) ) {
			$rate = (float) $value;
			if ( $rate > 1.0 ) {
				$rate = $rate / 100;
			}
			return round( max( 0.0, $rate ), 4 );
		}

		if ( is_numeric( $gross ) && is_numeric( $net ) ) {
			$gross = (float) $gross;
			$net   = (float) $net;
			if ( $gross > 0.0 && $net > 0.0 && $gross >= $net ) {
				return round( max( 0.0, ( $gross - $net ) / $net ), 4 );
			}
		}

		return null;
	}

	private static function status_webhook_payload(): array {
		if ( ! class_exists( 'DUTT_SHD_Status_Sync' ) ) {
			return array();
		}

		return array(
			'url'    => DUTT_SHD_Status_Sync::callback_url(),
			'secret' => DUTT_SHD_Status_Sync::ensure_webhook_secret(),
			'events' => array( 'delivery.status_updated' ),
		);
	}

	private static function order_package_metrics( WC_Order $order ): array {
		$total_weight = 0.0;
		$max_length   = 0.0;
		$max_width    = 0.0;
		$max_height   = 0.0;
		$items        = array();

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$product = $item->get_product();
			$qty     = max( 1, (int) $item->get_quantity() );
			$weight  = $product ? (float) $product->get_weight() : 0.0;
			$length  = $product ? (float) $product->get_length() : 0.0;
			$width   = $product ? (float) $product->get_width() : 0.0;
			$height  = $product ? (float) $product->get_height() : 0.0;

			$total_weight += $weight * $qty;
			$max_length    = max( $max_length, $length );
			$max_width     = max( $max_width, $width );
			$max_height    = max( $max_height, $height );

			$items[] = array(
				'product_id' => $product ? (string) $product->get_id() : '',
				'name'       => $item->get_name(),
				'sku'        => $product ? $product->get_sku() : '',
				'quantity'   => $qty,
				'weight_kg'  => $weight,
				'length_cm'  => $length,
				'width_cm'   => $width,
				'height_cm'  => $height,
			);
		}

		return array(
			'weight_kg' => round( $total_weight, 3 ),
			'length_cm' => round( $max_length, 2 ),
			'width_cm'  => round( $max_width, 2 ),
			'height_cm' => round( $max_height, 2 ),
			'items'     => $items,
		);
	}

	private static function pickup_reference( WC_Order $order ): string {
		$raw = trim( (string) $order->get_order_number() );
		if ( '' === $raw ) {
			$raw = (string) $order->get_id();
		}
		$raw = preg_replace( '/^#\s*/', '', $raw );
		if ( preg_match( '/^WC[-_\s]/i', $raw ) ) {
			return $raw;
		}
		return 'WC-' . $raw;
	}

	public static function is_cash_on_delivery_method( string $payment_method ): bool {
		return 'cod' === sanitize_key( $payment_method );
	}

	private static function return_pickup_reference( WC_Order $order ): string {
		$base = self::pickup_reference( $order );
		return str_starts_with( strtoupper( $base ), 'RETURN-' ) ? $base : 'RETURN-' . $base;
	}

	private static function return_external_order_id( WC_Order $order ): string {
		return 'return_wc_' . $order->get_id();
	}

	private static function order_delivery_id( WC_Order $order ): string {
		$delivery_id = (string) $order->get_meta( 'dutt_delivery_id' );
		if ( '' === $delivery_id ) {
			$delivery_id = (string) $order->get_meta( 'mock_dutt_delivery_id' );
		}

		return trim( $delivery_id );
	}

	private static function order_customer_name( WC_Order $order ): string {
		$shipping_name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
		$billing_name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		return $shipping_name ?: $billing_name;
	}

	private static function order_customer_phone( WC_Order $order ): string {
		$shipping_phone = method_exists( $order, 'get_shipping_phone' ) ? (string) $order->get_shipping_phone() : '';
		return trim( $shipping_phone ?: (string) $order->get_billing_phone() );
	}

	private static function order_customer_address( WC_Order $order ): string {
		$address_1 = $order->get_shipping_address_1() ?: $order->get_billing_address_1();
		$address_2 = $order->get_shipping_address_2() ?: $order->get_billing_address_2();
		return trim( $address_1 . ' ' . $address_2 );
	}

	private static function order_customer_city( WC_Order $order ): string {
		return trim( (string) ( $order->get_shipping_city() ?: $order->get_billing_city() ) );
	}

	private static function order_customer_postcode( WC_Order $order ): string {
		return trim( (string) ( $order->get_shipping_postcode() ?: $order->get_billing_postcode() ) );
	}

	private static function return_value( array $data, string $key, string $fallback = '' ): string {
		$value = array_key_exists( $key, $data ) ? (string) $data[ $key ] : $fallback;
		$value = trim( $value );
		return '' !== $value ? $value : trim( $fallback );
	}

	private static function dutt_shipping_total( WC_Order $order ): float {
		$totals = DUTT_SHD_WooCommerce_Fiscal::order_shipping_totals( $order );
		return $totals['gross'];
	}

	private static function meta_money_or_fallback( WC_Order $order, string $key, float $fallback ): string {
		$value = $order->get_meta( $key );
		if ( '' !== (string) $value && is_numeric( $value ) ) {
			return wc_format_decimal( (float) $value, 2 );
		}

		return wc_format_decimal( $fallback, 2 );
	}

	private static function add_optional_money( array &$target, string $payload_key, WC_Order $order, string $meta_key ): void {
		$value = $order->get_meta( $meta_key );
		if ( '' !== (string) $value && is_numeric( $value ) ) {
			$target[ $payload_key ] = wc_format_decimal( (float) $value, 2 );
		}
	}

	private static function add_optional_bool( array &$target, string $payload_key, WC_Order $order, string $meta_key ): void {
		$value = strtolower( trim( (string) $order->get_meta( $meta_key ) ) );
		if ( 'yes' === $value || 'true' === $value || '1' === $value ) {
			$target[ $payload_key ] = true;
		} elseif ( 'no' === $value || 'false' === $value || '0' === $value ) {
			$target[ $payload_key ] = false;
		}
	}

	private static function meta_number_or_null( WC_Order $order, string $key ): ?float {
		$value = $order->get_meta( $key );
		if ( '' === (string) $value || ! is_numeric( $value ) ) {
			return null;
		}

		return (float) $value;
	}

	private static function quote_charge_from_backend( array $data ): array {
		$required = array(
			'quote_price',
			'quote_price_net',
			'quote_price_vat',
			'customer_charge',
			'customer_charge_net',
			'customer_charge_vat',
			'store_contribution',
			'store_contribution_net',
			'store_contribution_vat',
			'settlement_due',
			'settlement_due_net',
			'settlement_due_vat',
			'merchant_due_to_dutt',
			'merchant_due_to_dutt_net',
			'merchant_due_to_dutt_vat',
			'merchant_invoice_amount',
			'merchant_invoice_net',
			'merchant_invoice_vat',
			'cart_subtotal',
			'charge_policy',
		);
		$missing  = array();
		$invalid  = array();
		foreach ( $required as $key ) {
			if ( ! array_key_exists( $key, $data ) || '' === (string) $data[ $key ] ) {
				$missing[] = $key;
			} elseif ( 'charge_policy' !== $key ) {
				$value = self::money_cents_or_null( $data[ $key ] );
				if ( null === $value || $value < 0 ) {
					$invalid[] = $key;
				}
			} elseif ( '' === sanitize_key( (string) $data[ $key ] ) ) {
				$invalid[] = $key;
			}
		}

		if ( empty( $missing ) && empty( $invalid ) ) {
			$quote_price        = self::money_cents_or_null( $data['quote_price'] );
			$customer_charge    = self::money_cents_or_null( $data['customer_charge'] );
			$store_contribution = self::money_cents_or_null( $data['store_contribution'] );
			$settlement_due     = self::money_cents_or_null( $data['settlement_due'] );
			$merchant_due       = self::money_cents_or_null( $data['merchant_due_to_dutt'] );
			$invoice_amount     = self::money_cents_or_null( $data['merchant_invoice_amount'] );
			if (
				null === $quote_price ||
				null === $customer_charge ||
				null === $store_contribution ||
				null === $settlement_due ||
				null === $merchant_due ||
				null === $invoice_amount ||
				$customer_charge + $store_contribution !== $quote_price ||
				$settlement_due !== $quote_price ||
				$merchant_due !== $settlement_due ||
				$invoice_amount !== $settlement_due
			) {
				$invalid[] = 'charge_total';
			}
			if (
				self::money_cents_or_null( $data['customer_charge_net'] ) + self::money_cents_or_null( $data['store_contribution_net'] ) !== self::money_cents_or_null( $data['quote_price_net'] ) ||
				self::money_cents_or_null( $data['customer_charge_vat'] ) + self::money_cents_or_null( $data['store_contribution_vat'] ) !== self::money_cents_or_null( $data['quote_price_vat'] )
			) {
				$invalid[] = 'charge_breakdown_total';
			}

			$breakdowns = array(
				'quote_price'             => array( 'quote_price', 'quote_price_net', 'quote_price_vat' ),
				'customer_charge'         => array( 'customer_charge', 'customer_charge_net', 'customer_charge_vat' ),
				'store_contribution'      => array( 'store_contribution', 'store_contribution_net', 'store_contribution_vat' ),
				'settlement_due'          => array( 'settlement_due', 'settlement_due_net', 'settlement_due_vat' ),
				'merchant_due_to_dutt'    => array( 'merchant_due_to_dutt', 'merchant_due_to_dutt_net', 'merchant_due_to_dutt_vat' ),
				'merchant_invoice_amount' => array( 'merchant_invoice_amount', 'merchant_invoice_net', 'merchant_invoice_vat' ),
			);
			foreach ( $breakdowns as $prefix => $keys ) {
				$gross = self::money_cents_or_null( $data[ $keys[0] ] );
				$net   = self::money_cents_or_null( $data[ $keys[1] ] );
				$vat   = self::money_cents_or_null( $data[ $keys[2] ] );
				if ( null === $gross || null === $net || null === $vat || $net + $vat !== $gross ) {
					$invalid[] = $prefix . '_breakdown';
				}
			}

			if ( 'merchant_b2b_v1' !== sanitize_key( (string) ( $data['fiscal_billing_model'] ?? '' ) ) ) {
				$invalid[] = 'fiscal_billing_model';
			}
			if ( ! array_key_exists( 'customer_receipt_required', $data ) || false !== $data['customer_receipt_required'] ) {
				$invalid[] = 'customer_receipt_required';
			}
			if ( ! array_key_exists( 'merchant_invoice_required', $data ) || true !== $data['merchant_invoice_required'] ) {
				$invalid[] = 'merchant_invoice_required';
			}
			if ( ! array_key_exists( 'fiscal_provider_ready', $data ) || true !== $data['fiscal_provider_ready'] ) {
				$invalid[] = 'fiscal_provider_ready';
			}
			if ( '' !== trim( (string) ( $data['customer_receipt_document_kind'] ?? '' ) ) ) {
				$invalid[] = 'customer_receipt_document_kind';
			}
			if ( 'service_invoice' !== sanitize_key( (string) ( $data['merchant_invoice_document_kind'] ?? '' ) ) ) {
				$invalid[] = 'merchant_invoice_document_kind';
			}
		}

		if ( ! empty( $missing ) || ! empty( $invalid ) ) {
			return array(
				'ok'             => false,
				'missing_fields' => $missing,
				'invalid_fields' => $invalid,
			);
		}

		return array(
			'ok'                             => true,
			'quote_price'                    => self::number_or_null( $data['quote_price'] ) ?? 0.0,
			'quote_price_net'                => self::number_or_null( $data['quote_price_net'] ?? null ) ?? 0.0,
			'quote_price_vat'                => self::number_or_null( $data['quote_price_vat'] ?? null ) ?? 0.0,
			'customer_charge'                => self::number_or_null( $data['customer_charge'] ) ?? 0.0,
			'customer_charge_net'            => self::number_or_null( $data['customer_charge_net'] ?? null ) ?? 0.0,
			'customer_charge_vat'            => self::number_or_null( $data['customer_charge_vat'] ?? null ) ?? 0.0,
			'store_contribution'             => self::number_or_null( $data['store_contribution'] ) ?? 0.0,
			'store_contribution_net'         => self::number_or_null( $data['store_contribution_net'] ?? null ) ?? 0.0,
			'store_contribution_vat'         => self::number_or_null( $data['store_contribution_vat'] ?? null ) ?? 0.0,
			'settlement_due'                 => self::number_or_null( $data['settlement_due'] ) ?? 0.0,
			'settlement_due_net'             => self::number_or_null( $data['settlement_due_net'] ?? null ) ?? 0.0,
			'settlement_due_vat'             => self::number_or_null( $data['settlement_due_vat'] ?? null ) ?? 0.0,
			'merchant_due_to_dutt'           => self::number_or_null( $data['merchant_due_to_dutt'] ?? $data['settlement_due'] ?? null ) ?? 0.0,
			'merchant_due_to_dutt_net'       => self::number_or_null( $data['merchant_due_to_dutt_net'] ?? $data['settlement_due_net'] ?? null ) ?? 0.0,
			'merchant_due_to_dutt_vat'       => self::number_or_null( $data['merchant_due_to_dutt_vat'] ?? $data['settlement_due_vat'] ?? null ) ?? 0.0,
			'fiscal_billing_model'           => sanitize_key( (string) ( $data['fiscal_billing_model'] ?? '' ) ),
			'charge_policy'                  => sanitize_key( (string) $data['charge_policy'] ),
			'cart_subtotal'                  => self::number_or_null( $data['cart_subtotal'] ?? null ) ?? 0.0,
			'customer_receipt_required'      => true === $data['customer_receipt_required'],
			'customer_receipt_document_kind' => sanitize_text_field( (string) ( $data['customer_receipt_document_kind'] ?? '' ) ),
			'merchant_invoice_required'      => true === $data['merchant_invoice_required'],
			'merchant_invoice_document_kind' => sanitize_text_field( (string) ( $data['merchant_invoice_document_kind'] ?? '' ) ),
			'merchant_invoice_amount'        => self::number_or_null( $data['merchant_invoice_amount'] ?? null ) ?? 0.0,
			'merchant_invoice_net'           => self::number_or_null( $data['merchant_invoice_net'] ?? null ) ?? 0.0,
			'merchant_invoice_vat'           => self::number_or_null( $data['merchant_invoice_vat'] ?? null ) ?? 0.0,
			'fiscal_provider_ready'          => true === $data['fiscal_provider_ready'],
		);
	}

	public static function valid_quote_contract( array $data ): bool {
		$quote_created_at    = self::number_or_null( $data['quote_created_at'] ?? null );
		$quote_expires_at    = self::number_or_null( $data['quote_expires_at'] ?? null );
		$quote_valid_seconds = self::number_or_null( $data['quote_valid_seconds'] ?? null );
		if (
			true !== ( $data['success'] ?? null ) ||
			'' === trim( (string) ( $data['quote_id'] ?? '' ) ) ||
			'EUR' !== strtoupper( trim( (string) ( $data['currency'] ?? '' ) ) ) ||
			null === $quote_created_at ||
			null === $quote_expires_at ||
			null === $quote_valid_seconds ||
			$quote_created_at <= 0 ||
			$quote_expires_at <= $quote_created_at ||
			$quote_valid_seconds <= 0
		) {
			return false;
		}

		$charge = self::quote_charge_from_backend( $data );
		return ! empty( $charge['ok'] );
	}

	public static function valid_https_endpoint( string $endpoint ): bool {
		$endpoint = trim( $endpoint );
		if ( '' === $endpoint || preg_match( '/[\r\n]/', $endpoint ) ) {
			return false;
		}

		$parts = wp_parse_url( $endpoint );
		return is_array( $parts )
			&& 'https' === strtolower( (string) ( $parts['scheme'] ?? '' ) )
			&& '' !== trim( (string) ( $parts['host'] ?? '' ) )
			&& empty( $parts['user'] )
			&& empty( $parts['pass'] )
			&& empty( $parts['fragment'] );
	}

	private static function resolve_woocommerce_shipping_cost( ?float $gross, ?float $net ): float {
		if ( wc_tax_enabled() && ! wc_prices_include_tax() && null !== $net ) {
			return round( $net, 2 );
		}

		if ( null !== $gross ) {
			return round( $gross, 2 );
		}

		return round( (float) $net, 2 );
	}

	private static function calculate_demo_distance_price( float $distance_km ): float {
		$table = array(
			1  => 3.97,
			2  => 4.47,
			3  => 5.07,
			4  => 5.67,
			5  => 6.27,
			6  => 6.97,
			7  => 7.77,
			8  => 8.67,
			9  => 9.67,
			10 => 10.87,
			11 => 11.87,
			12 => 12.97,
		);

		$d     = max( 0.1, $distance_km );
		$lower = (int) floor( $d );
		$upper = (int) ceil( $d );

		if ( isset( $table[ $lower ], $table[ $upper ] ) && $lower !== $upper ) {
			$ratio = $d - $lower;
			return round( $table[ $lower ] + ( ( $table[ $upper ] - $table[ $lower ] ) * $ratio ), 2 );
		}

		if ( isset( $table[ $upper ] ) ) {
			return round( $table[ $upper ], 2 );
		}

		return round( 12.97 + ( ( $d - 12 ) * 1.1 ), 2 );
	}

	private static function mock_distance_km( string $address, string $city, float $radius ): float {
		$text = mb_strtolower( $address . ' ' . $city );
		if ( str_contains( $text, 'outside' ) || str_contains( $text, 'far' ) ) {
			return round( $radius + 2.5, 1 );
		}

		$hash = abs( crc32( $address . '|' . $city ) );
		$max  = max( 1.0, min( $radius, 5.5 ) );
		return round( 0.7 + ( ( $hash % 100 ) / 100 ) * ( $max - 0.7 ), 1 );
	}

	private static function number_or_null( $value ): ?float {
		if ( null === $value || '' === $value || ! is_numeric( $value ) ) {
			return null;
		}

		$number = (float) $value;
		return is_finite( $number ) ? $number : null;
	}

	private static function money_cents_or_null( $value ): ?int {
		$number = self::number_or_null( $value );
		if ( null === $number ) {
			return null;
		}

		$scaled  = $number * 100;
		$rounded = round( $scaled );
		if ( abs( $scaled - $rounded ) > 0.000001 ) {
			return null;
		}

		return (int) $rounded;
	}

	private static function endpoint_host( string $endpoint ): string {
		$host = wp_parse_url( $endpoint, PHP_URL_HOST );
		return is_string( $host ) ? $host : '';
	}

	private static function fail( string $reason, array $extra = array() ): array {
		if ( class_exists( 'DUTT_SHD_Logger' ) ) {
			DUTT_SHD_Logger::warning(
				'api_failure',
				array_merge(
					array( 'reason' => $reason ),
					$extra
				)
			);
		}

		return array_merge(
			array(
				'success' => false,
				'reason'  => $reason,
			),
			$extra
		);
	}
}

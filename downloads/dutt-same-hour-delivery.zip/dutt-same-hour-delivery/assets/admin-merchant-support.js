(function () {
  'use strict';

  var config = window.duttMerchantSupport || {};
  var conversation = document.querySelector('[data-dutt-thread]');
  var messages = document.querySelector('[data-dutt-messages]');
  var composer = document.querySelector('[data-dutt-composer]');
  var newPanel = document.querySelector('[data-dutt-new-panel]');
  var sendStatus = composer ? composer.querySelector('[data-dutt-send-status]') : null;
  var seen = new Set();
  var timer = null;
  var statusTimer = null;

  function uuid() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    return Date.now().toString(36) + Math.random().toString(36).slice(2);
  }

  function post(action, data) {
    var body = new URLSearchParams(Object.assign({ action: action, nonce: config.nonce }, data || {}));
    return fetch(config.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    }).then(function (response) {
      return response.json().then(function (payload) {
        if (!response.ok || !payload.success) {
          throw new Error((payload.data && payload.data.reason) || 'support_request_failed');
        }
        return payload.data;
      });
    });
  }

  function messageNode(message) {
    var article = document.createElement('article');
    var sender = message.sender_type === 'merchant' ? 'You' : 'Dutt Support';
    article.className = 'dutt-support-message ' + (message.sender_type === 'merchant' ? 'is-merchant' : 'is-support');
    article.dataset.messageId = message.message_id || '';
    article.dataset.createdAt = String(message.created_at || 0);

    var label = document.createElement('div');
    label.className = 'dutt-support-message-label';
    label.textContent = sender;
    var bubble = document.createElement('div');
    bubble.className = 'dutt-support-bubble';
    bubble.textContent = message.text || '';
    article.appendChild(label);
    article.appendChild(bubble);
    return article;
  }

  function appendMessages(items) {
    if (!messages || !Array.isArray(items)) return;
    var added = false;
    items.forEach(function (item) {
      if (!item.message_id || seen.has(item.message_id)) return;
      seen.add(item.message_id);
      messages.appendChild(messageNode(item));
      added = true;
    });
    if (added) messages.scrollTop = messages.scrollHeight;
  }

  function latestTimestamp() {
    var latest = 0;
    if (!messages) return latest;
    messages.querySelectorAll('[data-created-at]').forEach(function (node) {
      latest = Math.max(latest, Number(node.dataset.createdAt || 0));
    });
    return latest;
  }

  function setSendStatus(text, isError) {
    if (!sendStatus) return;
    window.clearTimeout(statusTimer);
    sendStatus.textContent = text || '';
    sendStatus.classList.toggle('is-error', Boolean(isError));
    if (text && !isError) {
      statusTimer = window.setTimeout(function () {
        sendStatus.textContent = '';
      }, 2500);
    }
  }

  function confirmSentMessage(value, after) {
    return post('dutt_shd_support_poll', {
      thread_id: conversation.dataset.duttThread,
      after: Math.max(0, after - 1)
    }).then(function (data) {
      var items = Array.isArray(data.messages) ? data.messages : [];
      appendMessages(items);
      return items.some(function (item) {
        return item.sender_type === 'merchant' && item.text === value;
      });
    });
  }

  function schedulePoll() {
    window.clearTimeout(timer);
    timer = window.setTimeout(poll, document.hidden ? Number(config.idleMs || 30000) : Number(config.pollMs || 5000));
  }

  function poll() {
    if (!conversation) return;
    post('dutt_shd_support_poll', {
      thread_id: conversation.dataset.duttThread,
      after: latestTimestamp()
    }).then(function (data) {
      appendMessages(data.messages || []);
    }).catch(function () {
      // The next scheduled poll retries without interrupting the merchant.
    }).finally(schedulePoll);
  }

  document.querySelectorAll('[data-message-id]').forEach(function (node) {
    if (node.dataset.messageId) seen.add(node.dataset.messageId);
  });

  document.querySelectorAll('[data-dutt-new-thread]').forEach(function (button) {
    button.addEventListener('click', function () {
      if (newPanel) newPanel.style.display = '';
    });
  });
  document.querySelectorAll('[data-dutt-close-new]').forEach(function (button) {
    button.addEventListener('click', function () {
      if (newPanel) newPanel.style.display = 'none';
    });
  });

  document.querySelectorAll('[data-dutt-support-topic]').forEach(function (select) {
    select.addEventListener('change', function () {
      var targetId = select.dataset.target || '';
      var textarea = targetId ? document.getElementById(targetId) : null;
      if (!textarea || !select.value) return;

      textarea.value = select.value;
      var form = select.closest('form');
      var category = form ? form.querySelector('select[name="category"]') : null;
      var option = select.options[select.selectedIndex];
      if (category && option && option.dataset.category) {
        category.value = option.dataset.category;
      }
      textarea.focus();
    });
  });

  if (composer && conversation) {
    composer.addEventListener('submit', function (event) {
      event.preventDefault();
      var textarea = composer.querySelector('textarea[name="message"]');
      var topicSelect = composer.querySelector('[data-dutt-support-topic]');
      var button = composer.querySelector('button[type="submit"]');
      var value = textarea ? textarea.value.trim() : '';
      if (!value) return;
      var beforeSend = latestTimestamp();
      if (button) button.disabled = true;
      setSendStatus('', false);
      post('dutt_shd_support_send', {
        thread_id: conversation.dataset.duttThread,
        client_message_id: uuid(),
        message: value
      }).then(function (data) {
        appendMessages(data.message ? [data.message] : []);
        if (textarea) textarea.value = '';
        if (topicSelect) topicSelect.value = '';
        setSendStatus('Message sent.', false);
      }, function () {
        return confirmSentMessage(value, beforeSend).then(function (wasSent) {
          if (wasSent) {
            if (textarea) textarea.value = '';
            if (topicSelect) topicSelect.value = '';
            setSendStatus('Message sent.', false);
            return;
          }
          setSendStatus('The message could not be sent. Please try again.', true);
        }, function () {
          setSendStatus('The message could not be confirmed. Please try again.', true);
        });
      }).finally(function () {
        if (button) button.disabled = false;
        if (textarea) textarea.focus();
      });
    });
  }

  document.addEventListener('visibilitychange', schedulePoll);
  if (messages) messages.scrollTop = messages.scrollHeight;
  schedulePoll();
}());

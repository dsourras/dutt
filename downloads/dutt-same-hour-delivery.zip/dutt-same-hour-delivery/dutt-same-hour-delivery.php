<?php
/**
 * Plugin Name: DUTT Same Hour Delivery
 * Plugin URI: https://dutt.gr/
 * Description: WooCommerce same-hour delivery method that requests DUTT distance-based quotes.
 * Version: 1.2.2
 * Author: Dutt
 * Author URI: https://dutt.gr/
 * Developer: Dutt
 * Developer URI: https://dutt.gr/
 * Requires at least: 6.9
 * Tested up to: 7.0
 * Requires PHP: 8.0
 * Requires Plugins: woocommerce
 * WC requires at least: 8.8
 * WC tested up to: 10.9
 * Text Domain: dutt-same-hour-delivery
 * Domain Path: /languages
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI: https://dutt.gr/plugin-updates/dutt-same-hour-delivery
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DUTT_SHD_VERSION', '1.2.2' );
define( 'DUTT_SHD_PLUGIN_FILE', __FILE__ );
define( 'DUTT_SHD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-updater.php';
DUTT_SHD_Updater::init();

add_action(
	'before_woocommerce_init',
	function () {
		if ( ! class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			return;
		}

		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
);

register_activation_hook(
	__FILE__,
	function () {
		update_option( 'dutt_shd_needs_zone_install', 'yes' );
		DUTT_SHD_Updater::enable_auto_updates_by_default();
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>'
						. esc_html__( 'DUTT Same Hour Delivery requires WooCommerce to be active.', 'dutt-same-hour-delivery' )
						. '</p></div>';
				}
			);
			return;
		}

		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-logger.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-business-billing-notice.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-merchant-policy.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-settings.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-webhook-security.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-status-sync.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-woocommerce-fiscal.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-api-client.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-mock-api.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-tracking.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-eligibility-service.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-onboarding.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-merchant-overview.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-merchant-support-topics.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-merchant-support.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-admin-logs.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-refunds.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-category-eligibility.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-product-eligibility.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-scanner-admin.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-shipping-method.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-checkout.php';
		require_once DUTT_SHD_PLUGIN_DIR . 'includes/class-dutt-shd-order-meta.php';

		DUTT_SHD_Settings::init();
		DUTT_SHD_Status_Sync::init();
		DUTT_SHD_Tracking::init();
		DUTT_SHD_Onboarding::init();
		DUTT_SHD_Merchant_Overview::init();
		DUTT_SHD_Merchant_Support::init();
		DUTT_SHD_Admin_Logs::init();
		DUTT_SHD_Refunds::init();
		DUTT_SHD_Category_Eligibility::init();
		DUTT_SHD_Product_Eligibility::init();
		DUTT_SHD_Scanner_Admin::init();
		DUTT_SHD_Checkout::init();
		DUTT_SHD_Order_Meta::init();
	},
	20
);

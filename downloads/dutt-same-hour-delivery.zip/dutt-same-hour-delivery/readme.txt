=== DUTT Same Hour Delivery ===
Contributors: dutt
Tags: woocommerce, shipping, local delivery, same hour delivery, courier
Requires at least: 6.9
Tested up to: 7.0
Requires PHP: 8.0
Requires Plugins: woocommerce
Stable tag: 1.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add Dutt same-hour delivery to WooCommerce with live distance-based quotes, merchant controls, tracking, and status sync.

== Description ==

DUTT Same Hour Delivery adds a WooCommerce shipping method for local same-hour delivery.

The method appears at checkout only when the store setup, customer address, product eligibility, package limits, service hours, and live Dutt quote allow the delivery. Pricing, availability, cancellation rules, delivery lifecycle, and merchant accounting are decided by the common Dutt backend. The plugin is the WooCommerce adapter for that service.

Key features:

* Live, distance-based Dutt quotes.
* Customer-paid, store-paid, threshold-based, and split delivery-charge policies.
* Merchant-controlled eligible product categories and product-level overrides.
* Weight and dimension checks when product data is available.
* Store setup with a normal address; latitude and longitude are not required.
* Ready for Dutt pickup action after the merchant prepares the order.
* Delivery creation, cancellation, retry, return, tracking, and status sync.
* Merchant overview with shipment and settlement data plus CSV export.
* Explicit WooCommerce fiscal ownership for customer-facing shipping charges and B2B settlement data for Dutt merchant invoicing.
* Required merchant agreement and privacy/DPA acceptance for EUR deliveries within Greece.
* Signed callbacks with timestamp validation, replay protection, event deduplication, and terminal-status guards.
* WooCommerce Cart and Checkout Blocks compatibility.
* WooCommerce High-Performance Order Storage compatibility.
* Native WordPress update notifications with verified DUTT release packages.
* Automatic plugin updates enabled by default with a persistent merchant opt-out.

== Installation ==

1. Install and activate WooCommerce.
2. Upload the plugin ZIP from Plugins > Add New > Upload Plugin.
3. Activate DUTT Same Hour Delivery.
4. Open WooCommerce > Dutt Delivery.
5. Open WooCommerce > Settings > Shipping > DUTT Same Hour Delivery.
6. Enter the Merchant Key supplied by Dutt, complete the store and invoicing details, and accept the merchant agreement and privacy/DPA.
7. Save the settings and run the connection test.
8. Open WooCommerce > Eligible Categories and approve suitable product categories.
9. Run WooCommerce > Product Eligibility Scanner.
10. Add DUTT Same Hour Delivery to at least one WooCommerce shipping zone.
11. Place a test order before accepting production traffic.

== Order flow ==

1. The customer selects Dutt at checkout.
2. The plugin stores the quote and charge split on the WooCommerce order.
3. The merchant prepares the order; no driver is dispatched yet.
4. The merchant opens the order and selects Ready for Dutt pickup.
5. Dutt creates and dispatches the delivery.
6. Signed callbacks update tracking and delivery status in WooCommerce.

== Frequently Asked Questions ==

= Does the plugin require WooCommerce? =

Yes. WooCommerce must be installed and active.

= Does the merchant enter coordinates? =

No. The merchant enters the pickup city and address. The Dutt API resolves addresses for availability and pricing.

= When is the delivery created? =

The quote is stored at checkout. The delivery is created only when the merchant selects Ready for Dutt pickup on the WooCommerce order.

= Is a Merchant Key required? =

Yes. Each store must use its own Merchant Key supplied by Dutt. Keys must not be shared between stores.

= What terms apply when I connect my store? =

Connecting or using Dutt delivery means that the merchant accepts the Dutt Terms of Use at https://dutt.gr/terms.html. Monthly invoices are payable within 30 calendar days. If an invoice remains wholly unpaid five days after its due date, access to new delivery requests may be suspended until full payment is confirmed. Deliveries already in progress, support, order history, and issued invoices remain accessible.

= Where are diagnostics available? =

Diagnostic logging is disabled by default. Enable it in the Dutt shipping settings when support requests it. Then open WooCommerce > Dutt Logs. Full entries are also available under WooCommerce > Status > Logs with the `dutt-same-hour-delivery` source.

= Does the plugin support Checkout Blocks and HPOS? =

Yes. The plugin declares compatibility with Cart and Checkout Blocks and High-Performance Order Storage, and uses WooCommerce order CRUD APIs.

= What happens on uninstall? =

Plugin settings and product eligibility metadata are removed. Historical Dutt order metadata is preserved so past delivery records remain attached to their WooCommerce orders.

== External service and privacy ==

This plugin connects to the Dutt service at `dutt.gr` and Dutt API endpoints hosted on Google Cloud to provide delivery quotes, availability, delivery creation, cancellation, returns, tracking, merchant settlement information, and status callbacks. The service is required for the plugin to work.

Quote requests may include the store name and address, merchant invoicing details, customer delivery city, address and postcode, package weight and dimensions, currency, cart value, and site URL.

Delivery requests may additionally include recipient name and phone, delivery notes, WooCommerce order ID and number, payment method, order total, item names, SKUs, quantities, quote price, customer delivery charge, store contribution, and charge policy.

Dutt sends signed status callbacks to the store. The plugin stores delivery identifiers, status, tracking information, compact status history, and order notes on the WooCommerce order.

When the merchant explicitly enables diagnostic logging, the plugin keeps a limited recent diagnostics view in WordPress options and writes full diagnostics through the WooCommerce logger. Merchant keys, signatures, tokens, passwords, phone numbers, and email addresses are redacted from the recent diagnostics view. The merchant can disable logging or clear the recent view at any time.

No advertising, profiling, or unrelated tracking data is collected by the plugin. Merchants should disclose the Dutt delivery service in their own privacy policy. Service information and contact details are available at https://dutt.gr/.

== Screenshots ==

1. Dutt onboarding checklist.
2. Merchant shipment and settlement overview.
3. Dutt shipping settings.
4. Eligible product categories.

== Changelog ==

See `changelog.txt`.

import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const here = path.dirname(fileURLToPath(import.meta.url));
const contractPath = path.resolve(here, "../../../openapi/dutt-merchant-api.json");
const contract = JSON.parse(fs.readFileSync(contractPath, "utf8"));

const expectedPaths = [
  "/duttMerchantConnectionTest",
  "/duttMerchantQuote",
  "/duttMerchantCreateOrder",
  "/duttMerchantMarkReady",
  "/duttMerchantCancelDelivery",
  "/duttMerchantGetStatus",
  "/duttMerchantListDeliveries",
  "/duttMerchantListLocations",
  "/duttMerchantUpsertLocation",
  "/duttMerchantRegisterWebhook",
  "/duttMerchantRefundNotice",
];

test("OpenAPI contract is versioned and complete", () => {
  assert.equal(contract.openapi, "3.1.0");
  assert.equal(contract.info.version, "1.1.2");
  assert.deepEqual(Object.keys(contract.paths).sort(), expectedPaths.sort());
});

test("contract requires server-side merchant authentication", () => {
  assert.equal(
    contract.components.securitySchemes.merchantKey.name,
    "X-DUTT-Merchant-Key",
  );
  assert.equal(contract.components.securitySchemes.merchantKey.in, "header");
});

test("contract fixes custom source, EUR, Greece and current policy versions", () => {
  const schemas = contract.components.schemas;
  assert.equal(schemas.MerchantContext.properties.source.const, "custom");
  assert.equal(schemas.IntegrationMarket.properties.currency.const, "EUR");
  assert.equal(schemas.IntegrationMarket.properties.store_country.const, "GR");
  const legal = schemas.MerchantLegal.properties;
  assert.equal(
    legal.merchant_agreement.allOf[1].properties.version.const,
    "dutt-merchant-agreement-v1.0-2026-08-02",
  );
  assert.equal(
    legal.privacy_dpa.allOf[1].properties.version.const,
    "dutt-privacy-dpa-v1.0-2026-08-02",
  );
});

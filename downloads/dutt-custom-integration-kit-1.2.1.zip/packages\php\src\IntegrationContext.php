<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

use InvalidArgumentException;

final class IntegrationContext
{
    public const MERCHANT_AGREEMENT_VERSION = 'dutt-merchant-agreement-v1.0-2026-08-02';
    public const PRIVACY_DPA_VERSION = 'dutt-privacy-dpa-v1.0-2026-08-02';
    private const POLICY_EFFECTIVE_AT = 1785628800;

    public static function create(array $input): array
    {
        $siteUrl = self::requiredText($input['site_url'] ?? null, 'site_url');
        $parts = parse_url($siteUrl);
        if (
            !is_array($parts) ||
            strtolower((string) ($parts['scheme'] ?? '')) !== 'https' ||
            trim((string) ($parts['host'] ?? '')) === '' ||
            isset($parts['user']) ||
            isset($parts['pass']) ||
            isset($parts['query']) ||
            isset($parts['fragment'])
        ) {
            throw new InvalidArgumentException('site_url must use HTTPS');
        }

        $acceptedAt = self::requiredText($input['accepted_at'] ?? null, 'accepted_at');
        $acceptedTimestamp = strtotime($acceptedAt);
        if (
            $acceptedTimestamp === false ||
            $acceptedTimestamp < self::POLICY_EFFECTIVE_AT ||
            $acceptedTimestamp > time() + 300
        ) {
            throw new InvalidArgumentException(
                'accepted_at must be a valid real acceptance timestamp for the current policy'
            );
        }

        $billing = self::billing((array) ($input['merchant_billing'] ?? []));
        $store = self::store((array) ($input['store'] ?? []));

        $context = [
            'source' => 'custom',
            'channel' => 'custom',
            'integration' => 'custom',
            'site_url' => rtrim($siteUrl, '/'),
            'currency' => 'EUR',
            'merchant_legal' => [
                'merchant_agreement' => [
                    'accepted' => true,
                    'version' => self::MERCHANT_AGREEMENT_VERSION,
                    'accepted_at' => $acceptedAt,
                ],
                'privacy_dpa' => [
                    'accepted' => true,
                    'version' => self::PRIVACY_DPA_VERSION,
                    'accepted_at' => $acceptedAt,
                ],
            ],
            'integration_market' => [
                'currency' => 'EUR',
                'store_country' => 'GR',
                'delivery_country' => 'GR',
            ],
            'merchant_billing' => $billing,
            'store' => $store,
        ];

        $locationId = self::text($input['location_id'] ?? null);
        if ($locationId !== '') {
            $context['location_id'] = $locationId;
        }

        return $context;
    }

    public static function buildOrder(array $input): array
    {
        $context = (array) ($input['context'] ?? []);
        self::assertContext($context);
        $externalOrderId = self::requiredText(
            $input['external_order_id'] ?? null,
            'external_order_id'
        );
        $delivery = (array) ($input['delivery'] ?? []);
        $order = (array) ($input['order'] ?? []);
        $items = array_values((array) ($input['items'] ?? []));
        $paymentMethod = self::requiredText(
            $order['payment_method'] ?? $order['paymentMethod'] ?? null,
            'order.payment_method'
        );
        self::assertPrepaid($paymentMethod);
        $total = self::money($order['total'] ?? null, 'order.total');

        $deliveryName = self::requiredText(
            $delivery['name'] ?? $delivery['recipient_name'] ?? null,
            'delivery.name'
        );
        $cleanDelivery = array_merge($delivery, [
            'name' => $deliveryName,
            'recipient_name' => self::requiredText(
                $delivery['recipient_name'] ?? $deliveryName,
                'delivery.recipient_name'
            ),
            'phone' => self::requiredText($delivery['phone'] ?? null, 'delivery.phone'),
            'address' => self::requiredText($delivery['address'] ?? null, 'delivery.address'),
            'city' => self::requiredText($delivery['city'] ?? null, 'delivery.city'),
            'postcode' => self::text($delivery['postcode'] ?? null),
            'country' => 'GR',
        ]);

        $cleanOrder = array_merge($order, [
            'id' => $externalOrderId,
            'order_id' => $externalOrderId,
            'number' => self::text($order['number'] ?? $externalOrderId),
            'order_number' => self::text(
                $order['order_number'] ?? $order['number'] ?? $externalOrderId
            ),
            'total' => $total,
            'currency' => 'EUR',
            'payment_method' => $paymentMethod,
            'items' => !empty($order['items']) ? array_values((array) $order['items']) : $items,
        ]);

        $chargePolicy = (array) ($input['charge_policy'] ?? ['policy' => 'full_quote']);
        $chargePolicy['policy'] = self::text($chargePolicy['policy'] ?? 'full_quote');
        if ($chargePolicy['policy'] === '') {
            throw new InvalidArgumentException('charge_policy.policy is required');
        }
        $subtotalInput = array_key_exists('cart_subtotal', $cleanOrder)
            ? $cleanOrder['cart_subtotal']
            : $cleanOrder['total'];
        $subtotal = self::money($subtotalInput, 'order.cart_subtotal');
        $cleanOrder['cart_subtotal'] = $subtotal;

        $payload = array_merge($context, [
            'source' => 'custom',
            'channel' => 'custom',
            'integration' => 'custom',
            'external_order_id' => $externalOrderId,
            'merchant_order_id' => $externalOrderId,
            'order_number' => $cleanOrder['order_number'],
            'currency' => 'EUR',
            'customer_charge_policy' => $chargePolicy['policy'],
            'charge_policy' => $chargePolicy,
            'cart_subtotal' => $subtotal,
            'cart' => ['subtotal' => $subtotal],
            'customer' => (array) ($input['customer'] ?? []),
            'delivery' => $cleanDelivery,
            'order' => $cleanOrder,
            'items' => $cleanOrder['items'],
        ]);

        if (isset($input['quote']) && is_array($input['quote'])) {
            $payload['quote'] = $input['quote'];
        }

        return $payload;
    }

    public static function assertContext(array $context): void
    {
        $siteUrl = self::requiredText($context['site_url'] ?? null, 'site_url');
        $parts = parse_url($siteUrl);
        if (
            !is_array($parts) ||
            strtolower((string) ($parts['scheme'] ?? '')) !== 'https' ||
            trim((string) ($parts['host'] ?? '')) === '' ||
            isset($parts['user']) ||
            isset($parts['pass']) ||
            isset($parts['query']) ||
            isset($parts['fragment'])
        ) {
            throw new InvalidArgumentException('site_url must use HTTPS');
        }
        if (($context['currency'] ?? null) !== 'EUR') {
            throw new InvalidArgumentException('currency must be EUR');
        }
        if (
            ($context['integration_market']['currency'] ?? null) !== 'EUR' ||
            ($context['integration_market']['store_country'] ?? null) !== 'GR' ||
            ($context['integration_market']['delivery_country'] ?? null) !== 'GR'
        ) {
            throw new InvalidArgumentException('integration market must be EUR/GR');
        }
        self::assertAcceptance(
            (array) ($context['merchant_legal']['merchant_agreement'] ?? []),
            self::MERCHANT_AGREEMENT_VERSION,
            'merchant_legal.merchant_agreement'
        );
        self::assertAcceptance(
            (array) ($context['merchant_legal']['privacy_dpa'] ?? []),
            self::PRIVACY_DPA_VERSION,
            'merchant_legal.privacy_dpa'
        );
        self::billing((array) ($context['merchant_billing'] ?? []));
        self::store((array) ($context['store'] ?? []));
    }

    public static function customPayload(array $payload): array
    {
        $payload['source'] = 'custom';
        $payload['channel'] = 'custom';
        $payload['integration'] = 'custom';
        return $payload;
    }

    public static function assertPayloadPrepaid(array $payload): void
    {
        $order = (array) ($payload['order'] ?? []);
        $payment = (array) ($payload['payment'] ?? []);
        $candidates = [
            $order['payment_method'] ?? null,
            $order['paymentMethod'] ?? null,
            $payload['payment_method'] ?? null,
            $payload['paymentMethod'] ?? null,
            $payment['method'] ?? null,
            $payment['type'] ?? null,
        ];
        foreach ($candidates as $candidate) {
            self::assertPrepaid(self::text($candidate));
        }
    }

    private static function billing(array $input): array
    {
        $vat = preg_replace('/\D+/', '', self::requiredText(
            $input['vat_number'] ?? $input['vatNumber'] ?? $input['afm'] ?? null,
            'merchant_billing.vat_number'
        ));
        if (!is_string($vat) || !preg_match('/^\d{9}$/', $vat)) {
            throw new InvalidArgumentException(
                'merchant_billing.vat_number must contain exactly 9 digits'
            );
        }
        $gemi = preg_replace('/\D+/', '', self::requiredText(
            $input['gemi_number'] ?? $input['gemiNumber'] ?? null,
            'merchant_billing.gemi_number'
        ));
        if (!is_string($gemi) || !preg_match('/^\d{12}$/', $gemi)) {
            throw new InvalidArgumentException(
                'merchant_billing.gemi_number must contain exactly 12 digits'
            );
        }
        $billing = array_merge($input, [
            'legal_name' => self::requiredText(
                $input['legal_name'] ?? $input['legalName'] ?? null,
                'merchant_billing.legal_name'
            ),
            'vat_number' => $vat,
            'gemi_number' => $gemi,
            'tax_office' => self::requiredText(
                $input['tax_office'] ?? $input['taxOffice'] ?? $input['doy'] ?? null,
                'merchant_billing.tax_office'
            ),
            'billing_address' => self::requiredText(
                $input['billing_address'] ?? $input['billingAddress'] ?? $input['address'] ?? null,
                'merchant_billing.billing_address'
            ),
            'billing_city' => self::requiredText(
                $input['billing_city'] ?? $input['billingCity'] ?? $input['city'] ?? null,
                'merchant_billing.billing_city'
            ),
            'billing_postcode' => self::requiredText(
                $input['billing_postcode'] ?? $input['billingPostcode'] ?? $input['postcode'] ?? null,
                'merchant_billing.billing_postcode'
            ),
            'billing_email' => self::requiredText(
                $input['billing_email'] ?? $input['billingEmail'] ?? $input['email'] ?? null,
                'merchant_billing.billing_email'
            ),
            'business_activity' => self::text(
                $input['business_activity'] ?? $input['businessActivity'] ?? null
            ),
        ]);
        if (filter_var($billing['billing_email'], FILTER_VALIDATE_EMAIL) === false) {
            throw new InvalidArgumentException('merchant_billing.billing_email must be valid');
        }
        return $billing;
    }

    private static function assertAcceptance(
        array $acceptance,
        string $expectedVersion,
        string $field
    ): void {
        if (($acceptance['accepted'] ?? null) !== true) {
            throw new InvalidArgumentException($field . '.accepted must be true');
        }
        if (self::text($acceptance['version'] ?? null) !== $expectedVersion) {
            throw new InvalidArgumentException($field . '.version must be ' . $expectedVersion);
        }
        $acceptedAt = self::requiredText(
            $acceptance['accepted_at'] ?? $acceptance['acceptedAt'] ?? null,
            $field . '.accepted_at'
        );
        $timestamp = strtotime($acceptedAt);
        if (
            $timestamp === false ||
            $timestamp < self::POLICY_EFFECTIVE_AT ||
            $timestamp > time() + 300
        ) {
            throw new InvalidArgumentException($field . '.accepted_at is invalid');
        }
    }

    private static function store(array $input): array
    {
        return array_merge($input, [
            'name' => self::requiredText($input['name'] ?? null, 'store.name'),
            'address' => self::requiredText($input['address'] ?? null, 'store.address'),
            'city' => self::requiredText($input['city'] ?? null, 'store.city'),
            'postcode' => self::text($input['postcode'] ?? null),
            'country' => 'GR',
            'phone' => self::requiredText($input['phone'] ?? null, 'store.phone'),
        ]);
    }

    private static function assertPrepaid(string $value): void
    {
        $method = trim((string) preg_replace('/[^a-z0-9]+/', '_', strtolower($value)), '_');
        if (in_array(
            $method,
            ['cash', 'cod', 'cash_on_delivery', 'cashondelivery', 'pay_on_delivery'],
            true
        )) {
            throw new InvalidArgumentException(
                'Cash on delivery is disabled for DUTT custom integrations'
            );
        }
    }

    private static function requiredText(mixed $value, string $field): string
    {
        $result = self::text($value);
        if ($result === '') {
            throw new InvalidArgumentException($field . ' is required');
        }
        return $result;
    }

    private static function text(mixed $value): string
    {
        return $value === null ? '' : trim((string) $value);
    }

    private static function money(mixed $value, string $field): float
    {
        if (is_bool($value) || !is_scalar($value) || trim((string) $value) === '') {
            throw new InvalidArgumentException($field . ' must be a non-negative number');
        }
        $amount = filter_var($value, FILTER_VALIDATE_FLOAT);
        if ($amount === false || !is_finite((float) $amount) || (float) $amount < 0) {
            throw new InvalidArgumentException($field . ' must be a non-negative number');
        }
        $cents = round((float) $amount * 100);
        if (abs(((float) $amount * 100) - $cents) > 0.0000001) {
            throw new InvalidArgumentException($field . ' must have at most two decimal places');
        }
        return $cents / 100;
    }
}

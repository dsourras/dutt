<?php

declare(strict_types=1);

require_once __DIR__ . '/../src/DuttApiException.php';
require_once __DIR__ . '/../src/IntegrationContext.php';
require_once __DIR__ . '/../src/ReplayStore.php';
require_once __DIR__ . '/../src/AtomicReplayStore.php';
require_once __DIR__ . '/../src/MemoryReplayStore.php';
require_once __DIR__ . '/../src/WebhookVerifier.php';
require_once __DIR__ . '/../src/DuttMerchantClient.php';

use Dutt\CustomIntegration\DuttApiException;
use Dutt\CustomIntegration\DuttMerchantClient;
use Dutt\CustomIntegration\IntegrationContext;
use Dutt\CustomIntegration\MemoryReplayStore;
use Dutt\CustomIntegration\AtomicReplayStore;
use Dutt\CustomIntegration\ReplayStore;
use Dutt\CustomIntegration\WebhookVerifier;

$tests = [];

function test(string $name, callable $callback): void
{
    global $tests;
    $tests[] = [$name, $callback];
}

function same(mixed $expected, mixed $actual, string $message = ''): void
{
    if ($expected !== $actual) {
        throw new RuntimeException(
            $message !== '' ? $message : 'Expected ' . var_export($expected, true) .
                ', got ' . var_export($actual, true)
        );
    }
}

function context(): array
{
    return IntegrationContext::create([
        'site_url' => 'https://shop.example.gr',
        'accepted_at' => '2026-08-11T10:00:00.000Z',
        'merchant_billing' => [
            'legal_name' => 'Example IKE',
            'vat_number' => '123456789',
            'gemi_number' => '176518140000',
            'tax_office' => 'DOY Larissas',
            'billing_address' => 'Example 1',
            'billing_city' => 'Larissa',
            'billing_postcode' => '41222',
            'billing_email' => 'billing@example.gr',
        ],
        'store' => [
            'name' => 'Example Store',
            'address' => 'Example 1',
            'city' => 'Larissa',
            'postcode' => '41222',
            'phone' => '2410000000',
        ],
    ]);
}

function orderPayload(string $paymentMethod = 'card'): array
{
    return IntegrationContext::buildOrder([
        'context' => context(),
        'external_order_id' => 'ORDER-100',
        'delivery' => [
            'name' => 'Customer',
            'phone' => '6900000000',
            'address' => 'Delivery 1',
            'city' => 'Larissa',
            'postcode' => '41222',
        ],
        'order' => [
            'total' => 25,
            'payment_method' => $paymentMethod,
        ],
        'items' => [['name' => 'Item', 'quantity' => 1, 'price' => 25, 'total' => 25]],
    ]);
}

test('context enforces production policy', function (): void {
    $value = context();
    same('custom', $value['source']);
    same('EUR', $value['currency']);
    same('GR', $value['integration_market']['store_country']);
    same(true, $value['merchant_legal']['merchant_agreement']['accepted']);
});

test('invalid VAT is rejected', function (): void {
    $failed = false;
    try {
        $value = context();
        $value['merchant_billing']['vat_number'] = '123';
        IntegrationContext::assertContext($value);
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('invalid GEMI is rejected', function (): void {
    $failed = false;
    try {
        $value = context();
        $value['merchant_billing']['gemi_number'] = '123';
        IntegrationContext::assertContext($value);
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('handwritten payload cannot bypass legal policy validation', function (): void {
    $value = context();
    $value['merchant_legal']['privacy_dpa']['version'] = 'old-version';
    $failed = false;
    try {
        IntegrationContext::assertContext($value);
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('COD is rejected locally', function (): void {
    $failed = false;
    try {
        orderPayload('cash_on_delivery');
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('invalid cart subtotal is rejected locally', function (): void {
    foreach (['invalid', null, '', false, 1.001] as $subtotal) {
        $failed = false;
        try {
            $input = orderPayload();
            $input['order']['cart_subtotal'] = $subtotal;
            IntegrationContext::buildOrder([
                'context' => context(),
                'external_order_id' => 'ORDER-BAD-SUBTOTAL',
                'delivery' => $input['delivery'],
                'order' => $input['order'],
            ]);
        } catch (InvalidArgumentException) {
            $failed = true;
        }
        same(true, $failed);
    }
});

test('invalid order totals are rejected locally', function (): void {
    foreach ([null, '', false, -1, 1.001] as $total) {
        $failed = false;
        try {
            $input = orderPayload();
            $input['order']['total'] = $total;
            IntegrationContext::buildOrder([
                'context' => context(),
                'external_order_id' => 'ORDER-BAD-TOTAL',
                'delivery' => $input['delivery'],
                'order' => $input['order'],
            ]);
        } catch (InvalidArgumentException) {
            $failed = true;
        }
        same(true, $failed);
    }
});

test('client sends merchant key and forces custom source', function (): void {
    $captured = [];
    $transport = function (
        string $url,
        string $method,
        array $headers,
        string $body
    ) use (&$captured): array {
        $captured = compact('url', 'method', 'headers', 'body');
        return ['status' => 200, 'body' => '{"success":true,"status":"ok"}'];
    };
    $client = new DuttMerchantClient(
        'dutt_live_test',
        'http://127.0.0.1:9999',
        15,
        $transport
    );
    $payload = orderPayload();
    $payload['source'] = 'custom_api';
    $client->createOrder($payload);
    $decoded = json_decode($captured['body'], true, 512, JSON_THROW_ON_ERROR);
    same('custom', $decoded['source']);
    same(true, in_array('X-DUTT-Merchant-Key: dutt_live_test', $captured['headers'], true));
});

test('API errors retain status and reason', function (): void {
    $client = new DuttMerchantClient(
        'dutt_live_test',
        'http://127.0.0.1:9999',
        15,
        fn (): array => [
            'status' => 409,
            'body' => '{"success":false,"reason":"cannot_cancel_terminal_status"}',
        ]
    );
    try {
        $client->cancelDelivery('DEL-1');
        throw new RuntimeException('Expected DuttApiException');
    } catch (DuttApiException $error) {
        same(409, $error->status);
        same('cannot_cancel_terminal_status', $error->reason);
    }
});

test('empty or incomplete success response is rejected', function (): void {
    $raw = '';
    $client = new DuttMerchantClient(
        'dutt_live_test',
        'http://127.0.0.1:9999',
        90,
        function () use (&$raw): array {
            return ['status' => 200, 'body' => $raw];
        }
    );
    try {
        $client->listLocations();
        throw new RuntimeException('Expected DuttApiException');
    } catch (DuttApiException $error) {
        same('empty_response', $error->reason);
    }
    $raw = '{}';
    try {
        $client->listLocations();
        throw new RuntimeException('Expected DuttApiException');
    } catch (DuttApiException $error) {
        same('invalid_json_response', $error->reason);
    }
});

test('refund amounts reject missing values and fractions of a cent', function (): void {
    $client = new DuttMerchantClient('dutt_live_test', 'http://127.0.0.1:9999');
    foreach ([null, '', false, -1, 1.001] as $amount) {
        try {
            $client->refundNotice([
                'external_order_id' => 'ORDER-REFUND',
                'refund_id' => 'REFUND-1',
                'amount' => $amount,
            ]);
            throw new RuntimeException('Expected invalid refund amount');
        } catch (InvalidArgumentException $error) {
            same(true, str_contains($error->getMessage(), 'amount'));
        }
    }
});

test('URLs reject embedded credentials, queries and fragments', function (): void {
    foreach ([
        'https://user:pass@example.test',
        'https://example.test?token=secret',
        'https://example.test#fragment',
        'ftp://localhost',
    ] as $baseUrl) {
        try {
            new DuttMerchantClient('dutt_live_test', $baseUrl);
            throw new RuntimeException('Expected invalid base URL');
        } catch (InvalidArgumentException) {
        }
    }
});

function signedHeaders(string $body, string $secret, int $timestamp, string $eventId): array
{
    return [
        'x-dutt-event' => 'delivery.delivered',
        'x-dutt-event-id' => $eventId,
        'x-dutt-signature' => 'sha256=' . hash_hmac(
            'sha256',
            $timestamp . '.' . $body,
            $secret
        ),
        'x-dutt-timestamp' => (string) $timestamp,
    ];
}

test('valid webhook is accepted and duplicate is ignored', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $body = '{"event":"delivery.delivered","event_id":"event-00000001"}';
    $headers = signedHeaders($body, $secret, $timestamp, 'event-00000001');
    $store = new MemoryReplayStore();
    $count = 0;
    $first = WebhookVerifier::handle(
        $body,
        $headers,
        $secret,
        $store,
        function () use (&$count): void { $count++; },
        300,
        $timestamp
    );
    $second = WebhookVerifier::handle(
        $body,
        $headers,
        $secret,
        $store,
        function () use (&$count): void { $count++; },
        300,
        $timestamp
    );
    same(true, $first['processed']);
    same(true, $second['duplicate']);
    same(1, $count);
});

test('legacy replay stores remain compatible', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $eventId = 'event-legacy-000001';
    $body = '{"event":"delivery.delivered","event_id":"' . $eventId . '"}';
    $headers = signedHeaders($body, $secret, $timestamp, $eventId);
    $store = new class implements ReplayStore {
        private array $events = [];

        public function has(string $id): bool
        {
            return isset($this->events[$id]);
        }

        public function put(string $id, int $processedAt): void
        {
            $this->events[$id] = $processedAt;
        }
    };
    $count = 0;
    $options = static function () use (
        $body,
        $headers,
        $secret,
        $store,
        &$count,
        $timestamp
    ): array {
        return WebhookVerifier::handle(
            $body,
            $headers,
            $secret,
            $store,
            function () use (&$count): void { $count++; },
            300,
            $timestamp
        );
    };
    same(true, $options()['processed']);
    same(true, $options()['duplicate']);
    same(1, $count);
});

test('webhook claim uses processing time rather than signed event time', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $processingTime = $timestamp + 30;
    $eventId = 'event-clock-000001';
    $body = '{"event":"delivery.delivered","event_id":"' . $eventId . '"}';
    $headers = signedHeaders($body, $secret, $timestamp, $eventId);
    $store = new class implements AtomicReplayStore {
        public ?int $claimedAt = null;
        public ?int $completedAt = null;

        public function has(string $eventId): bool
        {
            return false;
        }

        public function put(string $eventId, int $timestamp): void
        {
        }

        public function claim(string $eventId, int $claimedAt): bool
        {
            $this->claimedAt = $claimedAt;
            return true;
        }

        public function complete(string $eventId, int $completedAt): void
        {
            $this->completedAt = $completedAt;
        }

        public function release(string $eventId): void
        {
        }
    };
    WebhookVerifier::handle(
        $body,
        $headers,
        $secret,
        $store,
        static function (): void {
        },
        300,
        $processingTime
    );
    same($processingTime, $store->claimedAt);
    same($processingTime, $store->completedAt);
});

test('tampered and stale webhooks are rejected', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $body = '{"event":"delivery.delivered","event_id":"event-00000002"}';
    $headers = signedHeaders($body, $secret, $timestamp, 'event-00000002');
    foreach ([
        [$body . ' ', $timestamp, 'invalid_signature'],
        [$body, $timestamp + 301, 'stale_timestamp'],
    ] as [$candidateBody, $now, $expected]) {
        try {
            WebhookVerifier::verify($candidateBody, $headers, $secret, 300, $now);
            throw new RuntimeException('Expected webhook verification failure');
        } catch (RuntimeException $error) {
            same($expected, $error->getMessage());
        }
    }
});

test('webhook verification rejects a JSON list payload', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $eventId = 'event-list-000001';
    $body = '[]';
    $headers = signedHeaders($body, $secret, $timestamp, $eventId);
    try {
        WebhookVerifier::verify($body, $headers, $secret, 300, $timestamp);
        throw new RuntimeException('Expected list payload rejection');
    } catch (RuntimeException $error) {
        same('invalid_json', $error->getMessage());
    }
});

test('webhook verification rejects invalid clock configuration', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $eventId = 'event-clock-000002';
    $body = '{"event":"delivery.delivered","event_id":"' . $eventId . '"}';
    $headers = signedHeaders($body, $secret, $timestamp, $eventId);
    foreach ([-1] as $tolerance) {
        try {
            WebhookVerifier::verify($body, $headers, $secret, $tolerance, $timestamp);
            throw new RuntimeException('Expected invalid tolerance');
        } catch (InvalidArgumentException $error) {
            same(true, str_contains($error->getMessage(), 'toleranceSeconds'));
        }
    }
    try {
        WebhookVerifier::verify($body, $headers, $secret, 300, -1);
        throw new RuntimeException('Expected invalid current time');
    } catch (InvalidArgumentException $error) {
        same(true, str_contains($error->getMessage(), 'nowSeconds'));
    }
});

test('client validates identity URLs and registered webhook event names', function (): void {
    $requests = [];
    $client = new DuttMerchantClient(
        'dutt_live_test',
        'https://api.example.test',
        90,
        function ($url, $method, $headers, $body) use (&$requests): array {
            $requests[] = json_decode($body, true, 512, JSON_THROW_ON_ERROR);
            return ['status' => 200, 'body' => '{"success":true}'];
        }
    );
    foreach ([
        fn () => $client->markReady([
            'external_order_id' => 'ORDER-1',
            'site_url' => 'http://shop.example.test',
        ]),
        fn () => $client->getStatus([
            'external_order_id' => 'ORDER-1',
            'site_url' => 'https://shop.example.test?token=bad',
        ]),
        fn () => $client->registerWebhook(
            'https://shop.example.test/webhook',
            '0123456789abcdef',
            ['delivery.delivereed']
        ),
    ] as $operation) {
        try {
            $operation();
            throw new RuntimeException('Expected validation failure');
        } catch (InvalidArgumentException) {
        }
    }
    $client->registerWebhook(
        'https://shop.example.test/webhook',
        '0123456789abcdef',
        ['DELIVERY.DELIVERED', 'delivery.delivered']
    );
    same(['delivery.delivered'], $requests[0]['events']);
});

test('failed webhook processing releases the atomic claim for retry', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $eventId = 'event-retry-000001';
    $body = '{"event":"delivery.delivered","event_id":"' . $eventId . '"}';
    $headers = signedHeaders($body, $secret, $timestamp, $eventId);
    $store = new MemoryReplayStore();
    try {
        WebhookVerifier::handle(
            $body,
            $headers,
            $secret,
            $store,
            fn () => throw new RuntimeException('database unavailable'),
            300,
            $timestamp
        );
        throw new RuntimeException('Expected processing failure');
    } catch (RuntimeException $error) {
        same('database unavailable', $error->getMessage());
    }
    same(false, $store->has($eventId));
});

test('malformed webhook event ID is rejected', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $body = '{"event":"delivery.delivered","event_id":"evt-1"}';
    $headers = signedHeaders($body, $secret, $timestamp, 'evt-1');
    try {
        WebhookVerifier::verify($body, $headers, $secret, 300, $timestamp);
        throw new RuntimeException('Expected invalid event ID');
    } catch (RuntimeException $error) {
        same('invalid_event_id', $error->getMessage());
    }
});

$failed = 0;
foreach ($tests as [$name, $callback]) {
    try {
        $callback();
        echo "PASS {$name}\n";
    } catch (Throwable $error) {
        $failed++;
        fwrite(STDERR, "FAIL {$name}: {$error->getMessage()}\n");
    }
}

echo sprintf("%d tests, %d failed\n", count($tests), $failed);
exit($failed === 0 ? 0 : 1);

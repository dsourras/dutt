#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";

import {
  DuttMerchantClient,
  buildOrderPayload,
  createIntegrationContext,
} from "../packages/node/src/index.js";

function parseArgs(argv) {
  const args = {
    envFile: ".env",
    quote: false,
    create: false,
    dispatch: false,
    cancel: false,
  };
  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    if (value === "--env") args.envFile = argv[++index] || "";
    else if (value === "--quote") args.quote = true;
    else if (value === "--create") {
      args.quote = true;
      args.create = true;
    } else if (value === "--dispatch") {
      args.quote = true;
      args.create = true;
      args.dispatch = true;
    } else if (value === "--cancel") args.cancel = true;
    else if (value === "--help" || value === "-h") args.help = true;
    else throw new Error(`Unknown argument: ${value}`);
  }
  return args;
}

function usage() {
  return `
DUTT Custom Integration Kit smoke test

Safe connection test only:
  node scripts/smoke-test.mjs --env .env

Connection and quote (uses protected Geocoding/Routes budget):
  node scripts/smoke-test.mjs --env .env --quote

Create a prepared test order, without dispatch:
  node scripts/smoke-test.mjs --env .env --create

Dispatch requires explicit acknowledgement:
  set DUTT_ALLOW_LIVE_DISPATCH=YES
  node scripts/smoke-test.mjs --env .env --dispatch

Add --cancel to cancel the dispatched test delivery immediately.
`;
}

function loadEnv(filePath) {
  const absolute = path.resolve(filePath);
  if (!fs.existsSync(absolute)) throw new Error(`Environment file not found: ${absolute}`);
  const values = {};
  for (const line of fs.readFileSync(absolute, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator < 1) continue;
    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    values[key] = value;
  }
  return { ...values, ...process.env };
}

function required(env, key) {
  const value = String(env[key] || "").trim();
  if (!value) throw new Error(`Missing ${key}`);
  return value;
}

function compactTimestamp() {
  return new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
}

function compact(value) {
  return {
    success: value?.success,
    status: value?.status,
    reason: value?.reason,
    merchant_id: value?.merchant_id,
    merchant_key_prefix: value?.merchant_key_prefix,
    quote_id: value?.quote_id,
    quote_price: value?.quote_price,
    customer_charge: value?.customer_charge,
    store_contribution: value?.store_contribution,
    merchant_due_to_dutt: value?.merchant_due_to_dutt,
    external_order_id: value?.external_order_id,
    delivery_id: value?.delivery_id || value?.dutt_order_id,
    city_id: value?.city_id,
  };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write(usage());
    return;
  }
  const env = loadEnv(args.envFile);
  if (args.dispatch && env.DUTT_ALLOW_LIVE_DISPATCH !== "YES") {
    throw new Error("Live dispatch is blocked. Set DUTT_ALLOW_LIVE_DISPATCH=YES explicitly.");
  }

  const context = createIntegrationContext({
    siteUrl: required(env, "DUTT_SITE_URL"),
    acceptedAt: required(env, "DUTT_MERCHANT_ACCEPTED_AT"),
    merchantBilling: {
      legal_name: required(env, "DUTT_LEGAL_NAME"),
      vat_number: required(env, "DUTT_VAT_NUMBER"),
      gemi_number: required(env, "DUTT_GEMI_NUMBER"),
      tax_office: required(env, "DUTT_TAX_OFFICE"),
      billing_address: required(env, "DUTT_BILLING_ADDRESS"),
      billing_city: required(env, "DUTT_BILLING_CITY"),
      billing_postcode: required(env, "DUTT_BILLING_POSTCODE"),
      billing_email: required(env, "DUTT_BILLING_EMAIL"),
      business_activity: env.DUTT_BUSINESS_ACTIVITY || "",
    },
    store: {
      name: required(env, "DUTT_STORE_NAME"),
      address: required(env, "DUTT_STORE_ADDRESS"),
      city: required(env, "DUTT_STORE_CITY"),
      postcode: env.DUTT_STORE_POSTCODE || "",
      phone: required(env, "DUTT_STORE_PHONE"),
    },
  });
  const client = new DuttMerchantClient({
    merchantKey: required(env, "DUTT_MERCHANT_KEY"),
    baseUrl: env.DUTT_API_BASE_URL || undefined,
  });

  const connection = await client.connectionTest(context);
  console.log("connection", compact(connection));
  const locations = await client.listLocations();
  console.log("locations", { success: locations.success, count: locations.count });
  if (!args.quote) return;

  const orderId = `CUSTOM-SMOKE-${compactTimestamp()}`;
  const payload = buildOrderPayload({
    context,
    externalOrderId: orderId,
    delivery: {
      name: required(env, "DUTT_TEST_DELIVERY_NAME"),
      phone: required(env, "DUTT_TEST_DELIVERY_PHONE"),
      email: required(env, "DUTT_TEST_DELIVERY_EMAIL"),
      address: required(env, "DUTT_TEST_DELIVERY_ADDRESS"),
      city: required(env, "DUTT_TEST_DELIVERY_CITY"),
      postcode: env.DUTT_TEST_DELIVERY_POSTCODE || "",
    },
    order: {
      total: 10,
      payment_method: "card",
      payment_method_title: "Card",
    },
    items: [{ name: "DUTT integration smoke item", sku: "DUTT-SMOKE", quantity: 1, price: 10, total: 10 }],
  });
  const quote = await client.quote(payload);
  console.log("quote", compact(quote));
  if (!args.create) return;

  const created = await client.createOrder({ ...payload, quote });
  console.log("create_order", compact(created));
  if (!args.dispatch) return;

  const ready = await client.markReady({
    site_url: context.site_url,
    external_order_id: orderId,
  });
  console.log("mark_ready", compact(ready));
  if (args.cancel) {
    const cancelled = await client.cancelDelivery({
      deliveryId: ready.delivery_id || ready.dutt_order_id,
      cityId: ready.city_id,
      reason: "custom_integration_smoke_test",
    });
    console.log("cancel", compact(cancelled));
  }
}

main().catch((error) => {
  console.error(`Smoke test failed: ${error.reason || error.message}`);
  process.exitCode = 1;
});

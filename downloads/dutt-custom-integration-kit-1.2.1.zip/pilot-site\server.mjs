#!/usr/bin/env node

import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import {
  DuttMerchantClient,
  buildOrderPayload,
  createIntegrationContext,
  handleDuttWebhook,
} from "../packages/node/src/index.js";

const moduleDirectory = path.dirname(fileURLToPath(import.meta.url));
const publicDirectory = path.join(moduleDirectory, "public");
const dataDirectory = path.join(moduleDirectory, "data");
const statePath = path.join(dataDirectory, "pilot-state.json");
const replayPath = path.join(dataDirectory, "webhook-events.json");

export function parseEnv(text) {
  const result = {};
  for (const line of String(text || "").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator < 1) continue;
    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    result[key] = value;
  }
  return result;
}

function required(env, key) {
  const value = String(env[key] || "").trim();
  if (!value) throw new Error(`Missing ${key}`);
  return value;
}

function safeEqual(left, right) {
  const leftDigest = createHash("sha256").update(String(left)).digest();
  const rightDigest = createHash("sha256").update(String(right)).digest();
  return timingSafeEqual(leftDigest, rightDigest);
}

export function isAuthorized(headers, expectedToken) {
  const received = headers?.["x-pilot-token"] || headers?.get?.("x-pilot-token") || "";
  return Boolean(expectedToken) && safeEqual(received, expectedToken);
}

export function buildPilotPayload({ context, input, orderId }) {
  const phone = String(input.phone || "").replace(/\s+/g, "");
  if (!/^69\d{8}$/.test(phone)) {
    throw new TypeError("Το τηλέφωνο παραλήπτη πρέπει να είναι ελληνικό κινητό 10 ψηφίων");
  }
  return buildOrderPayload({
    context,
    externalOrderId: orderId,
    delivery: {
      name: String(input.name || "").trim(),
      phone,
      email: String(input.email || "").trim(),
      address: String(input.address || "").trim(),
      city: String(input.city || "Larissa").trim(),
      postcode: String(input.postcode || "").trim(),
      notes: String(input.notes || "DUTT custom integration pilot").trim(),
    },
    customer: {
      name: String(input.name || "").trim(),
      phone,
      email: String(input.email || "").trim(),
    },
    order: {
      total: 0,
      cart_subtotal: 0,
      payment_method: "free_pilot",
      payment_method_title: "Free pilot order",
    },
    items: [
      {
        name: "DUTT Custom Integration Pilot Parcel",
        sku: "DUTT-PILOT-001",
        quantity: 1,
        price: 0,
        total: 0,
        weight_kg: 0.2,
        dimensions_cm: { length: 20, width: 15, height: 5 },
      },
    ],
    chargePolicy: { policy: "store_absorbs" },
  });
}

export function syncOrderFromStatus(current, status) {
  const deliveryId = String(status?.delivery_id || status?.dutt_order_id || "").trim();
  const cityId = String(status?.city_id || "").trim();
  const backendStatus = String(status?.status || "").trim().toLowerCase();
  if (deliveryId) current.deliveryId = deliveryId;
  if (cityId) current.cityId = cityId;
  if (
    current.stage === "merchant_preparing" &&
    deliveryId &&
    backendStatus &&
    !["merchant_preparing", "preparing", "quoted"].includes(backendStatus)
  ) {
    current.stage = "dispatched";
  }
  return current;
}

export class JsonReplayStore {
  static processingLeaseSeconds = 900;

  constructor(filePath) {
    this.filePath = filePath;
    this.values = new Map(
      Object.entries(readJson(filePath, {})).map(([eventId, value]) => {
        if (value?.status === "processing") {
          return [eventId, { status: "processing", claimedAt: Number(value.claimedAt) || 0 }];
        }
        return [eventId, {
          status: "processed",
          completedAt: Number(value?.completedAt ?? value) || 0,
        }];
      }),
    );
  }

  async has(eventId) {
    return this.values.has(eventId);
  }

  async claim(eventId, claimedAt) {
    const current = this.values.get(eventId);
    if (current?.status === "processed") return false;
    if (
      current?.status === "processing" &&
      Number(current.claimedAt) > claimedAt - JsonReplayStore.processingLeaseSeconds
    ) return false;
    this.values.set(eventId, { status: "processing", claimedAt });
    this.persist();
    return true;
  }

  async complete(eventId, completedAt) {
    this.values.set(eventId, { status: "processed", completedAt });
    this.persist();
  }

  async release(eventId) {
    if (this.values.get(eventId)?.status === "processing") {
      this.values.delete(eventId);
      this.persist();
    }
  }

  persist() {
    writeJsonAtomic(this.filePath, Object.fromEntries(this.values));
  }
}

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporaryPath = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(temporaryPath, filePath);
}

function orderId() {
  return `CUSTOM-PILOT-${new Date().toISOString().replace(/\D/g, "").slice(0, 14)}-${randomUUID().slice(0, 8)}`;
}

function compact(value) {
  if (!value || typeof value !== "object") return value;
  const allowed = [
    "success",
    "status",
    "reason",
    "merchant_id",
    "merchant_key_prefix",
    "quote_id",
    "quote_price",
    "customer_charge",
    "store_contribution",
    "merchant_due_to_dutt",
    "external_order_id",
    "delivery_id",
    "dutt_order_id",
    "city_id",
    "cancelled",
  ];
  return Object.fromEntries(allowed.filter((key) => value[key] !== undefined).map((key) => [key, value[key]]));
}

function contentType(filePath) {
  return {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".png": "image/png",
  }[path.extname(filePath).toLowerCase()] || "application/octet-stream";
}

function sendJson(res, status, body) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  });
  res.end(JSON.stringify(body));
}

async function readBody(req, { raw = false } = {}) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 64 * 1024) throw new Error("request_too_large");
    chunks.push(chunk);
  }
  const buffer = Buffer.concat(chunks);
  if (raw) return buffer;
  return buffer.length ? JSON.parse(buffer.toString("utf8")) : {};
}

function serveStatic(res, pathname) {
  const requested = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const filePath = path.resolve(publicDirectory, requested);
  if (!filePath.startsWith(`${path.resolve(publicDirectory)}${path.sep}`) && filePath !== path.join(publicDirectory, "index.html")) {
    sendJson(res, 403, { success: false, reason: "forbidden" });
    return;
  }
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    sendJson(res, 404, { success: false, reason: "not_found" });
    return;
  }
  res.writeHead(200, {
    "content-type": contentType(filePath),
    "cache-control": "no-store",
    "content-security-policy": "default-src 'self'; img-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'",
    "x-content-type-options": "nosniff",
    "x-frame-options": "DENY",
    "referrer-policy": "no-referrer",
  });
  fs.createReadStream(filePath).pipe(res);
}

function loadConfiguration(argv = process.argv.slice(2)) {
  const envIndex = argv.indexOf("--env");
  const envPath = path.resolve(envIndex >= 0 ? argv[envIndex + 1] : path.join(moduleDirectory, ".env"));
  const fileEnv = fs.existsSync(envPath) ? parseEnv(fs.readFileSync(envPath, "utf8")) : {};
  return { ...fileEnv, ...process.env };
}

export function createPilotServer(env) {
  const accessToken = required(env, "PILOT_ACCESS_TOKEN");
  const webhookSecret = required(env, "DUTT_WEBHOOK_SECRET");
  const siteUrl = required(env, "DUTT_SITE_URL").replace(/\/+$/, "");
  const dispatchEnabled = env.DUTT_ALLOW_LIVE_DISPATCH === "YES";
  const storePhoneVerified = env.DUTT_STORE_PHONE_VERIFIED === "YES";
  const client = new DuttMerchantClient({
    merchantKey: required(env, "DUTT_MERCHANT_KEY"),
    baseUrl: env.DUTT_API_BASE_URL || undefined,
    timeoutMs: Number(env.DUTT_API_TIMEOUT_MS || 90000),
  });
  const context = createIntegrationContext({
    siteUrl,
    acceptedAt: required(env, "DUTT_MERCHANT_ACCEPTED_AT"),
    merchantBilling: {
      legal_name: required(env, "DUTT_LEGAL_NAME"),
      vat_number: required(env, "DUTT_VAT_NUMBER"),
      gemi_number: required(env, "DUTT_GEMI_NUMBER"),
      tax_office: required(env, "DUTT_TAX_OFFICE"),
      billing_address: required(env, "DUTT_BILLING_ADDRESS"),
      billing_city: required(env, "DUTT_BILLING_CITY"),
      billing_postcode: required(env, "DUTT_BILLING_POSTCODE"),
      billing_email: required(env, "DUTT_BILLING_EMAIL"),
      business_activity: env.DUTT_BUSINESS_ACTIVITY || "",
    },
    store: {
      name: required(env, "DUTT_STORE_NAME"),
      address: required(env, "DUTT_STORE_ADDRESS"),
      city: required(env, "DUTT_STORE_CITY"),
      postcode: env.DUTT_STORE_POSTCODE || "",
      phone: required(env, "DUTT_STORE_PHONE"),
    },
  });
  const state = readJson(statePath, { orders: {}, webhooks: [] });
  const replayStore = new JsonReplayStore(replayPath);
  const persist = () => writeJsonAtomic(statePath, state);

  return http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    try {
      if (req.method === "POST" && url.pathname === "/webhooks/dutt") {
        const rawBody = await readBody(req, { raw: true });
        const result = await handleDuttWebhook({
          rawBody,
          headers: req.headers,
          secret: webhookSecret,
          replayStore,
          onEvent: async (payload, verified) => {
            if (state.webhooks.some((entry) => entry.eventId === verified.eventId)) return;
            const externalOrderId = payload.external_order_id || payload.externalOrderId || "";
            const deliveryId = payload.delivery_id || payload.deliveryId || "";
            const matchingOrder = Object.values(state.orders).find((order) =>
              order.orderId === externalOrderId ||
              (deliveryId && order.deliveryId === deliveryId)
            );
            if (matchingOrder) {
              matchingOrder.status = compact(payload);
              syncOrderFromStatus(matchingOrder, payload);
              matchingOrder.updatedAt = new Date().toISOString();
            }
            state.webhooks.unshift({
              receivedAt: new Date().toISOString(),
              event: verified.event,
              eventId: verified.eventId,
              externalOrderId,
              deliveryId,
            });
            state.webhooks = state.webhooks.slice(0, 100);
            persist();
          },
        });
        sendJson(res, 200, { success: true, duplicate: result.duplicate });
        return;
      }

      if (!url.pathname.startsWith("/api/")) {
        serveStatic(res, url.pathname);
        return;
      }
      if (!isAuthorized(req.headers, accessToken)) {
        sendJson(res, 401, { success: false, reason: "pilot_auth_required" });
        return;
      }

      if (req.method === "GET" && url.pathname === "/api/config") {
        sendJson(res, 200, {
          success: true,
          siteUrl,
          merchantKeyPrefix: required(env, "DUTT_MERCHANT_KEY").slice(0, 18),
          dispatchEnabled,
          storePhoneVerified,
          store: context.store,
        });
        return;
      }
      if (req.method === "GET" && url.pathname === "/api/orders") {
        sendJson(res, 200, {
          success: true,
          orders: Object.values(state.orders).slice(-10).reverse(),
          webhooks: state.webhooks.slice(0, 20),
        });
        return;
      }
      if (req.method !== "POST") {
        sendJson(res, 405, { success: false, reason: "method_not_allowed" });
        return;
      }

      const body = await readBody(req);
      if (url.pathname === "/api/connection") {
        sendJson(res, 200, { success: true, result: compact(await client.connectionTest(context)) });
        return;
      }
      if (url.pathname === "/api/register-webhook") {
        const result = await client.registerWebhook({ url: `${siteUrl}/webhooks/dutt`, secret: webhookSecret });
        sendJson(res, 200, { success: true, result: compact(result), webhookUrl: `${siteUrl}/webhooks/dutt` });
        return;
      }
      if (url.pathname === "/api/quote") {
        const id = orderId();
        const payload = buildPilotPayload({ context, input: body, orderId: id });
        const quote = await client.quote(payload);
        state.orders[id] = {
          orderId: id,
          stage: "quoted",
          createdAt: new Date().toISOString(),
          delivery: payload.delivery,
          quote: compact(quote),
          payload,
        };
        persist();
        sendJson(res, 200, { success: true, order: { ...state.orders[id], payload: undefined } });
        return;
      }
      if (url.pathname === "/api/create-order") {
        const id = String(body.orderId || "");
        const current = state.orders[id];
        if (!current?.payload || current.stage !== "quoted") throw new Error("quoted_order_required");
        const created = await client.createOrder({ ...current.payload, quote: current.quote });
        current.stage = "merchant_preparing";
        current.created = compact(created);
        current.deliveryId = created.delivery_id || created.dutt_order_id || "";
        current.cityId = created.city_id || "";
        current.updatedAt = new Date().toISOString();
        persist();
        sendJson(res, 200, { success: true, order: { ...current, payload: undefined } });
        return;
      }
      if (url.pathname === "/api/status") {
        const id = String(body.orderId || "");
        const current = state.orders[id];
        if (!current) throw new Error("order_not_found");
        const status = await client.getStatus({
          deliveryId: current.deliveryId,
          cityId: current.cityId,
          externalOrderId: id,
          siteUrl,
        });
        current.status = compact(status);
        syncOrderFromStatus(current, status);
        current.updatedAt = new Date().toISOString();
        persist();
        sendJson(res, 200, { success: true, order: { ...current, payload: undefined } });
        return;
      }
      if (url.pathname === "/api/dispatch") {
        if (!dispatchEnabled || !storePhoneVerified) {
          sendJson(res, 403, { success: false, reason: "live_dispatch_locked" });
          return;
        }
        if (body.confirmation !== "DISPATCH REAL ORDER") throw new Error("dispatch_confirmation_required");
        const id = String(body.orderId || "");
        const current = state.orders[id];
        if (!current || current.stage !== "merchant_preparing") throw new Error("prepared_order_required");
        const ready = await client.markReady({ external_order_id: id, site_url: siteUrl });
        current.stage = "dispatched";
        current.ready = compact(ready);
        current.deliveryId = ready.delivery_id || ready.dutt_order_id || current.deliveryId || "";
        current.cityId = ready.city_id || current.cityId || "";
        current.updatedAt = new Date().toISOString();
        persist();
        sendJson(res, 200, { success: true, order: { ...current, payload: undefined } });
        return;
      }
      if (url.pathname === "/api/cancel") {
        if (body.confirmation !== "CANCEL REAL ORDER") throw new Error("cancel_confirmation_required");
        const id = String(body.orderId || "");
        const current = state.orders[id];
        if (!current?.deliveryId) throw new Error("delivery_id_required");
        const cancelled = await client.cancelDelivery({
          deliveryId: current.deliveryId,
          cityId: current.cityId,
          reason: "custom_pilot_cancelled",
        });
        current.stage = "cancelled";
        current.cancelled = compact(cancelled);
        current.updatedAt = new Date().toISOString();
        persist();
        sendJson(res, 200, { success: true, order: { ...current, payload: undefined } });
        return;
      }
      sendJson(res, 404, { success: false, reason: "not_found" });
    } catch (error) {
      sendJson(res, Number(error.status) || 400, {
        success: false,
        reason: error.reason || error.message || "pilot_request_failed",
      });
    }
  });
}

async function main() {
  const env = loadConfiguration();
  const port = Number(env.PILOT_PORT || 8123);
  const host = env.PILOT_HOST || "127.0.0.1";
  const server = createPilotServer(env);
  server.listen(port, host, () => {
    process.stdout.write(`DUTT custom pilot listening on http://${host}:${port}\n`);
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}

# DUTT Custom Integration Kit

Official server-side integration package for connecting a custom e-commerce website to the existing DUTT merchant backend.

Version: `1.1.0`

## Choose an integration

### Hosted Connector: one-line installation

For stores without a developer or server integration, DUTT can issue an origin-bound installation ID and a private merchant-management link. The store adds one script tag; DUTT hosts the quote form, draft storage, retry protection, and merchant confirmation screen.

```html
<script src="https://dutt.gr/connect/widget.js" data-dutt-installation="dutt_inst_..." async></script>
```

The public widget can request a quote and save a draft only. It cannot dispatch a driver. Dispatch requires the merchant to confirm the real order ID, the exact order total, successful payment, and readiness in the protected DUTT portal. See [Hosted Connector](docs/HOSTED_CONNECTOR.md).

### Advanced Integration: server-side automation

Use the Node.js/PHP kit below when checkout, order state, webhooks, refunds, and merchant-admin actions must be automated inside the store's own system.

## What the advanced kit does

- Requests a DUTT delivery quote during checkout.
- Registers the merchant order without dispatching a driver.
- Dispatches only after the merchant marks the order ready.
- Synchronizes delivery status through signed webhooks.
- Supports status lookup, cancellation, location management, and refund notices.
- Uses the same pricing, dispatch, settlement, fiscal, and merchant-access policies as the DUTT WooCommerce integration.

This package does not create a second DUTT backend and does not contain pricing or accounting logic. Those rules remain in the common DUTT backend.

## Supported server stacks

- Node.js 18 or newer: `packages/node`
- PHP 8.1 or newer with cURL and JSON: `packages/php`
- Any other backend can use `openapi/dutt-merchant-api.json` directly.

Do not call the advanced DUTT merchant API directly from browser JavaScript. The Hosted Connector is the only browser-facing integration and never exposes a merchant key or webhook secret.

## Installation overview

1. DUTT creates a merchant and issues a unique merchant key.
2. The developer stores credentials in the website secret manager or environment.
3. The merchant explicitly accepts the current merchant agreement and privacy/DPA versions.
4. The developer runs the connection test.
5. Checkout calls `quote` and stores the complete accepted quote snapshot.
6. Order creation calls `createOrder`; the order remains `merchant_preparing`.
7. The merchant action "Ready for DUTT pickup" calls `markReady`.
8. Signed webhooks update the local order state. Status lookup is the fallback.
9. The production checklist and end-to-end test are completed before activation.

For one-line installation, start with [Hosted Connector](docs/HOSTED_CONNECTOR.md). For advanced server-side integration, start with [Installation](docs/INSTALLATION.md), then follow [Credential Operations](docs/CREDENTIAL_OPERATIONS.md), [API Workflow](docs/API_WORKFLOW.md), and [Production Checklist](docs/PRODUCTION_CHECKLIST.md).

## Production endpoint

`https://us-central1-sendygo-cd034.cloudfunctions.net`

All requests use the header:

```text
X-DUTT-Merchant-Key: dutt_live_...
```

## Critical policies

- Integration source is always `custom`.
- Currency is `EUR` and pickup/delivery country is Greece (`GR`).
- Cash on delivery is disabled for custom/plugin orders.
- Customer checkout, customer payment, VAT, and customer-facing documents remain the merchant website's responsibility.
- DUTT invoices the merchant for completed/chargeable delivery services under the common merchant billing flow.
- Merchant keys and webhook secrets must never be committed or sent to the browser.

## Package layout

```text
openapi/              OpenAPI 3.1 contract
packages/node/        Node.js server adapter
packages/php/         PHP server adapter
examples/             Minimal integration examples
scripts/              Safe smoke and release scripts
docs/                 Installation, workflow, security, fiscal, and go-live guides
```

## Distribution

The repository is private. Partners receive a versioned ZIP or a repository release. Merchant credentials are issued separately per merchant and are never included in the package.

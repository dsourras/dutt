import {
  DuttMerchantClient,
  buildOrderPayload,
  createIntegrationContext,
} from "../../packages/node/src/index.js";

const client = new DuttMerchantClient({
  merchantKey: process.env.DUTT_MERCHANT_KEY,
});

// Load these values from the merchant's protected integration settings.
const context = createIntegrationContext({
  siteUrl: process.env.DUTT_SITE_URL,
  acceptedAt: process.env.DUTT_MERCHANT_ACCEPTED_AT,
  merchantBilling: JSON.parse(process.env.DUTT_MERCHANT_BILLING_JSON || "{}"),
  store: JSON.parse(process.env.DUTT_STORE_JSON || "{}"),
});

export async function quoteForCheckout(localOrder) {
  const payload = buildOrderPayload({
    context,
    externalOrderId: localOrder.id,
    delivery: localOrder.delivery,
    order: {
      total: localOrder.total,
      cart_subtotal: localOrder.subtotal,
      payment_method: localOrder.paymentMethod,
    },
    items: localOrder.items,
    customer: localOrder.customer,
    chargePolicy: localOrder.duttChargePolicy,
  });
  return client.quote(payload);
}

export async function registerPreparedOrder(localOrder, acceptedQuote) {
  const payload = buildOrderPayload({
    context,
    externalOrderId: localOrder.id,
    delivery: localOrder.delivery,
    order: {
      total: localOrder.total,
      cart_subtotal: localOrder.subtotal,
      payment_method: localOrder.paymentMethod,
    },
    items: localOrder.items,
    customer: localOrder.customer,
    chargePolicy: localOrder.duttChargePolicy,
    quote: acceptedQuote,
  });
  return client.createOrder(payload);
}

export async function markOrderReady(localOrderId) {
  return client.markReady({
    site_url: context.site_url,
    external_order_id: String(localOrderId),
  });
}

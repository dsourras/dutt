# Proprietary License

Copyright (c) 2026 Oryn Technologies / DUTT. All rights reserved.

This integration kit is provided only to authorized DUTT merchants and implementation partners. No right is granted to publish, sublicense, redistribute, reverse engineer, or use the package outside an approved DUTT integration without prior written permission.

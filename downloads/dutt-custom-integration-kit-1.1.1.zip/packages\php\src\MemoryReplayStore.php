<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

final class MemoryReplayStore implements ReplayStore
{
    private array $events = [];

    public function has(string $eventId): bool
    {
        return array_key_exists($eventId, $this->events);
    }

    public function put(string $eventId, int $timestamp): void
    {
        $this->events[$eventId] = $timestamp;
    }
}

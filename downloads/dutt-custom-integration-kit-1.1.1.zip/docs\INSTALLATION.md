# Installation

## 1. Merchant onboarding by DUTT

DUTT creates one merchant record per business and issues one unique merchant key. Keys can be rotated or revoked without affecting other merchants.

The merchant must provide:

- Legal name
- Nine-digit Greek VAT number (AFM)
- Tax office (DOY)
- Billing address, city, postcode, and email
- Primary pickup location and contact phone
- Website URL

The merchant must explicitly accept:

- Merchant agreement: `dutt-merchant-agreement-v1.0-2026-08-02`
- Privacy/DPA: `dutt-privacy-dpa-v1.0-2026-08-02`

Record the real acceptance timestamp. Do not generate an acceptance without the merchant's action.

## 2. Install the adapter

### Node.js

Copy `packages/node` into the server project or install the released package archive, then import:

```js
import {
  DuttMerchantClient,
  createIntegrationContext,
} from "@dutt/custom-integration";
```

### PHP

Copy `packages/php` into the server project or install the released Composer package. With Composer autoloading:

```php
use Dutt\CustomIntegration\DuttMerchantClient;
use Dutt\CustomIntegration\IntegrationContext;
```

## 3. Configure server secrets

Use a secret manager or server environment variables:

```text
DUTT_API_BASE_URL=https://us-central1-sendygo-cd034.cloudfunctions.net
DUTT_MERCHANT_KEY=dutt_live_...
DUTT_WEBHOOK_SECRET=<at least 32 random bytes>
```

Never place these values in HTML, frontend bundles, mobile apps, logs, screenshots, support tickets, or source control.

## 4. Run the safe connection test

The root smoke test performs only a connection test by default. It does not create an order, dispatch a driver, or call quote-related Maps APIs.

```powershell
Copy-Item .env.example .env
# Fill the real merchant values in .env
node scripts/smoke-test.mjs --env .env
```

Use `--quote` only after the pickup and delivery test addresses are configured. Use order creation and dispatch flags only in an approved test account.

## 5. Add the website integration points

- Checkout shipping-rate calculation: `quote`
- Successful local order creation: `createOrder`
- Merchant admin action: `markReady`
- Merchant cancellation: `cancelDelivery`
- Delivery status: signed webhook plus `getStatus` fallback
- Refund/correction: `refundNotice`

The local database must store the DUTT quote ID, quote snapshot, external order ID, DUTT delivery ID, city ID, current status, and processed webhook event IDs.

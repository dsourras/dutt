# Fiscal and Payment Policy

This document describes the integration contract implemented by the common DUTT backend. It does not replace the merchant's statutory accounting obligations.

## Customer transaction

The custom website owns the customer checkout and payment. It records the customer shipping charge in its own order and tax system and issues the customer-facing sales/shipping document.

DUTT does not issue a separate customer receipt for a custom/plugin order.

## Merchant billing

DUTT records the value of completed or otherwise chargeable delivery services. The common merchant billing flow issues the merchant's B2B invoice for the full amount due to DUTT, including the applicable VAT treatment and payment flow.

The integration must store and transmit the quote charge split without recomputing it:

- Customer charge
- Merchant/store contribution
- Net value
- VAT value
- Total merchant amount due to DUTT

## Cancellation and correction

- Cancellation before a chargeable delivery stage removes the delivery according to the common cancellation policy.
- A later correction/refund is reported to DUTT and may create a related credit adjustment or manual review.
- The custom website must never edit DUTT ledgers, invoices, settlements, refunds, or tax fields directly.

## Cash on delivery

COD is disabled for custom/plugin orders until a dedicated collection and remittance flow is approved and implemented. The website must offer only supported prepaid methods for the delivery flow.

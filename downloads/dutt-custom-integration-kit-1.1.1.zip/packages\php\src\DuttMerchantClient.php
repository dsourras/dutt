<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

use InvalidArgumentException;
use JsonException;

final class DuttMerchantClient
{
    public const DEFAULT_BASE_URL = 'https://us-central1-sendygo-cd034.cloudfunctions.net';

    private const ENDPOINTS = [
        'connectionTest' => 'duttMerchantConnectionTest',
        'quote' => 'duttMerchantQuote',
        'createOrder' => 'duttMerchantCreateOrder',
        'markReady' => 'duttMerchantMarkReady',
        'cancelDelivery' => 'duttMerchantCancelDelivery',
        'getStatus' => 'duttMerchantGetStatus',
        'listDeliveries' => 'duttMerchantListDeliveries',
        'listLocations' => 'duttMerchantListLocations',
        'upsertLocation' => 'duttMerchantUpsertLocation',
        'registerWebhook' => 'duttMerchantRegisterWebhook',
        'refundNotice' => 'duttMerchantRefundNotice',
    ];

    private string $merchantKey;
    private string $baseUrl;
    private int $timeoutSeconds;
    private $transport;

    public function __construct(
        string $merchantKey,
        string $baseUrl = self::DEFAULT_BASE_URL,
        int $timeoutSeconds = 15,
        ?callable $transport = null,
    ) {
        $this->merchantKey = trim($merchantKey);
        if ($this->merchantKey === '') {
            throw new InvalidArgumentException('merchantKey is required');
        }
        $this->baseUrl = rtrim(trim($baseUrl), '/');
        $parts = parse_url($this->baseUrl);
        $host = strtolower((string) ($parts['host'] ?? ''));
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        if ($scheme !== 'https' && !in_array($host, ['localhost', '127.0.0.1'], true)) {
            throw new InvalidArgumentException('baseUrl must use HTTPS');
        }
        if ($timeoutSeconds < 1) {
            throw new InvalidArgumentException('timeoutSeconds must be positive');
        }
        $this->timeoutSeconds = $timeoutSeconds;
        $this->transport = $transport;
    }

    public function connectionTest(array $payload): array
    {
        $payload = IntegrationContext::customPayload($payload);
        IntegrationContext::assertContext($payload);
        return $this->request('connectionTest', 'POST', $payload);
    }

    public function quote(array $payload): array
    {
        $payload = IntegrationContext::customPayload($payload);
        IntegrationContext::assertContext($payload);
        IntegrationContext::assertPayloadPrepaid($payload);
        return $this->request('quote', 'POST', $payload);
    }

    public function createOrder(array $payload): array
    {
        $payload = IntegrationContext::customPayload($payload);
        IntegrationContext::assertContext($payload);
        IntegrationContext::assertPayloadPrepaid($payload);
        $this->requiredText($payload['external_order_id'] ?? null, 'external_order_id');
        return $this->request('createOrder', 'POST', $payload);
    }

    public function markReady(array $identity): array
    {
        $payload = IntegrationContext::customPayload($identity);
        $this->requiredText($payload['external_order_id'] ?? null, 'external_order_id');
        $this->requiredText($payload['site_url'] ?? null, 'site_url');
        return $this->request('markReady', 'POST', $payload);
    }

    public function cancelDelivery(
        string $deliveryId,
        string $cityId = '',
        string $reason = 'cancelled_by_merchant'
    ): array {
        return $this->request('cancelDelivery', 'POST', IntegrationContext::customPayload([
            'delivery_id' => $this->requiredText($deliveryId, 'deliveryId'),
            'city_id' => trim($cityId),
            'reason' => trim($reason) ?: 'cancelled_by_merchant',
        ]));
    }

    public function getStatus(array $identity): array
    {
        $deliveryId = trim((string) ($identity['delivery_id'] ?? ''));
        $externalOrderId = trim((string) ($identity['external_order_id'] ?? ''));
        if ($deliveryId === '' && $externalOrderId === '') {
            throw new InvalidArgumentException('delivery_id or external_order_id is required');
        }
        if ($deliveryId === '') {
            $this->requiredText($identity['site_url'] ?? null, 'site_url');
        }
        return $this->request(
            'getStatus',
            'POST',
            IntegrationContext::customPayload($identity)
        );
    }

    public function listDeliveries(int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        return $this->request('listDeliveries', 'GET', [], ['limit' => $limit]);
    }

    public function listLocations(): array
    {
        return $this->request('listLocations', 'GET');
    }

    public function upsertLocation(array $location, bool $makeDefault = false): array
    {
        $location['id'] = $this->requiredText(
            $location['id'] ?? $location['location_id'] ?? null,
            'location.id'
        );
        $location['name'] = $this->requiredText($location['name'] ?? null, 'location.name');
        $location['address'] = $this->requiredText(
            $location['address'] ?? null,
            'location.address'
        );
        $location['city'] = $this->requiredText($location['city'] ?? null, 'location.city');
        $location['country'] = 'GR';
        return $this->request('upsertLocation', 'POST', [
            'location' => $location,
            'default' => $makeDefault,
        ]);
    }

    public function registerWebhook(string $url, string $secret, array $events = []): array
    {
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') {
            throw new InvalidArgumentException('Webhook URL must use HTTPS');
        }
        if (strlen($secret) < 16) {
            throw new InvalidArgumentException('Webhook secret must be at least 16 characters');
        }
        if ($events === []) {
            $events = [
                'delivery.accepted',
                'delivery.approaching_pickup',
                'delivery.picked_up',
                'delivery.delivered',
                'delivery.cancelled',
                'delivery.failed',
                'delivery.returning',
                'delivery.returned',
            ];
        }
        return $this->request('registerWebhook', 'POST', [
            'url' => $url,
            'secret' => $secret,
            'events' => array_values(array_unique(array_filter(array_map('trim', $events)))),
        ]);
    }

    public function refundNotice(array $payload): array
    {
        $payload = IntegrationContext::customPayload($payload);
        $payload['currency'] = 'EUR';
        $this->requiredText($payload['external_order_id'] ?? null, 'external_order_id');
        $this->requiredText($payload['refund_id'] ?? null, 'refund_id');
        if (!is_numeric($payload['amount'] ?? null) || (float) $payload['amount'] < 0) {
            throw new InvalidArgumentException('amount must be a non-negative number');
        }
        return $this->request('refundNotice', 'POST', $payload);
    }

    private function request(
        string $endpoint,
        string $method = 'POST',
        array $body = [],
        array $query = []
    ): array {
        $path = self::ENDPOINTS[$endpoint] ?? null;
        if ($path === null) {
            throw new InvalidArgumentException('Unknown DUTT endpoint: ' . $endpoint);
        }
        $url = $this->baseUrl . '/' . $path;
        if ($query !== []) {
            $url .= '?' . http_build_query($query);
        }
        $headers = [
            'Accept: application/json',
            'X-DUTT-Merchant-Key: ' . $this->merchantKey,
        ];
        $encodedBody = '';
        if ($method !== 'GET') {
            $headers[] = 'Content-Type: application/json';
            try {
                $encodedBody = json_encode($body, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
            } catch (JsonException $error) {
                throw new InvalidArgumentException('Request payload cannot be encoded', 0, $error);
            }
        }

        $transport = $this->transport;
        $result = $transport !== null
            ? $transport($url, $method, $headers, $encodedBody, $this->timeoutSeconds)
            : $this->curlTransport($url, $method, $headers, $encodedBody);
        $status = (int) ($result['status'] ?? 0);
        $raw = (string) ($result['body'] ?? '');
        try {
            $data = $raw === '' ? [] : json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new DuttApiException(
                'DUTT returned a non-JSON response (' . $status . ')',
                $status,
                'invalid_json_response'
            );
        }
        if (!is_array($data)) {
            $data = [];
        }
        if ($status < 200 || $status >= 300 || ($data['success'] ?? null) === false) {
            $reason = trim((string) (
                $data['reason'] ?? $data['error'] ?? 'request_failed'
            ));
            throw new DuttApiException(
                'DUTT request failed (' . $status . '): ' . $reason,
                $status,
                $reason,
                $data
            );
        }
        return $data;
    }

    private function curlTransport(
        string $url,
        string $method,
        array $headers,
        string $body
    ): array {
        if (!function_exists('curl_init')) {
            throw new DuttApiException('PHP cURL extension is required', 0, 'curl_unavailable');
        }
        $curl = curl_init($url);
        if ($curl === false) {
            throw new DuttApiException('Unable to initialize cURL', 0, 'curl_init_failed');
        }
        curl_setopt_array($curl, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => min(5, $this->timeoutSeconds),
            CURLOPT_TIMEOUT => $this->timeoutSeconds,
        ]);
        if ($method !== 'GET') {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
        }
        $responseBody = curl_exec($curl);
        if ($responseBody === false) {
            $message = curl_error($curl);
            $code = curl_errno($curl);
            curl_close($curl);
            throw new DuttApiException(
                'DUTT request failed: ' . $message,
                0,
                $code === CURLE_OPERATION_TIMEDOUT ? 'request_timeout' : 'network_error'
            );
        }
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);
        return ['status' => $status, 'body' => $responseBody];
    }

    private function requiredText(mixed $value, string $field): string
    {
        $result = trim((string) ($value ?? ''));
        if ($result === '') {
            throw new InvalidArgumentException($field . ' is required');
        }
        return $result;
    }
}

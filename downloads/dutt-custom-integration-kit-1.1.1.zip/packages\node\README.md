# DUTT Node.js Adapter

Requires Node.js 18 or newer. The package has no runtime dependencies.

```js
import {
  DuttMerchantClient,
  buildOrderPayload,
  createIntegrationContext,
} from "@dutt/custom-integration";

const client = new DuttMerchantClient({
  merchantKey: process.env.DUTT_MERCHANT_KEY,
});

const context = createIntegrationContext({
  siteUrl: "https://shop.example.gr",
  acceptedAt: "2026-08-11T10:00:00.000Z",
  merchantBilling: {
    legal_name: "Example IKE",
    vat_number: "123456789",
    tax_office: "DOY Larissas",
    billing_address: "Example 1",
    billing_city: "Larissa",
    billing_postcode: "41222",
    billing_email: "billing@example.gr"
  },
  store: {
    name: "Example Store",
    address: "Example 1",
    city: "Larissa",
    postcode: "41222",
    phone: "2410000000"
  }
});
```

Use the real merchant acceptance timestamp. Never accept legal terms programmatically on behalf of a merchant.

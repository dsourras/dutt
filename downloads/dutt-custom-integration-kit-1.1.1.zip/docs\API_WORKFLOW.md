# API Workflow

## 1. Connection test

Call `duttMerchantConnectionTest` from the website backend. The payload must include fiscal information, explicit legal acceptance, `EUR`, and `GR` market validation.

Do this during onboarding and after changing merchant credentials or fiscal data. Do not run it on every checkout.

## 2. Checkout quote

Call `duttMerchantQuote` when the customer supplies a complete delivery address. Store the complete quote response with the local checkout/order.

Important response fields include:

- `quote_id` and `quote_expires_at`
- `quote_price`, net value, VAT, and currency
- `customer_charge` and `store_contribution`
- `merchant_due_to_dutt`
- `distance_km`, estimated time, and city ID
- pickup and delivery coordinates
- fiscal billing model fields

Do not recalculate or reinterpret DUTT pricing in the custom website.

## 3. Create the merchant order

After the website has successfully created its own order, call `duttMerchantCreateOrder` with the stable local order ID and the accepted quote/order data.

The DUTT response is `merchant_preparing`. No driver is dispatched at this point.

The idempotency identity is the combination of merchant, website URL, and external order ID. Retrying the same request must use the same values.

## 4. Mark ready

Add one clear merchant-admin action: "Ready for DUTT pickup". The action calls `duttMerchantMarkReady` with the same `site_url` and `external_order_id`.

Only this call creates the live DUTT delivery and starts dispatch. Store the returned:

- `delivery_id` / `dutt_order_id`
- `city_id`
- `status`
- `tracking_url`
- merchant/pickup reference

Disable repeated UI clicks while the request is in progress. A retry with the same identity is idempotent.

## 5. Status synchronization

Register a public HTTPS webhook with `duttMerchantRegisterWebhook`. Verify every request before processing it.

Subscribed delivery events:

- `delivery.accepted`
- `delivery.approaching_pickup`
- `delivery.picked_up`
- `delivery.delivered`
- `delivery.cancelled`
- `delivery.failed`
- `delivery.returning`
- `delivery.returned`

Return a successful HTTP response quickly. DUTT retries failed deliveries after approximately 5 minutes, 30 minutes, and 2 hours, with a maximum of four attempts.

Use `duttMerchantGetStatus` after a webhook gap or during reconciliation. Do not create a permanent polling loop.

## 6. Cancellation and refunds

Before dispatch, cancel the local prepared order according to the website workflow. After a DUTT delivery exists, call `duttMerchantCancelDelivery` with the DUTT delivery ID and city ID.

Report a later e-commerce refund through `duttMerchantRefundNotice`. The common backend decides whether the delivery adjustment is automatic or requires review. The custom website must not mutate DUTT settlement data directly.

## 7. Payment methods

Custom/plugin orders must be prepaid. Do not send cash, COD, cash-on-delivery, or recipient-cash payment methods. The common backend rejects COD for source `custom`.

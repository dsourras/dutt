import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { after, before, test } from "node:test";
import http from "node:http";

import {
  DuttApiError,
  DuttMerchantClient,
  DuttWebhookError,
  DEFAULT_TIMEOUT_MS,
  MemoryReplayStore,
  buildOrderPayload,
  createIntegrationContext,
  handleDuttWebhook,
  verifyDuttWebhook,
} from "../src/index.js";

test("production client timeout covers cold starts", () => {
  const client = new DuttMerchantClient({ merchantKey: "dutt_live_test" });
  assert.equal(DEFAULT_TIMEOUT_MS, 90000);
  assert.equal(client.timeoutMs, DEFAULT_TIMEOUT_MS);
});

let server;
let baseUrl;
const requests = [];

before(async () => {
  server = http.createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      requests.push({
        url: request.url,
        method: request.method,
        headers: request.headers,
        body: raw ? JSON.parse(raw) : null,
      });
      if (request.url.startsWith("/duttMerchantCancelDelivery")) {
        response.writeHead(409, { "content-type": "application/json" });
        response.end(JSON.stringify({ success: false, reason: "cannot_cancel_terminal_status" }));
        return;
      }
      if (request.url.startsWith("/duttMerchantGetStatus")) {
        setTimeout(() => {
          response.writeHead(200, { "content-type": "application/json" });
          response.end(JSON.stringify({ success: true, status: "delivered" }));
        }, 60);
        return;
      }
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ success: true, status: "ok" }));
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  baseUrl = `http://127.0.0.1:${address.port}`;
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

function context() {
  return createIntegrationContext({
    siteUrl: "https://shop.example.gr",
    acceptedAt: "2026-08-11T10:00:00.000Z",
    merchantBilling: {
      legal_name: "Example IKE",
      vat_number: "123456789",
      tax_office: "DOY Larissas",
      billing_address: "Example 1",
      billing_city: "Larissa",
      billing_postcode: "41222",
      billing_email: "billing@example.gr",
    },
    store: {
      name: "Example Store",
      address: "Example 1",
      city: "Larissa",
      postcode: "41222",
      phone: "2410000000",
    },
  });
}

function orderPayload(paymentMethod = "card") {
  return buildOrderPayload({
    context: context(),
    externalOrderId: "ORDER-100",
    delivery: {
      name: "Customer",
      phone: "6900000000",
      address: "Delivery 1",
      city: "Larissa",
      postcode: "41222",
    },
    order: {
      total: 25,
      payment_method: paymentMethod,
    },
    items: [{ name: "Item", quantity: 1, price: 25, total: 25 }],
  });
}

test("context contains the mandatory production policy", () => {
  const value = context();
  assert.equal(value.source, "custom");
  assert.equal(value.currency, "EUR");
  assert.equal(value.integration_market.store_country, "GR");
  assert.equal(value.merchant_legal.merchant_agreement.accepted, true);
});

test("invalid fiscal profile is rejected before a request", () => {
  assert.throws(
    () => createIntegrationContext({
      siteUrl: "https://shop.example.gr",
      acceptedAt: "2026-08-11T10:00:00.000Z",
      merchantBilling: {
        legal_name: "Example",
        vat_number: "123",
        tax_office: "DOY",
        billing_address: "A",
        billing_city: "B",
        billing_postcode: "1",
        billing_email: "a@example.gr",
      },
      store: { name: "S", address: "A", city: "B", phone: "1" },
    }),
    /exactly 9 digits/,
  );
});

test("handwritten payload cannot bypass legal policy validation", () => {
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl: "http://127.0.0.1:9999",
  });
  const payload = context();
  payload.merchant_legal.merchant_agreement.version = "old-version";
  assert.throws(() => client.connectionTest(payload), /merchant_agreement.version/);
});

test("COD is rejected locally", () => {
  assert.throws(() => orderPayload("cash_on_delivery"), /Cash on delivery/);
});

test("client sends the merchant key server-side and forces custom source", async () => {
  const client = new DuttMerchantClient({ merchantKey: "dutt_live_test", baseUrl });
  await client.createOrder({ ...orderPayload(), source: "custom_api" });
  const request = requests.at(-1);
  assert.equal(request.headers["x-dutt-merchant-key"], "dutt_live_test");
  assert.equal(request.body.source, "custom");
  assert.equal(request.body.channel, "custom");
  assert.equal(request.body.integration, "custom");
});

test("API errors retain status and reason", async () => {
  const client = new DuttMerchantClient({ merchantKey: "dutt_live_test", baseUrl });
  await assert.rejects(
    client.cancelDelivery({ deliveryId: "DEL-1" }),
    (error) => error instanceof DuttApiError &&
      error.status === 409 &&
      error.reason === "cannot_cancel_terminal_status",
  );
});

test("request timeout is explicit", async () => {
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl,
    timeoutMs: 10,
  });
  await assert.rejects(
    client.getStatus({ deliveryId: "DEL-1" }),
    (error) => error instanceof DuttApiError && error.reason === "request_timeout",
  );
});

function signedWebhook({ body, secret, timestamp, event = "delivery.delivered", eventId = "evt-1" }) {
  const signature = `sha256=${createHmac("sha256", secret)
    .update(`${timestamp}.${body}`, "utf8")
    .digest("hex")}`;
  return {
    "x-dutt-event": event,
    "x-dutt-event-id": eventId,
    "x-dutt-signature": signature,
    "x-dutt-timestamp": String(timestamp),
  };
}

test("valid webhook signature is accepted", () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "evt-1" });
  const result = verifyDuttWebhook({
    rawBody: body,
    headers: signedWebhook({ body, secret, timestamp }),
    secret,
    nowSeconds: timestamp,
  });
  assert.equal(result.eventId, "evt-1");
});

test("tampered and stale webhooks are rejected", () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "evt-1" });
  const headers = signedWebhook({ body, secret, timestamp });
  assert.throws(
    () => verifyDuttWebhook({ rawBody: `${body} `, headers, secret, nowSeconds: timestamp }),
    (error) => error instanceof DuttWebhookError && error.code === "invalid_signature",
  );
  assert.throws(
    () => verifyDuttWebhook({ rawBody: body, headers, secret, nowSeconds: timestamp + 301 }),
    (error) => error instanceof DuttWebhookError && error.code === "stale_timestamp",
  );
});

test("webhook handler processes an event once", async () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "evt-2" });
  const headers = signedWebhook({ body, secret, timestamp, eventId: "evt-2" });
  const store = new MemoryReplayStore();
  let count = 0;
  const options = {
    rawBody: body,
    headers,
    secret,
    replayStore: store,
    nowSeconds: timestamp,
    onEvent: async () => { count += 1; },
  };
  const first = await handleDuttWebhook(options);
  const second = await handleDuttWebhook(options);
  assert.equal(first.processed, true);
  assert.equal(second.duplicate, true);
  assert.equal(count, 1);
});

test("failed webhook processing is not marked as processed", async () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "evt-3" });
  const headers = signedWebhook({ body, secret, timestamp, eventId: "evt-3" });
  const store = new MemoryReplayStore();
  await assert.rejects(handleDuttWebhook({
    rawBody: body,
    headers,
    secret,
    replayStore: store,
    nowSeconds: timestamp,
    onEvent: async () => { throw new Error("database unavailable"); },
  }));
  assert.equal(await store.has("evt-3"), false);
});

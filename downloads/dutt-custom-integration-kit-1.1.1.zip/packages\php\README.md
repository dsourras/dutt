# DUTT PHP Adapter

Requires PHP 8.1 or newer with cURL and JSON.

```php
use Dutt\CustomIntegration\DuttMerchantClient;
use Dutt\CustomIntegration\IntegrationContext;

$client = new DuttMerchantClient($_ENV['DUTT_MERCHANT_KEY']);

$context = IntegrationContext::create([
    'site_url' => 'https://shop.example.gr',
    'accepted_at' => '2026-08-11T10:00:00.000Z',
    'merchant_billing' => [
        'legal_name' => 'Example IKE',
        'vat_number' => '123456789',
        'tax_office' => 'DOY Larissas',
        'billing_address' => 'Example 1',
        'billing_city' => 'Larissa',
        'billing_postcode' => '41222',
        'billing_email' => 'billing@example.gr',
    ],
    'store' => [
        'name' => 'Example Store',
        'address' => 'Example 1',
        'city' => 'Larissa',
        'postcode' => '41222',
        'phone' => '2410000000',
    ],
]);
```

The adapter is server-side only. Use the real merchant acceptance timestamp and never expose the merchant key or webhook secret to browser code.

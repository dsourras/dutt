import {
  createHmac,
  timingSafeEqual,
} from "node:crypto";

export const DEFAULT_BASE_URL =
  "https://us-central1-sendygo-cd034.cloudfunctions.net";
export const DEFAULT_TIMEOUT_MS = 90000;

export const MERCHANT_AGREEMENT_VERSION =
  "dutt-merchant-agreement-v1.0-2026-08-02";
export const PRIVACY_DPA_VERSION =
  "dutt-privacy-dpa-v1.0-2026-08-02";

export const DEFAULT_WEBHOOK_EVENTS = Object.freeze([
  "delivery.accepted",
  "delivery.approaching_pickup",
  "delivery.picked_up",
  "delivery.delivered",
  "delivery.cancelled",
  "delivery.failed",
  "delivery.returning",
  "delivery.returned",
]);

const POLICY_EFFECTIVE_AT = Date.parse("2026-08-02T00:00:00.000Z");
const MAX_ACCEPTANCE_FUTURE_SKEW_MS = 5 * 60 * 1000;
const COD_METHODS = new Set([
  "cash",
  "cod",
  "cash_on_delivery",
  "cashondelivery",
  "pay_on_delivery",
]);

const ENDPOINTS = Object.freeze({
  connectionTest: "duttMerchantConnectionTest",
  quote: "duttMerchantQuote",
  createOrder: "duttMerchantCreateOrder",
  markReady: "duttMerchantMarkReady",
  cancelDelivery: "duttMerchantCancelDelivery",
  getStatus: "duttMerchantGetStatus",
  listDeliveries: "duttMerchantListDeliveries",
  listLocations: "duttMerchantListLocations",
  upsertLocation: "duttMerchantUpsertLocation",
  registerWebhook: "duttMerchantRegisterWebhook",
  refundNotice: "duttMerchantRefundNotice",
});

function text(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

function requiredText(value, field) {
  const result = text(value);
  if (!result) throw new TypeError(`${field} is required`);
  return result;
}

function normalizeBaseUrl(value) {
  const url = new URL(requiredText(value, "baseUrl"));
  if (url.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(url.hostname)) {
    throw new TypeError("baseUrl must use HTTPS");
  }
  return url.toString().replace(/\/+$/, "");
}

function normalizeSiteUrl(value) {
  const url = new URL(requiredText(value, "siteUrl"));
  if (url.protocol !== "https:") throw new TypeError("siteUrl must use HTTPS");
  return url.toString().replace(/\/+$/, "");
}

function normalizePaymentMethod(value) {
  return text(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function assertPrepaid(payload) {
  const order = payload?.order && typeof payload.order === "object" ? payload.order : {};
  const payment = payload?.payment && typeof payload.payment === "object" ? payload.payment : {};
  const candidates = [
    order.payment_method,
    order.paymentMethod,
    payload?.payment_method,
    payload?.paymentMethod,
    payment.method,
    payment.type,
  ];
  for (const candidate of candidates) {
    if (COD_METHODS.has(normalizePaymentMethod(candidate))) {
      throw new TypeError("Cash on delivery is disabled for DUTT custom integrations");
    }
  }
}

function customPayload(payload = {}) {
  return {
    ...payload,
    source: "custom",
    channel: "custom",
    integration: "custom",
  };
}

function assertMerchantContext(payload) {
  if (!payload || typeof payload !== "object") {
    throw new TypeError("payload must be an object");
  }
  normalizeSiteUrl(payload.site_url);
  if (payload.currency !== "EUR") throw new TypeError("currency must be EUR");
  if (payload.integration_market?.currency !== "EUR") {
    throw new TypeError("integration_market.currency must be EUR");
  }
  if (
    payload.integration_market?.store_country !== "GR" ||
    payload.integration_market?.delivery_country !== "GR"
  ) {
    throw new TypeError("integration market countries must be GR");
  }
  assertLegalAcceptance(
    payload.merchant_legal?.merchant_agreement,
    MERCHANT_AGREEMENT_VERSION,
    "merchant_legal.merchant_agreement",
  );
  assertLegalAcceptance(
    payload.merchant_legal?.privacy_dpa,
    PRIVACY_DPA_VERSION,
    "merchant_legal.privacy_dpa",
  );
  requiredText(payload.merchant_billing?.legal_name, "merchant_billing.legal_name");
  if (!/^\d{9}$/.test(text(payload.merchant_billing?.vat_number))) {
    throw new TypeError("merchant_billing.vat_number must contain exactly 9 digits");
  }
  requiredText(payload.merchant_billing?.tax_office, "merchant_billing.tax_office");
  requiredText(payload.merchant_billing?.billing_address, "merchant_billing.billing_address");
  requiredText(payload.merchant_billing?.billing_city, "merchant_billing.billing_city");
  requiredText(payload.merchant_billing?.billing_postcode, "merchant_billing.billing_postcode");
  const billingEmail = requiredText(
    payload.merchant_billing?.billing_email,
    "merchant_billing.billing_email",
  );
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(billingEmail)) {
    throw new TypeError("merchant_billing.billing_email must be valid");
  }
  requiredText(payload.store?.name, "store.name");
  requiredText(payload.store?.address, "store.address");
  requiredText(payload.store?.city, "store.city");
  requiredText(payload.store?.phone, "store.phone");
  if (payload.store?.country !== "GR") throw new TypeError("store.country must be GR");
}

function assertLegalAcceptance(value, expectedVersion, field) {
  if (!value || typeof value !== "object" || value.accepted !== true) {
    throw new TypeError(`${field}.accepted must be true`);
  }
  if (text(value.version) !== expectedVersion) {
    throw new TypeError(`${field}.version must be ${expectedVersion}`);
  }
  const acceptedAt = requiredText(value.accepted_at ?? value.acceptedAt, `${field}.accepted_at`);
  const timestamp = Date.parse(acceptedAt);
  if (
    !Number.isFinite(timestamp) ||
    timestamp < POLICY_EFFECTIVE_AT ||
    timestamp > Date.now() + MAX_ACCEPTANCE_FUTURE_SKEW_MS
  ) {
    throw new TypeError(`${field}.accepted_at is invalid`);
  }
}

function canonicalBilling(input = {}) {
  const value = {
    ...input,
    legal_name: requiredText(input.legal_name ?? input.legalName, "merchantBilling.legal_name"),
    vat_number: requiredText(input.vat_number ?? input.vatNumber ?? input.afm, "merchantBilling.vat_number")
      .replace(/\D/g, ""),
    tax_office: requiredText(input.tax_office ?? input.taxOffice ?? input.doy, "merchantBilling.tax_office"),
    billing_address: requiredText(input.billing_address ?? input.billingAddress ?? input.address, "merchantBilling.billing_address"),
    billing_city: requiredText(input.billing_city ?? input.billingCity ?? input.city, "merchantBilling.billing_city"),
    billing_postcode: requiredText(input.billing_postcode ?? input.billingPostcode ?? input.postcode, "merchantBilling.billing_postcode"),
    billing_email: requiredText(input.billing_email ?? input.billingEmail ?? input.email, "merchantBilling.billing_email"),
    business_activity: text(input.business_activity ?? input.businessActivity),
  };
  if (!/^\d{9}$/.test(value.vat_number)) {
    throw new TypeError("merchantBilling.vat_number must contain exactly 9 digits");
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.billing_email)) {
    throw new TypeError("merchantBilling.billing_email must be valid");
  }
  return value;
}

function canonicalStore(input = {}) {
  return {
    ...input,
    name: requiredText(input.name, "store.name"),
    address: requiredText(input.address, "store.address"),
    city: requiredText(input.city, "store.city"),
    postcode: text(input.postcode),
    country: "GR",
    phone: requiredText(input.phone, "store.phone"),
  };
}

export function createIntegrationContext({
  siteUrl,
  acceptedAt,
  merchantBilling,
  store,
  locationId = "",
} = {}) {
  const acceptedAtText = requiredText(acceptedAt, "acceptedAt");
  const acceptedAtMs = Date.parse(acceptedAtText);
  if (
    !Number.isFinite(acceptedAtMs) ||
    acceptedAtMs < POLICY_EFFECTIVE_AT ||
    acceptedAtMs > Date.now() + MAX_ACCEPTANCE_FUTURE_SKEW_MS
  ) {
    throw new TypeError("acceptedAt must be a valid real acceptance timestamp for the current policy");
  }

  const context = customPayload({
    site_url: normalizeSiteUrl(siteUrl),
    currency: "EUR",
    merchant_legal: {
      merchant_agreement: {
        accepted: true,
        version: MERCHANT_AGREEMENT_VERSION,
        accepted_at: acceptedAtText,
      },
      privacy_dpa: {
        accepted: true,
        version: PRIVACY_DPA_VERSION,
        accepted_at: acceptedAtText,
      },
    },
    integration_market: {
      currency: "EUR",
      store_country: "GR",
      delivery_country: "GR",
    },
    merchant_billing: canonicalBilling(merchantBilling),
    store: canonicalStore(store),
  });
  if (text(locationId)) context.location_id = text(locationId);
  assertMerchantContext(context);
  return context;
}

export function buildOrderPayload({
  context,
  externalOrderId,
  delivery,
  order,
  items = [],
  customer = {},
  chargePolicy = { policy: "full_quote" },
  quote = null,
} = {}) {
  assertMerchantContext(context);
  const id = requiredText(externalOrderId, "externalOrderId");
  const cleanDelivery = {
    ...delivery,
    name: requiredText(delivery?.name ?? delivery?.recipient_name, "delivery.name"),
    recipient_name: requiredText(delivery?.recipient_name ?? delivery?.name, "delivery.recipient_name"),
    phone: requiredText(delivery?.phone, "delivery.phone"),
    address: requiredText(delivery?.address, "delivery.address"),
    city: requiredText(delivery?.city, "delivery.city"),
    postcode: text(delivery?.postcode),
    country: "GR",
  };
  const cleanOrder = {
    ...order,
    id,
    order_id: id,
    number: text(order?.number ?? id),
    order_number: text(order?.order_number ?? order?.number ?? id),
    currency: "EUR",
    payment_method: requiredText(order?.payment_method ?? order?.paymentMethod, "order.payment_method"),
    items: Array.isArray(order?.items) && order.items.length ? order.items : items,
  };
  if (!Number.isFinite(Number(cleanOrder.total)) || Number(cleanOrder.total) < 0) {
    throw new TypeError("order.total must be a non-negative number");
  }
  const policy = {
    policy: text(chargePolicy?.policy || "full_quote"),
    ...chargePolicy,
  };
  const payload = customPayload({
    ...context,
    external_order_id: id,
    merchant_order_id: id,
    order_number: cleanOrder.order_number,
    currency: "EUR",
    customer_charge_policy: policy.policy,
    charge_policy: policy,
    cart_subtotal: Number(cleanOrder.cart_subtotal ?? cleanOrder.total),
    cart: {
      subtotal: Number(cleanOrder.cart_subtotal ?? cleanOrder.total),
    },
    customer,
    delivery: cleanDelivery,
    order: cleanOrder,
    items: cleanOrder.items,
  });
  if (quote && typeof quote === "object") payload.quote = quote;
  assertPrepaid(payload);
  return payload;
}

export class DuttApiError extends Error {
  constructor(message, { status = 0, reason = "request_failed", details = null } = {}) {
    super(message);
    this.name = "DuttApiError";
    this.status = status;
    this.reason = reason;
    this.details = details;
  }
}

export class DuttMerchantClient {
  constructor({
    merchantKey,
    baseUrl = DEFAULT_BASE_URL,
    timeoutMs = DEFAULT_TIMEOUT_MS,
    fetchImpl = globalThis.fetch,
  } = {}) {
    this.merchantKey = requiredText(merchantKey, "merchantKey");
    this.baseUrl = normalizeBaseUrl(baseUrl);
    this.timeoutMs = Number(timeoutMs);
    if (!Number.isFinite(this.timeoutMs) || this.timeoutMs < 1) {
      throw new TypeError("timeoutMs must be a positive number");
    }
    if (typeof fetchImpl !== "function") throw new TypeError("A fetch implementation is required");
    this.fetchImpl = fetchImpl;
  }

  async request(endpoint, { method = "POST", body, query = {} } = {}) {
    const path = ENDPOINTS[endpoint];
    if (!path) throw new TypeError(`Unknown DUTT endpoint: ${endpoint}`);
    const url = new URL(`${this.baseUrl}/${path}`);
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && value !== "") {
        url.searchParams.set(key, String(value));
      }
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetchImpl(url, {
        method,
        headers: {
          accept: "application/json",
          ...(method === "GET" ? {} : { "content-type": "application/json" }),
          "X-DUTT-Merchant-Key": this.merchantKey,
        },
        body: method === "GET" ? undefined : JSON.stringify(body ?? {}),
        signal: controller.signal,
      });
      const raw = await response.text();
      let data = {};
      try {
        data = raw ? JSON.parse(raw) : {};
      } catch {
        throw new DuttApiError(`DUTT returned a non-JSON response (${response.status})`, {
          status: response.status,
          reason: "invalid_json_response",
        });
      }
      if (!response.ok || data.success === false) {
        const reason = text(data.reason || data.error || response.statusText || "request_failed");
        throw new DuttApiError(`DUTT request failed (${response.status}): ${reason}`, {
          status: response.status,
          reason,
          details: data,
        });
      }
      return data;
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new DuttApiError("DUTT request timed out", {
          reason: "request_timeout",
        });
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  connectionTest(payload) {
    const body = customPayload(payload);
    assertMerchantContext(body);
    return this.request("connectionTest", { body });
  }

  quote(payload) {
    const body = customPayload(payload);
    assertMerchantContext(body);
    assertPrepaid(body);
    return this.request("quote", { body });
  }

  createOrder(payload) {
    const body = customPayload(payload);
    assertMerchantContext(body);
    assertPrepaid(body);
    requiredText(body.external_order_id, "external_order_id");
    return this.request("createOrder", { body });
  }

  markReady(payload) {
    const body = customPayload(payload);
    requiredText(body.external_order_id, "external_order_id");
    requiredText(body.site_url, "site_url");
    return this.request("markReady", { body });
  }

  cancelDelivery({ deliveryId, cityId = "", reason = "cancelled_by_merchant" } = {}) {
    return this.request("cancelDelivery", {
      body: customPayload({
        delivery_id: requiredText(deliveryId, "deliveryId"),
        city_id: text(cityId),
        reason: text(reason) || "cancelled_by_merchant",
      }),
    });
  }

  getStatus({ deliveryId = "", cityId = "", externalOrderId = "", siteUrl = "" } = {}) {
    if (!text(deliveryId) && !text(externalOrderId)) {
      throw new TypeError("deliveryId or externalOrderId is required");
    }
    const body = customPayload({
      delivery_id: text(deliveryId),
      city_id: text(cityId),
      external_order_id: text(externalOrderId),
      site_url: text(siteUrl),
    });
    if (!body.delivery_id) requiredText(body.site_url, "siteUrl");
    return this.request("getStatus", { body });
  }

  listDeliveries({ limit = 50 } = {}) {
    const value = Math.max(1, Math.min(200, Math.round(Number(limit) || 50)));
    return this.request("listDeliveries", { method: "GET", query: { limit: value } });
  }

  listLocations() {
    return this.request("listLocations", { method: "GET" });
  }

  upsertLocation(location, { makeDefault = false } = {}) {
    const body = {
      location: {
        ...location,
        id: requiredText(location?.id ?? location?.location_id, "location.id"),
        name: requiredText(location?.name, "location.name"),
        address: requiredText(location?.address, "location.address"),
        city: requiredText(location?.city, "location.city"),
        country: "GR",
      },
      default: Boolean(makeDefault),
    };
    return this.request("upsertLocation", { body });
  }

  registerWebhook({ url, secret, events = DEFAULT_WEBHOOK_EVENTS } = {}) {
    const webhookUrl = new URL(requiredText(url, "url"));
    if (webhookUrl.protocol !== "https:") throw new TypeError("Webhook URL must use HTTPS");
    const webhookSecret = requiredText(secret, "secret");
    if (webhookSecret.length < 16) throw new TypeError("Webhook secret must be at least 16 characters");
    return this.request("registerWebhook", {
      body: {
        url: webhookUrl.toString(),
        secret: webhookSecret,
        events: Array.from(new Set(events.map(text).filter(Boolean))),
      },
    });
  }

  refundNotice(payload) {
    const body = customPayload({ ...payload, currency: "EUR" });
    requiredText(body.external_order_id, "external_order_id");
    requiredText(body.refund_id, "refund_id");
    if (!Number.isFinite(Number(body.amount)) || Number(body.amount) < 0) {
      throw new TypeError("amount must be a non-negative number");
    }
    return this.request("refundNotice", { body });
  }
}

function headerValue(headers, name) {
  if (headers && typeof headers.get === "function") return text(headers.get(name));
  const wanted = name.toLowerCase();
  for (const [key, value] of Object.entries(headers || {})) {
    if (key.toLowerCase() === wanted) {
      return Array.isArray(value) ? text(value[0]) : text(value);
    }
  }
  return "";
}

function constantTimeEqual(expected, received) {
  const expectedBuffer = Buffer.from(expected, "utf8");
  const receivedBuffer = Buffer.from(received, "utf8");
  return expectedBuffer.length === receivedBuffer.length &&
    timingSafeEqual(expectedBuffer, receivedBuffer);
}

export class DuttWebhookError extends Error {
  constructor(message, code) {
    super(message);
    this.name = "DuttWebhookError";
    this.code = code;
  }
}

export function verifyDuttWebhook({
  rawBody,
  headers,
  secret,
  toleranceSeconds = 300,
  nowSeconds = Math.floor(Date.now() / 1000),
} = {}) {
  const webhookSecret = requiredText(secret, "secret");
  const timestamp = headerValue(headers, "x-dutt-timestamp");
  const signature = headerValue(headers, "x-dutt-signature");
  const event = headerValue(headers, "x-dutt-event");
  const eventId = headerValue(headers, "x-dutt-event-id");
  if (!timestamp || !signature || !event || !eventId) {
    throw new DuttWebhookError("Missing DUTT webhook headers", "missing_headers");
  }
  if (!/^\d+$/.test(timestamp)) {
    throw new DuttWebhookError("Invalid DUTT webhook timestamp", "invalid_timestamp");
  }
  const timestampNumber = Number(timestamp);
  if (
    !Number.isFinite(timestampNumber) ||
    Math.abs(Number(nowSeconds) - timestampNumber) > Number(toleranceSeconds)
  ) {
    throw new DuttWebhookError("Stale DUTT webhook", "stale_timestamp");
  }
  const body = Buffer.isBuffer(rawBody) ? rawBody.toString("utf8") : String(rawBody ?? "");
  const expected = `sha256=${createHmac("sha256", webhookSecret)
    .update(`${timestamp}.${body}`, "utf8")
    .digest("hex")}`;
  if (!constantTimeEqual(expected, signature)) {
    throw new DuttWebhookError("Invalid DUTT webhook signature", "invalid_signature");
  }
  let payload;
  try {
    payload = JSON.parse(body);
  } catch {
    throw new DuttWebhookError("Invalid DUTT webhook JSON", "invalid_json");
  }
  if (text(payload.event_id) !== eventId || text(payload.event) !== event) {
    throw new DuttWebhookError("DUTT webhook headers do not match the payload", "header_payload_mismatch");
  }
  return {
    event,
    eventId,
    timestamp: timestampNumber,
    payload,
  };
}

export class MemoryReplayStore {
  constructor() {
    this.eventIds = new Set();
  }

  async has(eventId) {
    return this.eventIds.has(eventId);
  }

  async put(eventId) {
    this.eventIds.add(eventId);
  }
}

export async function handleDuttWebhook({
  rawBody,
  headers,
  secret,
  replayStore,
  onEvent,
  toleranceSeconds = 300,
  nowSeconds,
} = {}) {
  if (!replayStore || typeof replayStore.has !== "function" || typeof replayStore.put !== "function") {
    throw new TypeError("replayStore with async has() and put() methods is required");
  }
  if (typeof onEvent !== "function") throw new TypeError("onEvent callback is required");
  const verified = verifyDuttWebhook({
    rawBody,
    headers,
    secret,
    toleranceSeconds,
    ...(nowSeconds === undefined ? {} : { nowSeconds }),
  });
  if (await replayStore.has(verified.eventId)) {
    return { ...verified, duplicate: true, processed: false };
  }
  await onEvent(verified.payload, verified);
  await replayStore.put(verified.eventId, verified.timestamp);
  return { ...verified, duplicate: false, processed: true };
}

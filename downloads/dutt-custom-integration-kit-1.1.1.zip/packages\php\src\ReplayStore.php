<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

interface ReplayStore
{
    public function has(string $eventId): bool;

    public function put(string $eventId, int $timestamp): void;
}

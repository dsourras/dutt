<?php

declare(strict_types=1);

require_once __DIR__ . '/../src/DuttApiException.php';
require_once __DIR__ . '/../src/IntegrationContext.php';
require_once __DIR__ . '/../src/ReplayStore.php';
require_once __DIR__ . '/../src/MemoryReplayStore.php';
require_once __DIR__ . '/../src/WebhookVerifier.php';
require_once __DIR__ . '/../src/DuttMerchantClient.php';

use Dutt\CustomIntegration\DuttApiException;
use Dutt\CustomIntegration\DuttMerchantClient;
use Dutt\CustomIntegration\IntegrationContext;
use Dutt\CustomIntegration\MemoryReplayStore;
use Dutt\CustomIntegration\WebhookVerifier;

$tests = [];

function test(string $name, callable $callback): void
{
    global $tests;
    $tests[] = [$name, $callback];
}

function same(mixed $expected, mixed $actual, string $message = ''): void
{
    if ($expected !== $actual) {
        throw new RuntimeException(
            $message !== '' ? $message : 'Expected ' . var_export($expected, true) .
                ', got ' . var_export($actual, true)
        );
    }
}

function context(): array
{
    return IntegrationContext::create([
        'site_url' => 'https://shop.example.gr',
        'accepted_at' => '2026-08-11T10:00:00.000Z',
        'merchant_billing' => [
            'legal_name' => 'Example IKE',
            'vat_number' => '123456789',
            'tax_office' => 'DOY Larissas',
            'billing_address' => 'Example 1',
            'billing_city' => 'Larissa',
            'billing_postcode' => '41222',
            'billing_email' => 'billing@example.gr',
        ],
        'store' => [
            'name' => 'Example Store',
            'address' => 'Example 1',
            'city' => 'Larissa',
            'postcode' => '41222',
            'phone' => '2410000000',
        ],
    ]);
}

function orderPayload(string $paymentMethod = 'card'): array
{
    return IntegrationContext::buildOrder([
        'context' => context(),
        'external_order_id' => 'ORDER-100',
        'delivery' => [
            'name' => 'Customer',
            'phone' => '6900000000',
            'address' => 'Delivery 1',
            'city' => 'Larissa',
            'postcode' => '41222',
        ],
        'order' => [
            'total' => 25,
            'payment_method' => $paymentMethod,
        ],
        'items' => [['name' => 'Item', 'quantity' => 1, 'price' => 25, 'total' => 25]],
    ]);
}

test('context enforces production policy', function (): void {
    $value = context();
    same('custom', $value['source']);
    same('EUR', $value['currency']);
    same('GR', $value['integration_market']['store_country']);
    same(true, $value['merchant_legal']['merchant_agreement']['accepted']);
});

test('invalid VAT is rejected', function (): void {
    $failed = false;
    try {
        $value = context();
        $value['merchant_billing']['vat_number'] = '123';
        IntegrationContext::assertContext($value);
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('handwritten payload cannot bypass legal policy validation', function (): void {
    $value = context();
    $value['merchant_legal']['privacy_dpa']['version'] = 'old-version';
    $failed = false;
    try {
        IntegrationContext::assertContext($value);
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('COD is rejected locally', function (): void {
    $failed = false;
    try {
        orderPayload('cash_on_delivery');
    } catch (InvalidArgumentException) {
        $failed = true;
    }
    same(true, $failed);
});

test('client sends merchant key and forces custom source', function (): void {
    $captured = [];
    $transport = function (
        string $url,
        string $method,
        array $headers,
        string $body
    ) use (&$captured): array {
        $captured = compact('url', 'method', 'headers', 'body');
        return ['status' => 200, 'body' => '{"success":true,"status":"ok"}'];
    };
    $client = new DuttMerchantClient(
        'dutt_live_test',
        'http://127.0.0.1:9999',
        15,
        $transport
    );
    $payload = orderPayload();
    $payload['source'] = 'custom_api';
    $client->createOrder($payload);
    $decoded = json_decode($captured['body'], true, 512, JSON_THROW_ON_ERROR);
    same('custom', $decoded['source']);
    same(true, in_array('X-DUTT-Merchant-Key: dutt_live_test', $captured['headers'], true));
});

test('API errors retain status and reason', function (): void {
    $client = new DuttMerchantClient(
        'dutt_live_test',
        'http://127.0.0.1:9999',
        15,
        fn (): array => [
            'status' => 409,
            'body' => '{"success":false,"reason":"cannot_cancel_terminal_status"}',
        ]
    );
    try {
        $client->cancelDelivery('DEL-1');
        throw new RuntimeException('Expected DuttApiException');
    } catch (DuttApiException $error) {
        same(409, $error->status);
        same('cannot_cancel_terminal_status', $error->reason);
    }
});

function signedHeaders(string $body, string $secret, int $timestamp, string $eventId): array
{
    return [
        'x-dutt-event' => 'delivery.delivered',
        'x-dutt-event-id' => $eventId,
        'x-dutt-signature' => 'sha256=' . hash_hmac(
            'sha256',
            $timestamp . '.' . $body,
            $secret
        ),
        'x-dutt-timestamp' => (string) $timestamp,
    ];
}

test('valid webhook is accepted and duplicate is ignored', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $body = '{"event":"delivery.delivered","event_id":"evt-1"}';
    $headers = signedHeaders($body, $secret, $timestamp, 'evt-1');
    $store = new MemoryReplayStore();
    $count = 0;
    $first = WebhookVerifier::handle(
        $body,
        $headers,
        $secret,
        $store,
        function () use (&$count): void { $count++; },
        300,
        $timestamp
    );
    $second = WebhookVerifier::handle(
        $body,
        $headers,
        $secret,
        $store,
        function () use (&$count): void { $count++; },
        300,
        $timestamp
    );
    same(true, $first['processed']);
    same(true, $second['duplicate']);
    same(1, $count);
});

test('tampered and stale webhooks are rejected', function (): void {
    $secret = '0123456789abcdef0123456789abcdef';
    $timestamp = 1786442400;
    $body = '{"event":"delivery.delivered","event_id":"evt-2"}';
    $headers = signedHeaders($body, $secret, $timestamp, 'evt-2');
    foreach ([
        [$body . ' ', $timestamp, 'invalid_signature'],
        [$body, $timestamp + 301, 'stale_timestamp'],
    ] as [$candidateBody, $now, $expected]) {
        try {
            WebhookVerifier::verify($candidateBody, $headers, $secret, 300, $now);
            throw new RuntimeException('Expected webhook verification failure');
        } catch (RuntimeException $error) {
            same($expected, $error->getMessage());
        }
    }
});

$failed = 0;
foreach ($tests as [$name, $callback]) {
    try {
        $callback();
        echo "PASS {$name}\n";
    } catch (Throwable $error) {
        $failed++;
        fwrite(STDERR, "FAIL {$name}: {$error->getMessage()}\n");
    }
}

echo sprintf("%d tests, %d failed\n", count($tests), $failed);
exit($failed === 0 ? 0 : 1);

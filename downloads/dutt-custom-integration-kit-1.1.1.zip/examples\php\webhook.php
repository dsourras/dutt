<?php

declare(strict_types=1);

require_once __DIR__ . '/../../packages/php/vendor/autoload.php';

use Dutt\CustomIntegration\ReplayStore;
use Dutt\CustomIntegration\WebhookVerifier;

final class PdoReplayStore implements ReplayStore
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function has(string $eventId): bool
    {
        $statement = $this->pdo->prepare(
            'SELECT 1 FROM dutt_webhook_events WHERE event_id = :event_id'
        );
        $statement->execute(['event_id' => $eventId]);
        return (bool) $statement->fetchColumn();
    }

    public function put(string $eventId, int $timestamp): void
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO dutt_webhook_events (event_id, event_name, processed_at) ' .
            'VALUES (:event_id, :event_name, CURRENT_TIMESTAMP)'
        );
        $statement->execute([
            'event_id' => $eventId,
            'event_name' => 'dutt.delivery',
        ]);
    }
}

$rawBody = (string) file_get_contents('php://input');
$headers = function_exists('getallheaders') ? getallheaders() : [];
$pdo = new PDO((string) getenv('DATABASE_DSN'));
$store = new PdoReplayStore($pdo);

try {
    $pdo->beginTransaction();
    $result = WebhookVerifier::handle(
        $rawBody,
        $headers,
        (string) getenv('DUTT_WEBHOOK_SECRET'),
        $store,
        function (array $payload) use ($pdo): void {
            // Update the matching local order here using external_order_id.
        }
    );
    $pdo->commit();
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['received' => true, 'duplicate' => $result['duplicate']]);
} catch (Throwable $error) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['received' => false, 'reason' => 'invalid_webhook']);
}

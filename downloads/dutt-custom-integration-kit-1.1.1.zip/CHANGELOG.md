# Changelog

All notable changes to the DUTT Custom Integration Kit are documented here.

## 1.1.1 - 2026-08-13

- Rendered the Hosted Connector as a native radio option in the checkout shipping-method list.
- Added checkout form metadata, quote-based shipping charge events, and a fail-closed draft requirement.
- Restored the previous shipping method when DUTT details are cancelled or the cart changes.
- Preserved the previous floating-button snippet behavior for existing installations.
- Validated the native method with repeated desktop/mobile checkout, retry, merchant confirmation, and cancellation pilots.

## 1.1.0 - 2026-08-12

- Added the Hosted Connector as the one-line option for custom websites.
- Kept merchant credentials, draft state, retry protection, and confirmation state on DUTT infrastructure.
- Required merchant confirmation of the real order ID, exact total, payment, and readiness before dispatch.
- Added mandatory customer privacy-notice acceptance before delivery data is sent.
- Added merchant-portal cancellation through the existing DUTT cancellation and accounting policy.
- Kept the existing Node.js/PHP integration as the advanced option for automated order and webhook workflows.

## 1.0.2 - 2026-08-12

- Corrected the planned merchant-key rotation runbook to match the backend's fixed 15-minute overlap.
- Clarified that the emergency revoke operation revokes every key recorded as active for the selected merchant and must not be used to finish a normal rotation.

## 1.0.1 - 2026-08-11

- Validated the custom merchant flow with a real production pilot in Larissa: quote, preparation, dispatch, status, and cancellation.
- Increased the production client timeout to 90 seconds so cold starts do not produce an ambiguous delivery result.
- Added pilot status recovery for delivery and city identifiers after a delayed backend completion.
- Added a protected local pilot website and regression coverage for recovery and cancellation safety.

## 1.0.0 - 2026-08-11

- Added the production merchant API contract for custom websites.
- Added server-side Node.js and PHP adapters.
- Added signed webhook verification and replay-protection helpers.
- Added safe smoke testing, onboarding, security, fiscal, and production guides.
- Enforced the `custom` integration source so backend COD restrictions apply.
- Added EUR/Greece and merchant agreement/privacy-DPA payload validation.

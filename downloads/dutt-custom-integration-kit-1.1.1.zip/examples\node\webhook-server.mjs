import http from "node:http";

import {
  MemoryReplayStore,
  handleDuttWebhook,
} from "../../packages/node/src/index.js";

// Local example only. Replace this with a persistent database-backed store in production.
const replayStore = new MemoryReplayStore();
const secret = process.env.DUTT_WEBHOOK_SECRET;

const server = http.createServer(async (request, response) => {
  if (request.method !== "POST" || request.url !== "/webhooks/dutt") {
    response.writeHead(404).end();
    return;
  }
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  const rawBody = Buffer.concat(chunks);
  try {
    const result = await handleDuttWebhook({
      rawBody,
      headers: request.headers,
      secret,
      replayStore,
      onEvent: async (payload) => {
        // Update the matching local order in one database transaction.
        console.log(payload.external_order_id, payload.status);
      },
    });
    response.writeHead(200, { "content-type": "application/json" });
    response.end(JSON.stringify({ received: true, duplicate: result.duplicate }));
  } catch (error) {
    response.writeHead(400, { "content-type": "application/json" });
    response.end(JSON.stringify({ received: false, reason: error.code || "invalid_webhook" }));
  }
});

server.listen(Number(process.env.PORT || 8080));

<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

use RuntimeException;

final class DuttApiException extends RuntimeException
{
    public function __construct(
        string $message,
        public readonly int $status = 0,
        public readonly string $reason = 'request_failed',
        public readonly ?array $details = null,
    ) {
        parent::__construct($message);
    }
}

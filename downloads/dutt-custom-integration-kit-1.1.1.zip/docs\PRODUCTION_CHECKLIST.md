# Production Checklist

## Merchant and credentials

- [ ] Merchant created in DUTT Admin
- [ ] Unique merchant key issued through the approved channel
- [ ] Webhook secret generated and stored server-side
- [ ] Key rotation and revocation owner identified
- [ ] Fiscal profile complete
- [ ] Merchant agreement and privacy/DPA accepted with real timestamp
- [ ] Store and delivery country validated as Greece
- [ ] Currency validated as EUR

## Functional checks

- [ ] Connection test succeeds
- [ ] Valid checkout quote succeeds
- [ ] Outside-service-area response hides DUTT shipping cleanly
- [ ] Expired quote is refreshed
- [ ] Local order creation remains merchant-preparing
- [ ] Mark-ready dispatch creates exactly one DUTT delivery
- [ ] Duplicate create and mark-ready calls remain idempotent
- [ ] Status lookup returns only this merchant's order
- [ ] Signed webhooks update the correct local order
- [ ] Duplicate webhook event is ignored
- [ ] Invalid and stale webhook signatures are rejected
- [ ] Cancellation before and after dispatch follows the common policy
- [ ] Refund notice is matched to the correct external order
- [ ] COD is absent and rejected server-side

## Fiscal and reconciliation checks

- [ ] Customer document is issued by the custom website
- [ ] No DUTT customer receipt is created for the plugin/custom order
- [ ] Customer/store charge split matches the accepted quote
- [ ] Completed delivery appears once in merchant settlement
- [ ] Monthly merchant invoice matches chargeable deliveries
- [ ] Cancellation/refund adjustment is linked and not duplicated

## Operational checks

- [ ] Merchant key is absent from browser/network frontend assets
- [ ] Secrets are absent from source control and release ZIP
- [ ] Webhook endpoint is public HTTPS
- [ ] Persistent replay table has a unique event ID constraint
- [ ] Failed webhooks are visible in logs/alerts
- [ ] Status reconciliation is available without permanent polling
- [ ] Rollback procedure is documented and tested
- [ ] Versioned release ZIP checksum is recorded

# Security

## Credentials

- Use one merchant key per merchant.
- Store the key only in the server secret manager or protected environment.
- Never expose it to browser code.
- Rotate or revoke a compromised key immediately.
- Use a different webhook secret for every merchant/integration.
- Generate webhook secrets from at least 32 random bytes.

## Webhook verification

DUTT sends:

```text
x-dutt-event
x-dutt-event-id
x-dutt-signature
x-dutt-timestamp
```

The signature is:

```text
sha256=HMAC_SHA256(secret, timestamp + "." + raw_request_body)
```

Verification requirements:

1. Read the exact raw request body before JSON parsing.
2. Reject missing or malformed headers.
3. Reject timestamps outside a five-minute window.
4. Compare signatures using a constant-time function.
5. Store `x-dutt-event-id` in a persistent table with a unique constraint.
6. Run the business update in a transaction.
7. Mark the event processed only after the transaction succeeds.

Suggested table:

```sql
CREATE TABLE dutt_webhook_events (
  event_id VARCHAR(64) PRIMARY KEY,
  event_name VARCHAR(80) NOT NULL,
  processed_at TIMESTAMP NOT NULL
);
```

The included in-memory replay store is only for tests and local development. Production must use persistent storage shared by all website instances.

## Request handling

- Use TLS and reject private/internal callback URLs.
- Set strict outbound timeouts.
- Do not log request authorization headers or webhook secrets.
- Treat non-2xx responses and `{ "success": false }` as failures.
- Retry only idempotent operations with the same external order identity.
- Keep customer card data outside the integration entirely.

## Secret scanning

Before every release, scan for merchant key prefixes, private keys, access tokens, `.env` files, and webhook secrets. Release archives must exclude `.git`, `.env`, `node_modules`, `vendor`, reports, and previous releases.

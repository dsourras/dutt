<?php

declare(strict_types=1);

require_once __DIR__ . '/../../packages/php/vendor/autoload.php';

use Dutt\CustomIntegration\DuttMerchantClient;
use Dutt\CustomIntegration\IntegrationContext;

$client = new DuttMerchantClient((string) getenv('DUTT_MERCHANT_KEY'));
$context = IntegrationContext::create([
    'site_url' => getenv('DUTT_SITE_URL'),
    'accepted_at' => getenv('DUTT_MERCHANT_ACCEPTED_AT'),
    'merchant_billing' => json_decode(
        (string) getenv('DUTT_MERCHANT_BILLING_JSON'),
        true,
        512,
        JSON_THROW_ON_ERROR
    ),
    'store' => json_decode(
        (string) getenv('DUTT_STORE_JSON'),
        true,
        512,
        JSON_THROW_ON_ERROR
    ),
]);

// Map these values from the website's real order entity.
$localOrder = [
    'id' => 'ORDER-100',
    'total' => 25.00,
    'payment_method' => 'card',
    'delivery' => [
        'name' => 'Customer Name',
        'phone' => '6900000000',
        'address' => 'Delivery address',
        'city' => 'Larissa',
        'postcode' => '41222',
    ],
    'items' => [['name' => 'Item', 'quantity' => 1, 'price' => 25.00, 'total' => 25.00]],
];

$payload = IntegrationContext::buildOrder([
    'context' => $context,
    'external_order_id' => $localOrder['id'],
    'delivery' => $localOrder['delivery'],
    'order' => [
        'total' => $localOrder['total'],
        'payment_method' => $localOrder['payment_method'],
    ],
    'items' => $localOrder['items'],
]);

$quote = $client->quote($payload);

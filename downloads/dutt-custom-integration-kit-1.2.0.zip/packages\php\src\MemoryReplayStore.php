<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

final class MemoryReplayStore implements AtomicReplayStore
{
    private array $events = [];

    public function has(string $eventId): bool
    {
        return array_key_exists($eventId, $this->events);
    }

    public function put(string $eventId, int $timestamp): void
    {
        $this->events[$eventId] = ['status' => 'processed', 'completed_at' => $timestamp];
    }

    public function claim(string $eventId, int $claimedAt): bool
    {
        if ($this->has($eventId)) {
            return false;
        }
        $this->events[$eventId] = ['status' => 'processing', 'claimed_at' => $claimedAt];
        return true;
    }

    public function complete(string $eventId, int $completedAt): void
    {
        $this->events[$eventId] = ['status' => 'processed', 'completed_at' => $completedAt];
    }

    public function release(string $eventId): void
    {
        if (($this->events[$eventId]['status'] ?? '') === 'processing') {
            unset($this->events[$eventId]);
        }
    }
}

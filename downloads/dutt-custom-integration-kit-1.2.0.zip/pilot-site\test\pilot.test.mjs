import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import {
  JsonReplayStore,
  buildPilotPayload,
  isAuthorized,
  parseEnv,
  syncOrderFromStatus,
} from "../server.mjs";
import { createIntegrationContext } from "../../packages/node/src/index.js";

function context() {
  return createIntegrationContext({
    siteUrl: "https://pilot.example.test",
    acceptedAt: "2026-08-11T00:00:00.000Z",
    merchantBilling: {
      legal_name: "DUTT Pilot",
      vat_number: "103922076",
      tax_office: "DOY Larissas",
      billing_address: "Mandilara 1",
      billing_city: "Larissa",
      billing_postcode: "41222",
      billing_email: "info@example.test",
    },
    store: {
      name: "DUTT Pilot",
      address: "Mandilara 1",
      city: "Larissa",
      postcode: "41222",
      phone: "2410000000",
    },
  });
}

test("pilot environment parser does not alter values", () => {
  assert.deepEqual(parseEnv("A=one\nB='two words'\n# ignored\n"), { A: "one", B: "two words" });
});

test("pilot token check is exact", () => {
  assert.equal(isAuthorized({ "x-pilot-token": "secret" }, "secret"), true);
  assert.equal(isAuthorized({ "x-pilot-token": "Secret" }, "secret"), false);
});

test("pilot order is free, prepaid and merchant-funded", () => {
  const payload = buildPilotPayload({
    context: context(),
    orderId: "CUSTOM-PILOT-1",
    input: {
      name: "Pilot User",
      phone: "6900000000",
      email: "pilot@example.test",
      address: "Koutlimpana 5",
      city: "Larissa",
      postcode: "41222",
    },
  });
  assert.equal(payload.source, "custom");
  assert.equal(payload.order.total, 0);
  assert.equal(payload.order.payment_method, "free_pilot");
  assert.equal(payload.charge_policy.policy, "store_absorbs");
  assert.equal(payload.delivery.country, "GR");
});

test("pilot rejects a non-real recipient phone shape", () => {
  assert.throws(
    () => buildPilotPayload({
      context: context(),
      orderId: "CUSTOM-PILOT-2",
      input: { name: "Pilot", phone: "2410000000", address: "Koutlimpana 5", city: "Larissa" },
    }),
    /κινητό 10 ψηφίων/,
  );
});

test("pilot recovers a dispatched delivery from status after a client timeout", () => {
  const order = syncOrderFromStatus(
    { stage: "merchant_preparing", deliveryId: "", cityId: "" },
    { status: "pending", delivery_id: "DEL-1", city_id: "larisa" },
  );
  assert.equal(order.stage, "dispatched");
  assert.equal(order.deliveryId, "DEL-1");
  assert.equal(order.cityId, "larisa");
});

test("pilot status recovery never reopens a cancelled order", () => {
  const order = syncOrderFromStatus(
    { stage: "cancelled", deliveryId: "DEL-1", cityId: "larisa" },
    { status: "pending", delivery_id: "DEL-1", city_id: "larisa" },
  );
  assert.equal(order.stage, "cancelled");
});

test("pilot replay store reclaims only stale processing events", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "dutt-pilot-replay-"));
  const file = path.join(directory, "events.json");
  try {
    const store = new JsonReplayStore(file);
    assert.equal(await store.claim("event-processing-1", 1000), true);
    assert.equal(await store.claim("event-processing-1", 1001), false);
    assert.equal(await store.claim("event-processing-1", 1901), true);
    await store.complete("event-processing-1", 1901);
    assert.equal(await store.claim("event-processing-1", 10000), false);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test("pilot replay store treats version 1.1 timestamp entries as processed", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "dutt-pilot-replay-"));
  const file = path.join(directory, "events.json");
  try {
    fs.writeFileSync(file, JSON.stringify({ "event-legacy-1": 1723400000 }), "utf8");
    const store = new JsonReplayStore(file);
    assert.equal(await store.claim("event-legacy-1", 1723500000), false);
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

const form = document.querySelector("#pilotForm");
const tokenInput = document.querySelector("#accessToken");
const result = document.querySelector("#result");
const toast = document.querySelector("#toast");
const badge = document.querySelector("#connectionBadge");
const createButton = document.querySelector("#createButton");
const statusButton = document.querySelector("#statusButton");
const dispatchButton = document.querySelector("#dispatchButton");
const cancelButton = document.querySelector("#cancelButton");
const timeline = [...document.querySelectorAll("#timeline li")];

let activeOrder = null;
let configuration = null;

function pilotToken() {
  return tokenInput.value.trim();
}

async function api(path, options = {}) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 90000);
  let response;
  try {
    response = await fetch(path, {
      ...options,
      headers: {
        "content-type": "application/json",
        "x-pilot-token": pilotToken(),
        ...(options.headers || {}),
      },
      signal: controller.signal,
    });
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("Η σύνδεση καθυστέρησε υπερβολικά");
    throw error;
  } finally {
    window.clearTimeout(timeout);
  }
  const payload = await response.json().catch(() => null);
  if (
    !response.ok ||
    !payload ||
    typeof payload !== "object" ||
    Array.isArray(payload) ||
    payload.success !== true
  ) {
    throw new Error(payload?.reason || (response.ok ? "invalid_response" : `HTTP ${response.status}`));
  }
  return payload;
}

function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 3000);
}

function show(value) {
  result.textContent = JSON.stringify(value, null, 2);
}

function updateTimeline(stage = "") {
  const index = { quoted: 0, merchant_preparing: 1, dispatched: 2, cancelled: 3, delivered: 3 }[stage] ?? 0;
  timeline.forEach((item, itemIndex) => {
    item.classList.toggle("done", itemIndex < index);
    item.classList.toggle("current", itemIndex === index);
  });
}

function updateActions() {
  const stage = activeOrder?.stage || "";
  createButton.disabled = stage !== "quoted";
  statusButton.disabled = !activeOrder;
  dispatchButton.disabled = stage !== "merchant_preparing" || !configuration?.dispatchEnabled || !configuration?.storePhoneVerified;
  cancelButton.disabled = !activeOrder?.deliveryId || stage === "cancelled";
  updateTimeline(stage);
}

function formPayload() {
  return Object.fromEntries(new FormData(form).entries());
}

async function withBusy(button, task) {
  const wasDisabled = button.disabled;
  button.disabled = true;
  try {
    await task();
  } catch (error) {
    show({ success: false, reason: error.message });
    notify(error.message);
  } finally {
    button.disabled = wasDisabled;
    updateActions();
  }
}

document.querySelector("#connectionButton").addEventListener("click", (event) => withBusy(event.currentTarget, async () => {
  configuration = await api("/api/config");
  const response = await api("/api/connection", { method: "POST", body: "{}" });
  badge.textContent = "Συνδεδεμένο";
  badge.classList.add("ready");
  show({ configuration, connection: response.result });
}));

document.querySelector("#webhookButton").addEventListener("click", (event) => withBusy(event.currentTarget, async () => {
  const response = await api("/api/register-webhook", { method: "POST", body: "{}" });
  show(response);
  notify("Το webhook συνδέθηκε");
}));

form.addEventListener("submit", (event) => {
  event.preventDefault();
  withBusy(form.querySelector("button[type=submit]"), async () => {
    configuration = await api("/api/config");
    const response = await api("/api/quote", { method: "POST", body: JSON.stringify(formPayload()) });
    activeOrder = response.order;
    show(activeOrder);
    notify("Η προσφορά δημιουργήθηκε");
  });
});

createButton.addEventListener("click", () => withBusy(createButton, async () => {
  const response = await api("/api/create-order", { method: "POST", body: JSON.stringify({ orderId: activeOrder.orderId }) });
  activeOrder = response.order;
  show(activeOrder);
  notify("Η παραγγελία έμεινε σε προετοιμασία");
}));

statusButton.addEventListener("click", () => withBusy(statusButton, async () => {
  const response = await api("/api/status", { method: "POST", body: JSON.stringify({ orderId: activeOrder.orderId }) });
  activeOrder = response.order;
  show(activeOrder);
}));

dispatchButton.addEventListener("click", () => withBusy(dispatchButton, async () => {
  const confirmation = window.prompt('Γράψε ακριβώς "DISPATCH REAL ORDER"');
  if (confirmation !== "DISPATCH REAL ORDER") throw new Error("Το dispatch ακυρώθηκε");
  const response = await api("/api/dispatch", { method: "POST", body: JSON.stringify({ orderId: activeOrder.orderId, confirmation }) });
  activeOrder = response.order;
  show(activeOrder);
  notify("Η παραγγελία στάλθηκε για πραγματικό dispatch");
}));

cancelButton.addEventListener("click", () => withBusy(cancelButton, async () => {
  const confirmation = window.prompt('Γράψε ακριβώς "CANCEL REAL ORDER"');
  if (confirmation !== "CANCEL REAL ORDER") throw new Error("Η ακύρωση διακόπηκε");
  const response = await api("/api/cancel", { method: "POST", body: JSON.stringify({ orderId: activeOrder.orderId, confirmation }) });
  activeOrder = response.order;
  show(activeOrder);
  notify("Η ακύρωση καταγράφηκε");
}));

document.querySelector("#refreshButton").addEventListener("click", (event) => withBusy(event.currentTarget, async () => {
  const response = await api("/api/orders");
  activeOrder = response.orders[0] || activeOrder;
  show({ activeOrder, webhooks: response.webhooks });
}));

tokenInput.addEventListener("change", () => {
  badge.textContent = "Έτοιμο για έλεγχο";
  updateActions();
});

updateActions();

<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

interface AtomicReplayStore extends ReplayStore
{
    public function claim(string $eventId, int $claimedAt): bool;

    public function complete(string $eventId, int $completedAt): void;

    public function release(string $eventId): void;
}

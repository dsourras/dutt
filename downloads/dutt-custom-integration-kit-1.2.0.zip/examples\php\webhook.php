<?php

declare(strict_types=1);

require_once __DIR__ . '/../../packages/php/vendor/autoload.php';

use Dutt\CustomIntegration\AtomicReplayStore;
use Dutt\CustomIntegration\WebhookVerifier;

final class PdoReplayStore implements AtomicReplayStore
{
    private const PROCESSING_LEASE_SECONDS = 900;

    public function __construct(private readonly PDO $pdo)
    {
    }

    public function has(string $eventId): bool
    {
        $statement = $this->pdo->prepare(
            'SELECT 1 FROM dutt_webhook_events WHERE event_id = :event_id'
        );
        $statement->execute(['event_id' => $eventId]);
        return (bool) $statement->fetchColumn();
    }

    public function put(string $eventId, int $timestamp): void
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO dutt_webhook_events (event_id, event_name, status, received_at, processed_at) ' .
            'VALUES (:event_id, :event_name, :status, :received_at, CURRENT_TIMESTAMP)'
        );
        $statement->execute([
            'event_id' => $eventId,
            'event_name' => 'dutt.delivery',
            'status' => 'processed',
            'received_at' => gmdate('Y-m-d H:i:s', $timestamp),
        ]);
    }

    public function claim(string $eventId, int $claimedAt): bool
    {
        $receivedAt = gmdate('Y-m-d H:i:s', $claimedAt);
        $usesSavepoint = $this->pdo->inTransaction();
        if ($usesSavepoint) {
            $this->pdo->exec('SAVEPOINT dutt_webhook_claim');
        }
        try {
            $statement = $this->pdo->prepare(
                'INSERT INTO dutt_webhook_events (event_id, event_name, status, received_at) ' .
                'VALUES (:event_id, :event_name, :status, :received_at)'
            );
            $statement->execute([
                'event_id' => $eventId,
                'event_name' => 'dutt.delivery',
                'status' => 'processing',
                'received_at' => $receivedAt,
            ]);
            if ($usesSavepoint) {
                $this->pdo->exec('RELEASE SAVEPOINT dutt_webhook_claim');
            }
            return true;
        } catch (PDOException $error) {
            if ($usesSavepoint) {
                $this->pdo->exec('ROLLBACK TO SAVEPOINT dutt_webhook_claim');
                $this->pdo->exec('RELEASE SAVEPOINT dutt_webhook_claim');
            }
            if (!in_array((string) $error->getCode(), ['23000', '23505'], true)) {
                throw $error;
            }
        }

        $statement = $this->pdo->prepare(
            'UPDATE dutt_webhook_events SET received_at = :received_at ' .
            'WHERE event_id = :event_id AND status = :status AND received_at < :stale_before'
        );
        $statement->execute([
            'event_id' => $eventId,
            'status' => 'processing',
            'received_at' => $receivedAt,
            'stale_before' => gmdate(
                'Y-m-d H:i:s',
                $claimedAt - self::PROCESSING_LEASE_SECONDS
            ),
        ]);
        return $statement->rowCount() === 1;
    }

    public function complete(string $eventId, int $timestamp): void
    {
        $statement = $this->pdo->prepare(
            'UPDATE dutt_webhook_events SET status = :status, processed_at = CURRENT_TIMESTAMP ' .
            'WHERE event_id = :event_id'
        );
        $statement->execute(['status' => 'processed', 'event_id' => $eventId]);
    }

    public function release(string $eventId): void
    {
        $statement = $this->pdo->prepare(
            'DELETE FROM dutt_webhook_events WHERE event_id = :event_id AND status = :status'
        );
        $statement->execute(['event_id' => $eventId, 'status' => 'processing']);
    }
}

$rawBody = (string) file_get_contents('php://input');
$headers = function_exists('getallheaders') ? getallheaders() : [];
$pdo = new PDO((string) getenv('DATABASE_DSN'));
$store = new PdoReplayStore($pdo);

try {
    $pdo->beginTransaction();
    $result = WebhookVerifier::handle(
        $rawBody,
        $headers,
        (string) getenv('DUTT_WEBHOOK_SECRET'),
        $store,
        function (array $payload) use ($pdo): void {
            // Update the matching local order here using external_order_id.
        }
    );
    $pdo->commit();
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode(['received' => true, 'duplicate' => $result['duplicate']]);
} catch (Throwable $error) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $invalidWebhookReasons = [
        'missing_headers',
        'invalid_timestamp',
        'invalid_event_id',
        'stale_timestamp',
        'invalid_signature',
        'invalid_json',
        'header_payload_mismatch',
    ];
    $isInvalidWebhook = in_array($error->getMessage(), $invalidWebhookReasons, true);
    http_response_code($isInvalidWebhook ? 400 : 500);
    header('Content-Type: application/json');
    echo json_encode([
        'received' => false,
        'reason' => $isInvalidWebhook ? 'invalid_webhook' : 'processing_failed',
    ]);
}

#!/usr/bin/env node

import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

const backendInput = process.argv[2] || process.env.DUTT_BACKEND_PATH;
assert.ok(
  backendInput,
  "Pass the backend checkout path as the first argument or DUTT_BACKEND_PATH.",
);
const backend = path.resolve(backendInput);

function read(file) {
  const fullPath = path.join(backend, file);
  assert.ok(fs.existsSync(fullPath), `Backend file not found: ${fullPath}`);
  return fs.readFileSync(fullPath, "utf8");
}

const index = read("index.js");
const policy = read("merchantIntegrationPolicy.js");
const delivery = read("merchantCreateDelivery.js");
const webhooks = read("merchantWebhooks.js");

const endpoints = [
  "duttMerchantConnectionTest",
  "duttMerchantQuote",
  "duttMerchantCreateOrder",
  "duttMerchantMarkReady",
  "duttMerchantCancelDelivery",
  "duttMerchantGetStatus",
  "duttMerchantListDeliveries",
  "duttMerchantListLocations",
  "duttMerchantUpsertLocation",
  "duttMerchantRegisterWebhook",
  "duttMerchantRefundNotice",
];
for (const endpoint of endpoints) {
  assert.match(index, new RegExp(`exports\\.${endpoint}\\s*=`), `Missing backend export: ${endpoint}`);
}

assert.match(policy, /dutt-merchant-agreement-v1\.0-2026-08-02/);
assert.match(policy, /dutt-privacy-dpa-v1\.0-2026-08-02/);
assert.match(policy, /const REQUIRED_CURRENCY = "EUR"/);
assert.match(policy, /const REQUIRED_COUNTRY = "GR"/);
assert.match(delivery, /MERCHANT_PLUGIN_ORDER_SOURCES[^\n]*new Set\(\["woocommerce", "shopify", "custom"\]\)/);
for (const method of ["cash", "cod", "cash_on_delivery", "cashondelivery", "pay_on_delivery"]) {
  assert.match(delivery, new RegExp(`"${method}"`), `Backend COD policy is missing ${method}`);
}
assert.match(
  webhooks,
  /const signedPayload = `\$\{readString\(timestamp\)\}\.\$\{String\(body\)\}`/,
);
assert.match(webhooks, /"x-dutt-signature": signature/);
assert.match(webhooks, /"x-dutt-event-id": eventId/);
assert.match(webhooks, /const MAX_ATTEMPTS = 4/);

console.log(`Backend contract verified against ${backend}`);

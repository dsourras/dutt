import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const version = fs.readFileSync(path.join(root, "VERSION"), "utf8").trim();
const rootPackage = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const nodePackage = JSON.parse(fs.readFileSync(path.join(root, "packages/node/package.json"), "utf8"));
const phpPackage = JSON.parse(fs.readFileSync(path.join(root, "packages/php/composer.json"), "utf8"));
const openapi = JSON.parse(fs.readFileSync(path.join(root, "openapi/dutt-merchant-api.json"), "utf8"));

assert.match(version, /^\d+\.\d+\.\d+$/);
assert.equal(rootPackage.version, version);
assert.equal(nodePackage.version, version);
assert.equal(phpPackage.extra["dutt-kit-version"], version);
assert.equal(openapi.info.version, version);

const expectedEndpoints = [
  "duttMerchantConnectionTest",
  "duttMerchantQuote",
  "duttMerchantCreateOrder",
  "duttMerchantMarkReady",
  "duttMerchantCancelDelivery",
  "duttMerchantGetStatus",
  "duttMerchantListDeliveries",
  "duttMerchantListLocations",
  "duttMerchantUpsertLocation",
  "duttMerchantRegisterWebhook",
  "duttMerchantRefundNotice",
];
assert.deepEqual(
  Object.keys(openapi.paths).map((value) => value.slice(1)).sort(),
  expectedEndpoints.sort(),
);

function resolvePointer(document, pointer) {
  assert.match(pointer, /^#\//, `Only local OpenAPI references are allowed: ${pointer}`);
  return pointer.slice(2).split("/").reduce((value, segment) => {
    const key = segment.replace(/~1/g, "/").replace(/~0/g, "~");
    assert.ok(value && Object.hasOwn(value, key), `Unresolved OpenAPI reference: ${pointer}`);
    return value[key];
  }, document);
}

function visit(value) {
  if (Array.isArray(value)) {
    value.forEach(visit);
    return;
  }
  if (!value || typeof value !== "object") return;
  if (typeof value.$ref === "string") resolvePointer(openapi, value.$ref);
  Object.values(value).forEach(visit);
}
visit(openapi);

const requiredFiles = [
  "README.md",
  "CHANGELOG.md",
  "docs/INSTALLATION.md",
  "docs/HOSTED_CONNECTOR.md",
  "docs/CREDENTIAL_OPERATIONS.md",
  "docs/API_WORKFLOW.md",
  "docs/SECURITY.md",
  "docs/FISCAL_AND_PAYMENT_POLICY.md",
  "docs/PRODUCTION_CHECKLIST.md",
  "packages/node/src/index.js",
  "packages/php/src/DuttMerchantClient.php",
  "packages/php/src/WebhookVerifier.php",
  "openapi/dutt-merchant-api.json",
  "examples/hosted/one-line.html",
  "pilot-site/server.mjs",
  "pilot-site/test/pilot.test.mjs",
  "scripts/smoke-test.mjs",
  "scripts/verify-backend-contract.mjs",
];
requiredFiles.forEach((file) => assert.ok(fs.existsSync(path.join(root, file)), `Missing ${file}`));

function filesUnder(directory) {
  const result = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if ([".git", "node_modules", "vendor", "releases", "reports"].includes(entry.name)) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) result.push(...filesUnder(fullPath));
    else result.push(fullPath);
  }
  return result;
}

const ignoredFiles = fs.existsSync(path.join(root, ".git"))
  ? new Set(
    execFileSync(
      "git",
      ["ls-files", "--others", "--ignored", "--exclude-standard", "-z"],
      { cwd: root },
    )
      .toString("utf8")
      .split("\0")
      .filter(Boolean)
      .map((file) => path.resolve(root, file)),
  )
  : new Set();

const forbidden = [
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
  /\bgh[opusr]_[A-Za-z0-9_]{20,}\b/,
  /\bAIza[0-9A-Za-z_-]{30,}\b/,
  /\bdutt_live_(?!\.\.\.|test\b|example\b)[A-Za-z0-9_-]{16,}\b/,
];
for (const file of filesUnder(root)) {
  if (ignoredFiles.has(path.resolve(file))) continue;
  if (path.basename(file) === ".env") throw new Error("A real .env file must not be packaged");
  const content = fs.readFileSync(file, "utf8");
  for (const pattern of forbidden) {
    assert.equal(pattern.test(content), false, `Possible secret in ${path.relative(root, file)}`);
  }
}

console.log(`DUTT Custom Integration Kit ${version}: validation passed`);

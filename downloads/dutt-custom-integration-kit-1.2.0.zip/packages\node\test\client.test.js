import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { after, before, test } from "node:test";
import http from "node:http";

import {
  DuttApiError,
  DuttMerchantClient,
  DuttWebhookError,
  DEFAULT_TIMEOUT_MS,
  MemoryReplayStore,
  buildOrderPayload,
  createIntegrationContext,
  handleDuttWebhook,
  verifyDuttWebhook,
} from "../src/index.js";

test("production client timeout covers cold starts", () => {
  const client = new DuttMerchantClient({ merchantKey: "dutt_live_test" });
  assert.equal(DEFAULT_TIMEOUT_MS, 90000);
  assert.equal(client.timeoutMs, DEFAULT_TIMEOUT_MS);
});

let server;
let baseUrl;
const requests = [];

before(async () => {
  server = http.createServer((request, response) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      requests.push({
        url: request.url,
        method: request.method,
        headers: request.headers,
        body: raw ? JSON.parse(raw) : null,
      });
      if (request.url.startsWith("/duttMerchantCancelDelivery")) {
        response.writeHead(409, { "content-type": "application/json" });
        response.end(JSON.stringify({ success: false, reason: "cannot_cancel_terminal_status" }));
        return;
      }
      if (request.url.startsWith("/duttMerchantGetStatus")) {
        setTimeout(() => {
          response.writeHead(200, { "content-type": "application/json" });
          response.end(JSON.stringify({ success: true, status: "delivered" }));
        }, 60);
        return;
      }
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ success: true, status: "ok" }));
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  baseUrl = `http://127.0.0.1:${address.port}`;
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

function context() {
  return createIntegrationContext({
    siteUrl: "https://shop.example.gr",
    acceptedAt: "2026-08-11T10:00:00.000Z",
    merchantBilling: {
      legal_name: "Example IKE",
      vat_number: "123456789",
      tax_office: "DOY Larissas",
      billing_address: "Example 1",
      billing_city: "Larissa",
      billing_postcode: "41222",
      billing_email: "billing@example.gr",
    },
    store: {
      name: "Example Store",
      address: "Example 1",
      city: "Larissa",
      postcode: "41222",
      phone: "2410000000",
    },
  });
}

function orderPayload(paymentMethod = "card", overrides = {}) {
  return buildOrderPayload({
    context: context(),
    externalOrderId: "ORDER-100",
    delivery: {
      name: "Customer",
      phone: "6900000000",
      address: "Delivery 1",
      city: "Larissa",
      postcode: "41222",
    },
    order: {
      total: 25,
      payment_method: paymentMethod,
      ...(overrides.order || {}),
    },
    items: [{ name: "Item", quantity: 1, price: 25, total: 25 }],
  });
}

test("context contains the mandatory production policy", () => {
  const value = context();
  assert.equal(value.source, "custom");
  assert.equal(value.currency, "EUR");
  assert.equal(value.integration_market.store_country, "GR");
  assert.equal(value.merchant_legal.merchant_agreement.accepted, true);
});

test("invalid fiscal profile is rejected before a request", () => {
  assert.throws(
    () => createIntegrationContext({
      siteUrl: "https://shop.example.gr",
      acceptedAt: "2026-08-11T10:00:00.000Z",
      merchantBilling: {
        legal_name: "Example",
        vat_number: "123",
        tax_office: "DOY",
        billing_address: "A",
        billing_city: "B",
        billing_postcode: "1",
        billing_email: "a@example.gr",
      },
      store: { name: "S", address: "A", city: "B", phone: "1" },
    }),
    /exactly 9 digits/,
  );
});

test("handwritten payload cannot bypass legal policy validation", () => {
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl: "http://127.0.0.1:9999",
  });
  const payload = context();
  payload.merchant_legal.merchant_agreement.version = "old-version";
  assert.throws(() => client.connectionTest(payload), /merchant_agreement.version/);
});

test("COD is rejected locally", () => {
  assert.throws(() => orderPayload("cash_on_delivery"), /Cash on delivery/);
});

test("order amounts and charge policy are normalized before transmission", () => {
  const payload = buildOrderPayload({
    context: context(),
    externalOrderId: "ORDER-NORMALIZED",
    delivery: {
      name: "Customer",
      phone: "6900000000",
      address: "Delivery 1",
      city: "Larissa",
    },
    order: { total: "25.50", cart_subtotal: "20.25", payment_method: "card" },
    chargePolicy: { policy: " fixed_customer_amount " },
  });
  assert.equal(payload.order.total, 25.5);
  assert.equal(payload.order.cart_subtotal, 20.25);
  assert.equal(payload.cart_subtotal, 20.25);
  assert.equal(payload.charge_policy.policy, "fixed_customer_amount");
  assert.throws(
    () => buildOrderPayload({
      context: context(),
      externalOrderId: "ORDER-BAD-SUBTOTAL",
      delivery: {
        name: "Customer",
        phone: "6900000000",
        address: "Delivery 1",
        city: "Larissa",
      },
      order: { total: 25, cart_subtotal: "invalid", payment_method: "card" },
    }),
    /cart_subtotal/,
  );
  for (const cartSubtotal of [null, "", false, -1, 1.001]) {
    assert.throws(
      () => orderPayload("card", { order: { cart_subtotal: cartSubtotal } }),
      /order\.cart_subtotal/,
    );
  }
  for (const total of [null, undefined, "", false]) {
    assert.throws(
      () => buildOrderPayload({
        context: context(),
        externalOrderId: "ORDER-BAD-TOTAL",
        delivery: {
          name: "Customer",
          phone: "6900000000",
          address: "Delivery 1",
          city: "Larissa",
        },
        order: { total, payment_method: "card" },
      }),
      /order\.total/,
    );
  }
  assert.throws(
    () => orderPayload("card", { order: { total: 1.001 } }),
    /two decimal places/,
  );
});

test("refund amounts reject missing values and fractions of a cent", () => {
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl: "http://127.0.0.1:9999",
  });
  for (const amount of [null, "", false, 1.001]) {
    assert.throws(
      () => client.refundNotice({
        external_order_id: "ORDER-REFUND",
        refund_id: "REFUND-1",
        amount,
      }),
      /amount/,
    );
  }
});

test("URLs reject embedded credentials and fragments", () => {
  assert.throws(
    () => new DuttMerchantClient({ merchantKey: "key", baseUrl: "https://user:pass@example.test" }),
    /credentials/,
  );
  assert.throws(
    () => new DuttMerchantClient({ merchantKey: "key", baseUrl: "ftp://localhost" }),
    /baseUrl must use HTTPS/,
  );
  const invalidContext = () => createIntegrationContext({
    siteUrl: "https://user:pass@example.test",
    acceptedAt: new Date().toISOString(),
    merchantBilling: context().merchant_billing,
    store: context().store,
  });
  assert.throws(invalidContext, /credentials/);
});

test("client sends the merchant key server-side and forces custom source", async () => {
  const client = new DuttMerchantClient({ merchantKey: "dutt_live_test", baseUrl });
  await client.createOrder({ ...orderPayload(), source: "custom_api" });
  const request = requests.at(-1);
  assert.equal(request.headers["x-dutt-merchant-key"], "dutt_live_test");
  assert.equal(request.body.source, "custom");
  assert.equal(request.body.channel, "custom");
  assert.equal(request.body.integration, "custom");
});

test("API errors retain status and reason", async () => {
  const client = new DuttMerchantClient({ merchantKey: "dutt_live_test", baseUrl });
  await assert.rejects(
    client.cancelDelivery({ deliveryId: "DEL-1" }),
    (error) => error instanceof DuttApiError &&
      error.status === 409 &&
      error.reason === "cannot_cancel_terminal_status",
  );
});

test("request timeout is explicit", async () => {
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl,
    timeoutMs: 10,
  });
  await assert.rejects(
    client.getStatus({ deliveryId: "DEL-1" }),
    (error) => error instanceof DuttApiError && error.reason === "request_timeout",
  );
});

test("client rejects empty or incomplete success responses and never follows redirects with credentials", async () => {
  let requestOptions;
  let raw = "";
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl: "https://api.example.test",
    fetchImpl: async (url, options) => {
      requestOptions = options;
      return { ok: true, status: 200, statusText: "OK", text: async () => raw };
    },
  });
  await assert.rejects(
    client.listLocations(),
    (error) => error instanceof DuttApiError && error.reason === "empty_response",
  );
  assert.equal(requestOptions.redirect, "error");
  raw = "{}";
  await assert.rejects(
    client.listLocations(),
    (error) => error instanceof DuttApiError && error.reason === "invalid_json_response",
  );
});

function signedWebhook({ body, secret, timestamp, event = "delivery.delivered", eventId = "event-00000001" }) {
  const signature = `sha256=${createHmac("sha256", secret)
    .update(`${timestamp}.${body}`, "utf8")
    .digest("hex")}`;
  return {
    "x-dutt-event": event,
    "x-dutt-event-id": eventId,
    "x-dutt-signature": signature,
    "x-dutt-timestamp": String(timestamp),
  };
}

test("valid webhook signature is accepted", () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "event-00000001" });
  const result = verifyDuttWebhook({
    rawBody: body,
    headers: signedWebhook({ body, secret, timestamp }),
    secret,
    nowSeconds: timestamp,
  });
  assert.equal(result.eventId, "event-00000001");
});

test("tampered and stale webhooks are rejected", () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "event-00000001" });
  const headers = signedWebhook({ body, secret, timestamp });
  assert.throws(
    () => verifyDuttWebhook({ rawBody: `${body} `, headers, secret, nowSeconds: timestamp }),
    (error) => error instanceof DuttWebhookError && error.code === "invalid_signature",
  );
  assert.throws(
    () => verifyDuttWebhook({ rawBody: body, headers, secret, nowSeconds: timestamp + 301 }),
    (error) => error instanceof DuttWebhookError && error.code === "stale_timestamp",
  );
});

test("webhook verification rejects invalid clock configuration and non-object JSON", () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "event-clock-00001" });
  const headers = signedWebhook({ body, secret, timestamp, eventId: "event-clock-00001" });
  for (const toleranceSeconds of ["bad", -1, Number.POSITIVE_INFINITY]) {
    assert.throws(
      () => verifyDuttWebhook({ body, rawBody: body, headers, secret, nowSeconds: timestamp, toleranceSeconds }),
      TypeError,
    );
  }
  assert.throws(
    () => verifyDuttWebhook({ rawBody: body, headers, secret, nowSeconds: "bad" }),
    TypeError,
  );
  const arrayBody = JSON.stringify([]);
  assert.throws(
    () => verifyDuttWebhook({
      rawBody: arrayBody,
      headers: signedWebhook({ body: arrayBody, secret, timestamp, eventId: "event-array-00001" }),
      secret,
      nowSeconds: timestamp,
    }),
    (error) => error instanceof DuttWebhookError && error.code === "invalid_json",
  );
});

test("client validates identity URLs and registered webhook event names", async () => {
  const requests = [];
  const client = new DuttMerchantClient({
    merchantKey: "dutt_live_test",
    baseUrl: "https://api.example.test",
    fetchImpl: async (url, options) => {
      requests.push({ url: String(url), body: JSON.parse(options.body) });
      return { ok: true, status: 200, statusText: "OK", text: async () => '{"success":true}' };
    },
  });
  assert.throws(
    () => client.markReady({ external_order_id: "ORDER-1", site_url: "http://shop.example.test" }),
    /siteUrl must use HTTPS/,
  );
  assert.throws(
    () => client.getStatus({ externalOrderId: "ORDER-1", siteUrl: "https://shop.example.test?token=bad" }),
    /siteUrl must not contain/,
  );
  assert.throws(
    () => client.registerWebhook({
      url: "https://shop.example.test/webhook",
      secret: "0123456789abcdef",
      events: ["delivery.delivereed"],
    }),
    /Unsupported webhook event/,
  );
  await client.registerWebhook({
    url: "https://shop.example.test/webhook",
    secret: "0123456789abcdef",
    events: ["DELIVERY.DELIVERED", "delivery.delivered"],
  });
  assert.deepEqual(requests[0].body.events, ["delivery.delivered"]);
});

test("webhook handler processes an event once", async () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "event-00000002" });
  const headers = signedWebhook({ body, secret, timestamp, eventId: "event-00000002" });
  const store = new MemoryReplayStore();
  let count = 0;
  const options = {
    rawBody: body,
    headers,
    secret,
    replayStore: store,
    nowSeconds: timestamp,
    onEvent: async () => { count += 1; },
  };
  const first = await handleDuttWebhook(options);
  const second = await handleDuttWebhook(options);
  assert.equal(first.processed, true);
  assert.equal(second.duplicate, true);
  assert.equal(count, 1);
});

test("legacy has/put replay stores remain compatible", async () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const eventId = "event-legacy-000001";
  const body = JSON.stringify({ event: "delivery.delivered", event_id: eventId });
  const headers = signedWebhook({ body, secret, timestamp, eventId });
  const events = new Set();
  const store = {
    async has(id) { return events.has(id); },
    async put(id) { events.add(id); },
  };
  let count = 0;
  const options = {
    rawBody: body,
    headers,
    secret,
    replayStore: store,
    nowSeconds: timestamp,
    onEvent: async () => { count += 1; },
  };
  assert.equal((await handleDuttWebhook(options)).processed, true);
  assert.equal((await handleDuttWebhook(options)).duplicate, true);
  assert.equal(count, 1);
});

test("failed webhook processing is not marked as processed", async () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "event-00000003" });
  const headers = signedWebhook({ body, secret, timestamp, eventId: "event-00000003" });
  const store = new MemoryReplayStore();
  await assert.rejects(handleDuttWebhook({
    rawBody: body,
    headers,
    secret,
    replayStore: store,
    nowSeconds: timestamp,
    onEvent: async () => { throw new Error("database unavailable"); },
  }));
  assert.equal(await store.has("event-00000003"), false);
});

test("concurrent duplicate webhooks cannot run the business callback twice", async () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const eventId = "event-concurrent-0001";
  const body = JSON.stringify({ event: "delivery.delivered", event_id: eventId });
  const headers = signedWebhook({ body, secret, timestamp, eventId });
  const store = new MemoryReplayStore();
  let release;
  const blocker = new Promise((resolve) => { release = resolve; });
  let count = 0;
  const options = {
    rawBody: body,
    headers,
    secret,
    replayStore: store,
    nowSeconds: timestamp,
    onEvent: async () => {
      count += 1;
      await blocker;
    },
  };
  const firstPromise = handleDuttWebhook(options);
  await new Promise((resolve) => setImmediate(resolve));
  const duplicate = await handleDuttWebhook(options);
  release();
  const first = await firstPromise;
  assert.equal(first.processed, true);
  assert.equal(duplicate.duplicate, true);
  assert.equal(count, 1);
});

test("short or malformed webhook event IDs are rejected", () => {
  const secret = "0123456789abcdef0123456789abcdef";
  const timestamp = 1786442400;
  const body = JSON.stringify({ event: "delivery.delivered", event_id: "evt-1" });
  assert.throws(
    () => verifyDuttWebhook({
      rawBody: body,
      headers: signedWebhook({ body, secret, timestamp, eventId: "evt-1" }),
      secret,
      nowSeconds: timestamp,
    }),
    (error) => error instanceof DuttWebhookError && error.code === "invalid_event_id",
  );
});

<?php

declare(strict_types=1);

namespace Dutt\CustomIntegration;

use InvalidArgumentException;
use JsonException;
use RuntimeException;
use Throwable;

final class WebhookVerifier
{
    public static function verify(
        string $rawBody,
        array $headers,
        string $secret,
        int $toleranceSeconds = 300,
        ?int $nowSeconds = null,
    ): array {
        if (trim($secret) === '') {
            throw new InvalidArgumentException('secret is required');
        }
        if ($toleranceSeconds < 0) {
            throw new InvalidArgumentException('toleranceSeconds must be non-negative');
        }
        if ($nowSeconds !== null && $nowSeconds < 0) {
            throw new InvalidArgumentException('nowSeconds must be non-negative');
        }
        $normalized = [];
        foreach ($headers as $key => $value) {
            $normalized[strtolower((string) $key)] = is_array($value)
                ? trim((string) ($value[0] ?? ''))
                : trim((string) $value);
        }
        $timestamp = $normalized['x-dutt-timestamp'] ?? '';
        $signature = $normalized['x-dutt-signature'] ?? '';
        $event = $normalized['x-dutt-event'] ?? '';
        $eventId = $normalized['x-dutt-event-id'] ?? '';
        if ($timestamp === '' || $signature === '' || $event === '' || $eventId === '') {
            throw new RuntimeException('missing_headers');
        }
        if (!preg_match('/^\d+$/', $timestamp)) {
            throw new RuntimeException('invalid_timestamp');
        }
        if (!preg_match('/^[A-Za-z0-9._:-]{8,128}$/', $eventId)) {
            throw new RuntimeException('invalid_event_id');
        }
        if (strlen($timestamp) > strlen((string) PHP_INT_MAX)) {
            throw new RuntimeException('invalid_timestamp');
        }
        $timestampValue = (int) $timestamp;
        $now = $nowSeconds ?? time();
        if (abs($now - $timestampValue) > $toleranceSeconds) {
            throw new RuntimeException('stale_timestamp');
        }
        $expected = 'sha256=' . hash_hmac(
            'sha256',
            $timestamp . '.' . $rawBody,
            $secret
        );
        if (!hash_equals($expected, $signature)) {
            throw new RuntimeException('invalid_signature');
        }
        try {
            $payload = json_decode($rawBody, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new RuntimeException('invalid_json', 0, $error);
        }
        if (!is_array($payload) || array_is_list($payload)) {
            throw new RuntimeException('invalid_json');
        }
        if (
            trim((string) ($payload['event_id'] ?? '')) !== $eventId ||
            trim((string) ($payload['event'] ?? '')) !== $event
        ) {
            throw new RuntimeException('header_payload_mismatch');
        }
        return [
            'event' => $event,
            'event_id' => $eventId,
            'timestamp' => $timestampValue,
            'payload' => $payload,
        ];
    }

    public static function handle(
        string $rawBody,
        array $headers,
        string $secret,
        ReplayStore $replayStore,
        callable $onEvent,
        int $toleranceSeconds = 300,
        ?int $nowSeconds = null,
    ): array {
        $verified = self::verify(
            $rawBody,
            $headers,
            $secret,
            $toleranceSeconds,
            $nowSeconds
        );
        $claimedAt = $nowSeconds ?? time();
        if (!$replayStore instanceof AtomicReplayStore) {
            if ($replayStore->has($verified['event_id'])) {
                return array_merge($verified, [
                    'duplicate' => true,
                    'processed' => false,
                ]);
            }
            $onEvent($verified['payload'], $verified);
            $replayStore->put($verified['event_id'], $claimedAt);
            return array_merge($verified, [
                'duplicate' => false,
                'processed' => true,
            ]);
        }
        if (!$replayStore->claim($verified['event_id'], $claimedAt)) {
            return array_merge($verified, [
                'duplicate' => true,
                'processed' => false,
            ]);
        }
        try {
            $onEvent($verified['payload'], $verified);
            $replayStore->complete($verified['event_id'], $claimedAt);
            return array_merge($verified, [
                'duplicate' => false,
                'processed' => true,
            ]);
        } catch (Throwable $error) {
            $replayStore->release($verified['event_id']);
            throw $error;
        }
    }
}

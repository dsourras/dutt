# Security

## Credentials

- Use one merchant key per merchant.
- Store the key only in the server secret manager or protected environment.
- Never expose it to browser code.
- Rotate or revoke a compromised key immediately.
- Use a different webhook secret for every merchant/integration.
- Generate webhook secrets from at least 32 random bytes.

## Webhook verification

DUTT sends:

```text
x-dutt-event
x-dutt-event-id
x-dutt-signature
x-dutt-timestamp
```

The signature is:

```text
sha256=HMAC_SHA256(secret, timestamp + "." + raw_request_body)
```

Verification requirements:

1. Read the exact raw request body before JSON parsing.
2. Reject missing or malformed headers.
3. Reject timestamps outside a five-minute window.
4. Compare signatures using a constant-time function.
5. Store `x-dutt-event-id` in a persistent table with a unique constraint.
6. Run the business update in a transaction.
7. Mark the event processed only after the transaction succeeds.

Suggested table:

```sql
CREATE TABLE dutt_webhook_events (
  event_id VARCHAR(128) PRIMARY KEY,
  event_name VARCHAR(80) NOT NULL,
  status VARCHAR(16) NOT NULL,
  received_at TIMESTAMP NOT NULL,
  processed_at TIMESTAMP NULL
);
```

The included in-memory replay store is only for tests and local development. Production must use persistent storage shared by all website instances. Claim the event with one atomic `INSERT` into the primary key before applying it. The claim, local order update, and transition to `processed` should share a database transaction. Delete only a failed `processing` claim so DUTT can retry the event. Legacy `has`/`put` replay stores remain accepted for upgrade compatibility, but they cannot prevent two simultaneous workers from processing the same event and must not be used for a new production integration.

Give `processing` claims a bounded lease so a hard process crash cannot block the event forever. The included PDO example uses 15 minutes and atomically reclaims only stale `processing` rows; it never reclaims `processed` rows. Keep the lease longer than normal webhook processing and perform the local order update idempotently.

When upgrading from version 1.1, migrate the replay table before deploying the 1.2 webhook handler. PostgreSQL example (adapt the `ALTER COLUMN` syntax for the selected database):

```sql
ALTER TABLE dutt_webhook_events ADD COLUMN status VARCHAR(16);
ALTER TABLE dutt_webhook_events ADD COLUMN received_at TIMESTAMP;
UPDATE dutt_webhook_events
SET status = 'processed', received_at = processed_at
WHERE status IS NULL;
ALTER TABLE dutt_webhook_events ALTER COLUMN status SET NOT NULL;
ALTER TABLE dutt_webhook_events ALTER COLUMN received_at SET NOT NULL;
```

The pilot site's JSON replay store migrates legacy `{ "event-id": timestamp }` entries automatically and conservatively treats them as processed.

## Request handling

- Use TLS and reject private/internal callback URLs.
- Set strict outbound timeouts.
- Do not log request authorization headers or webhook secrets.
- Accept only 2xx JSON object responses with `{ "success": true }`.
- Retry only idempotent operations with the same external order identity.
- Keep customer card data outside the integration entirely.

## Secret scanning

Before every release, scan for merchant key prefixes, private keys, access tokens, `.env` files, and webhook secrets. Release archives must exclude `.git`, `.env`, `node_modules`, `vendor`, reports, and previous releases.

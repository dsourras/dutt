# DUTT real-time custom merchant pilot

This local storefront exercises the official Node adapter against the production DUTT merchant API. It keeps the merchant key and webhook secret server-side.

## Safety defaults

- The product total is EUR 0.00 and the merchant absorbs delivery.
- Creating an order stops at `merchant_preparing`.
- Dispatch is disabled unless both `DUTT_ALLOW_LIVE_DISPATCH=YES` and `DUTT_STORE_PHONE_VERIFIED=YES` are set.
- Dispatch and cancellation require explicit confirmation phrases.
- Webhooks are HMAC verified and replay event IDs are persisted under the ignored `data/` directory.

## Run

```powershell
npm run test:pilot
npm run pilot
```

Open `http://127.0.0.1:8123`. A public HTTPS tunnel can point to the same port for webhook delivery; set its URL in `DUTT_SITE_URL` before starting the server.
